var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/program/files/[fileId]/route.js")
R.c("server/chunks/[root-of-the-server]__0ahz.2z._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_program_files_[fileId]_route_actions_0mhug13.js")
R.m(68370)
module.exports=R.m(68370).exports
