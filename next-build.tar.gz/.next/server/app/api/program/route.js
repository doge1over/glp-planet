var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/program/route.js")
R.c("server/chunks/[root-of-the-server]__07crfv5._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_program_route_actions_13xgj0c.js")
R.m(57001)
module.exports=R.m(57001).exports
