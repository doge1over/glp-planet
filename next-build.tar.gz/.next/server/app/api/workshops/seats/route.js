var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/workshops/seats/route.js")
R.c("server/chunks/[root-of-the-server]__0_6gp8m._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_workshops_seats_route_actions_0wi3l71.js")
R.m(51157)
module.exports=R.m(51157).exports
