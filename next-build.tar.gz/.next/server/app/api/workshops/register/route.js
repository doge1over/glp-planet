var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/workshops/register/route.js")
R.c("server/chunks/[root-of-the-server]__02otfb-._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_workshops_register_route_actions_0kxjldf.js")
R.m(49214)
module.exports=R.m(49214).exports
