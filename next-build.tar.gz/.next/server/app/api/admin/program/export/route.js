var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/program/export/route.js")
R.c("server/chunks/[root-of-the-server]__03bf4kc._.js")
R.c("server/chunks/[root-of-the-server]__12d7tn7._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_program_export_route_actions_0cabxpj.js")
R.m(95623)
module.exports=R.m(95623).exports
