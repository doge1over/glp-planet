var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/program/route.js")
R.c("server/chunks/[root-of-the-server]__00qa2-b._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_program_route_actions_0nu.owi.js")
R.m(61693)
module.exports=R.m(61693).exports
