var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/program/files/route.js")
R.c("server/chunks/[root-of-the-server]__0.nssb2._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_program_files_route_actions_13xme9k.js")
R.m(8264)
module.exports=R.m(8264).exports
