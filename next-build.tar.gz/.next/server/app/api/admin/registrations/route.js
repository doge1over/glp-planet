var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/registrations/route.js")
R.c("server/chunks/[root-of-the-server]__069oy9t._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_registrations_route_actions_0l3okg2.js")
R.m(34532)
module.exports=R.m(34532).exports
