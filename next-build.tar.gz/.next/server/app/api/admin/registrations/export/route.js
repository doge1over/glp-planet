var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/registrations/export/route.js")
R.c("server/chunks/[root-of-the-server]__0ykkmto._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_registrations_export_route_actions_07hd4a8.js")
R.m(60603)
module.exports=R.m(60603).exports
