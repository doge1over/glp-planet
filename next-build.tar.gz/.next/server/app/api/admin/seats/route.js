var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/seats/route.js")
R.c("server/chunks/[root-of-the-server]__0_85u_n._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_seats_route_actions_0c4a-m1.js")
R.m(9205)
module.exports=R.m(9205).exports
