1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:I[70119,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0zmi3-gi4c_2x.js","/_next/static/chunks/17pa9cg753_5w.js"],"default"]
e:I[68027,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default",1]
:HL["/_next/static/chunks/0ucn.fhmshxpu.css","style"]
:HL["/_next/static/media/9cd5979df91f9479-s.p.0aav1~6p6zet5.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a626ed2fbe2db1bf-s.p.0_bmx_ioij-un.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"P":null,"c":["","archive","2026"],"q":"","i":false,"f":[[["",{"children":["archive",{"children":["2026",{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0ucn.fhmshxpu.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/01xlw8hd842-c.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0d3shmwh5_nmn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"ru","children":["$","body",null,{"className":"exo_2_ac247d62-module__Li8Wga__className","children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[[["$","$L4",null,{}],["$","main",null,{"style":{"minHeight":"100vh"},"children":[["$","section",null,{"className":"conf-hero","children":["$","div",null,{"className":"conf-container","children":[["$","div",null,{"className":"conf-hero-label","children":"VII Конференция · 2026"}],["$","h1",null,{"className":"conf-hero-title","children":"GLP-Planet конференция 7.0"}],["$","div",null,{"className":"conf-hero-meta","children":[["$","span",null,{"children":"1–3 июля 2026"}],["$","span",null,{"className":"conf-hero-dot","children":"·"}],["$","span",null,{"children":"г. Санкт-Петербург, Россия"}]]}]]}]}],["$","section",null,{"className":"conf-about","children":["$","div",null,{"className":"conf-container","children":[["$","h2",null,{"className":"conf-section-title","children":"О конференции"}],["$","div",null,{"className":"conf-divider"}],["$","div",null,{"className":"conf-text","children":[["$","p",null,{"children":["1–3 июля 2026 г. в Санкт-Петербурге прошла ",["$","strong",null,{"children":"VII Международная научно-практическая конференция GLP-PLANET"}],", организованная совместно с Русской ассоциацией специалистов по лабораторным животным (Rus-LASA)."]}],["$","p",null,{"children":"Конференция состоялась в отеле «Санкт-Петербург» и объединила специалистов в области надлежащей лабораторной практики, фармакологии, доклинических исследований и гуманного обращения с лабораторными животными."}]]}],["$","div",null,{"className":"conf-links","children":[["$","a",null,{"href":"/schedule","target":"_blank","rel":"noopener noreferrer","className":"conf-program-btn","children":[["$","svg",null,{"width":"18","height":"18","viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":"1.5","strokeLinecap":"round","strokeLinejoin":"round","aria-hidden":"true","children":[["$","rect",null,{"x":"3","y":"4","width":"18","height":"17","rx":"2"}],["$","line",null,{"x1":"8","y1":"2","x2":"8","y2":"6"}],["$","line",null,{"x1":"16","y1":"2","x2":"16","y2":"6"}],["$","line",null,{"x1":"3","y1":"10","x2":"21","y2":"10"}]]}],"Расписание конференции"]}],["$","a",null,{"href":"/docs/Programma_GLP_PLANET_VII-1.pdf","target":"_blank","rel":"noopener noreferrer","className":"conf-program-btn","children":["$L5","Программа конференции"]}]]}]]}]}],"$L6"]}],"$L7","$L8"],["$L9","$La"],"$Lb"]}],{},null,false,null]},null,false,"$@c"]},null,false,"$@c"]},null,false,null],"$Ld",false]],"m":"$undefined","G":["$e",["$Lf"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"j-s8gww9if42eMuTXpB6h"}
10:I[67484,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0zmi3-gi4c_2x.js","/_next/static/chunks/17pa9cg753_5w.js"],"default"]
11:I[56691,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0zmi3-gi4c_2x.js","/_next/static/chunks/17pa9cg753_5w.js"],"default"]
13:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
14:"$Sreact.suspense"
17:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"ViewportBoundary"]
19:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"MetadataBoundary"]
5:["$","svg",null,{"width":"18","height":"18","viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":"1.5","strokeLinecap":"round","strokeLinejoin":"round","aria-hidden":"true","children":[["$","path",null,{"d":"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"}],["$","polyline",null,{"points":"14,2 14,8 20,8"}]]}]
6:["$","$L10",null,{}]
7:["$","$L11",null,{}]
12:T94c,
.conf-container { max-width: 1000px; margin: 0 auto; }
.conf-hero { padding: 140px 48px 60px; background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%); }
.conf-hero-label { font-size: 11px; color: #6B82C4; font-weight: 600; text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px; }
.conf-hero-title { font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px; }
.conf-hero-meta { font-size: 15px; color: rgba(255,255,255,0.4); display: flex; align-items: center; flex-wrap: wrap; }
.conf-hero-dot { margin: 0 10px; color: #6B82C4; }
.conf-about { padding: 80px 48px; background: linear-gradient(155deg, #0D1330 0%, #141B4D 50%, #1A2460 100%); }
.conf-section-title { font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 16px; }
.conf-divider { width: 40px; height: 3px; background: var(--secondary); border-radius: 1px; margin-bottom: 32px; }
.conf-text { color: rgba(255,255,255,0.55); font-size: 15px; line-height: 1.85; }
.conf-text p { margin-bottom: 16px; }
.conf-text strong { color: rgba(255,255,255,0.8); }
.conf-links { display: flex; flex-wrap: wrap; gap: 14px; margin-top: 32px; }
.conf-program-btn { display: inline-flex; align-items: center; gap: 10px; padding: 14px 28px; background: rgba(73,100,162,0.15); border: 1px solid rgba(107,130,196,0.3); border-radius: 6px; color: #8FA6E5; font-size: 14px; font-weight: 600; text-decoration: none; transition: all 0.25s; }
.conf-program-btn:hover { background: rgba(73,100,162,0.25); border-color: rgba(107,130,196,0.5); color: #fff; transform: translateY(-2px); }
@media (max-width: 1024px) {
  .conf-hero { padding: 120px 32px 48px; }
  .conf-hero-title { font-size: 34px; }
  .conf-about { padding: 60px 32px; }
}
@media (max-width: 600px) {
  .conf-hero { padding: 100px 20px 36px; }
  .conf-hero-label { font-size: 10px; letter-spacing: 2px; margin-bottom: 8px; }
  .conf-hero-title { font-size: 26px; margin-bottom: 12px; }
  .conf-hero-meta { flex-direction: column; align-items: flex-start; gap: 2px; font-size: 13px; }
  .conf-hero-dot { display: none; }
  .conf-about { padding: 40px 16px; }
  .conf-text { font-size: 14px; line-height: 1.75; }
  .conf-section-title { font-size: 22px; }
  .conf-links { flex-direction: column; gap: 10px; }
  .conf-program-btn { padding: 12px 20px; font-size: 13px; width: 100%; justify-content: center; }
}
8:["$","style",null,{"children":"$12"}]
9:["$","script","script-0",{"src":"/_next/static/chunks/0zmi3-gi4c_2x.js","async":true,"nonce":"$undefined"}]
a:["$","script","script-1",{"src":"/_next/static/chunks/17pa9cg753_5w.js","async":true,"nonce":"$undefined"}]
b:["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]
16:[]
c:"$W16"
d:["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","div",null,{"hidden":true,"children":["$","$L19",null,{"children":["$","$14",null,{"name":"Next.Metadata","children":"$L1a"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
f:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0ucn.fhmshxpu.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1b:I[27201,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"IconMark"]
15:null
1a:[["$","title","0",{"children":"GLP-Planet конференция 2026 — GLP-Planet"}],["$","meta","1",{"name":"description","content":"VII Международная научно-практическая конференция GLP-Planet совместно с Rus-LASA, 1–3 июля 2026 г., Санкт-Петербург"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0y7j9ngb5somr.ico","sizes":"256x256","type":"image/x-icon"}],["$","link","3",{"rel":"icon","href":"/icon.png?icon.03_uxo6ldu04c.png","sizes":"512x512","type":"image/png"}],["$","link","4",{"rel":"apple-touch-icon","href":"/apple-icon.png?apple-icon.06b5hegi~w45e.png","sizes":"180x180","type":"image/png"}],["$","$L1b","5",{}]]
