1:"$Sreact.fragment"
2:I[70119,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0zmi3-gi4c_2x.js","/_next/static/chunks/17pa9cg753_5w.js"],"default"]
3:I[67484,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0zmi3-gi4c_2x.js","/_next/static/chunks/17pa9cg753_5w.js"],"default"]
4:I[56691,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0zmi3-gi4c_2x.js","/_next/static/chunks/17pa9cg753_5w.js"],"default"]
9:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
a:"$Sreact.suspense"
5:T94c,
.conf-container { max-width: 1000px; margin: 0 auto; }
.conf-hero { padding: 140px 48px 60px; background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%); }
.conf-hero-label { font-size: 11px; color: #6B82C4; font-weight: 600; text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px; }
.conf-hero-title { font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px; }
.conf-hero-meta { font-size: 15px; color: rgba(255,255,255,0.4); display: flex; align-items: center; flex-wrap: wrap; }
.conf-hero-dot { margin: 0 10px; color: #6B82C4; }
.conf-about { padding: 80px 48px; background: linear-gradient(155deg, #0D1330 0%, #141B4D 50%, #1A2460 100%); }
.conf-section-title { font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 16px; }
.conf-divider { width: 40px; height: 3px; background: var(--secondary); border-radius: 1px; margin-bottom: 32px; }
.conf-text { color: rgba(255,255,255,0.55); font-size: 15px; line-height: 1.85; }
.conf-text p { margin-bottom: 16px; }
.conf-text strong { color: rgba(255,255,255,0.8); }
.conf-links { display: flex; flex-wrap: wrap; gap: 14px; margin-top: 32px; }
.conf-program-btn { display: inline-flex; align-items: center; gap: 10px; padding: 14px 28px; background: rgba(73,100,162,0.15); border: 1px solid rgba(107,130,196,0.3); border-radius: 6px; color: #8FA6E5; font-size: 14px; font-weight: 600; text-decoration: none; transition: all 0.25s; }
.conf-program-btn:hover { background: rgba(73,100,162,0.25); border-color: rgba(107,130,196,0.5); color: #fff; transform: translateY(-2px); }
@media (max-width: 1024px) {
  .conf-hero { padding: 120px 32px 48px; }
  .conf-hero-title { font-size: 34px; }
  .conf-about { padding: 60px 32px; }
}
@media (max-width: 600px) {
  .conf-hero { padding: 100px 20px 36px; }
  .conf-hero-label { font-size: 10px; letter-spacing: 2px; margin-bottom: 8px; }
  .conf-hero-title { font-size: 26px; margin-bottom: 12px; }
  .conf-hero-meta { flex-direction: column; align-items: flex-start; gap: 2px; font-size: 13px; }
  .conf-hero-dot { display: none; }
  .conf-about { padding: 40px 16px; }
  .conf-text { font-size: 14px; line-height: 1.75; }
  .conf-section-title { font-size: 22px; }
  .conf-links { flex-direction: column; gap: 10px; }
  .conf-program-btn { padding: 12px 20px; font-size: 13px; width: 100%; justify-content: center; }
}
0:{"rsc":["$","$1","c",{"children":[[["$","$L2",null,{}],["$","main",null,{"style":{"minHeight":"100vh"},"children":[["$","section",null,{"className":"conf-hero","children":["$","div",null,{"className":"conf-container","children":[["$","div",null,{"className":"conf-hero-label","children":"VII Конференция · 2026"}],["$","h1",null,{"className":"conf-hero-title","children":"GLP-Planet конференция 7.0"}],["$","div",null,{"className":"conf-hero-meta","children":[["$","span",null,{"children":"1–3 июля 2026"}],["$","span",null,{"className":"conf-hero-dot","children":"·"}],["$","span",null,{"children":"г. Санкт-Петербург, Россия"}]]}]]}]}],["$","section",null,{"className":"conf-about","children":["$","div",null,{"className":"conf-container","children":[["$","h2",null,{"className":"conf-section-title","children":"О конференции"}],["$","div",null,{"className":"conf-divider"}],["$","div",null,{"className":"conf-text","children":[["$","p",null,{"children":["1–3 июля 2026 г. в Санкт-Петербурге прошла ",["$","strong",null,{"children":"VII Международная научно-практическая конференция GLP-PLANET"}],", организованная совместно с Русской ассоциацией специалистов по лабораторным животным (Rus-LASA)."]}],["$","p",null,{"children":"Конференция состоялась в отеле «Санкт-Петербург» и объединила специалистов в области надлежащей лабораторной практики, фармакологии, доклинических исследований и гуманного обращения с лабораторными животными."}]]}],["$","div",null,{"className":"conf-links","children":[["$","a",null,{"href":"/schedule","target":"_blank","rel":"noopener noreferrer","className":"conf-program-btn","children":[["$","svg",null,{"width":"18","height":"18","viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":"1.5","strokeLinecap":"round","strokeLinejoin":"round","aria-hidden":"true","children":[["$","rect",null,{"x":"3","y":"4","width":"18","height":"17","rx":"2"}],["$","line",null,{"x1":"8","y1":"2","x2":"8","y2":"6"}],["$","line",null,{"x1":"16","y1":"2","x2":"16","y2":"6"}],["$","line",null,{"x1":"3","y1":"10","x2":"21","y2":"10"}]]}],"Расписание конференции"]}],["$","a",null,{"href":"/docs/Programma_GLP_PLANET_VII-1.pdf","target":"_blank","rel":"noopener noreferrer","className":"conf-program-btn","children":[["$","svg",null,{"width":"18","height":"18","viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":"1.5","strokeLinecap":"round","strokeLinejoin":"round","aria-hidden":"true","children":[["$","path",null,{"d":"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"}],["$","polyline",null,{"points":"14,2 14,8 20,8"}]]}],"Программа конференции"]}]]}]]}]}],["$","$L3",null,{}]]}],["$","$L4",null,{}],["$","style",null,{"children":"$5"}]],["$L6","$L7"],"$L8"]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"j-s8gww9if42eMuTXpB6h"}
6:["$","script","script-0",{"src":"/_next/static/chunks/0zmi3-gi4c_2x.js","async":true}]
7:["$","script","script-1",{"src":"/_next/static/chunks/17pa9cg753_5w.js","async":true}]
8:["$","$L9",null,{"children":["$","$a",null,{"name":"Next.MetadataOutlet","children":"$@b"}]}]
b:null
