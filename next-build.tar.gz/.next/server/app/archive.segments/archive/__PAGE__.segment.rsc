1:"$Sreact.fragment"
2:I[70119,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0vjjfldwujcyt.js"],"default"]
3:I[5500,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0vjjfldwujcyt.js"],"Image"]
a:I[56691,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0vjjfldwujcyt.js"],"default"]
c:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
d:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[[["$","$L2",null,{}],["$","main",null,{"style":{"minHeight":"100vh"},"children":[["$","section",null,{"className":"archive-hero","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":[["$","div",null,{"style":{"fontSize":11,"color":"#6B82C4","fontWeight":600,"textTransform":"uppercase","letterSpacing":3,"marginBottom":12},"children":"История"}],["$","h1",null,{"style":{"fontSize":42,"fontWeight":700,"color":"#fff","lineHeight":1.2,"marginBottom":16},"children":"Архив конференций"}],["$","p",null,{"style":{"fontSize":16,"color":"rgba(255,255,255,0.72)","lineHeight":1.8,"maxWidth":560},"children":"Все прошедшие конференции GLP-PLANET"}]]}]}],["$","section",null,{"className":"archive-content","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":["$","div",null,{"className":"archive-page-grid","children":[["$","a","2020",{"href":"/archive/2020","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L3",null,{"src":"/images/archive/2020.jpg","alt":"GLP — Planet конференция 1.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2020}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 1.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2021",{"href":"/archive/2021","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L3",null,{"src":"/images/archive/2021.jpg","alt":"GLP — Planet конференция 2.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2021}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 2.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2022",{"href":"/archive/2022","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L3",null,{"src":"/images/archive/2022.jpg","alt":"GLP — Planet конференция 3.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2022}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 3.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2023",{"href":"/archive/2023","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L3",null,{"src":"/images/archive/2023.jpg","alt":"GLP — Planet конференция 4.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2023}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 4.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2024",{"href":"/archive/2024","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L3",null,{"src":"/images/archive/2024.jpg","alt":"GLP — Planet конференция 5.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2024}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 5.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2025",{"href":"/archive/2025","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L3",null,{"src":"/images/archive/2020.jpg","alt":"GLP — Planet конференция 6.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],"$L4","$L5"]}]]}]}]}]]}],"$L6","$L7"],["$L8"],"$L9"]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Due96VcOfCdFGsHzAgsbE"}
4:["$","div",null,{"className":"archive-card-overlay"}]
5:["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2025}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 6.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]
6:["$","$La",null,{}]
b:Tb1c,
        .archive-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .archive-content { padding: 80px 48px 100px; }
        .archive-page-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .archive-card {
          display: block; position: relative; overflow: hidden;
          border-radius: 6px; aspect-ratio: 1.5; text-decoration: none;
        }
        .archive-card-img {
          object-fit: cover;
          transition: transform 1.2s cubic-bezier(0.25, 1, 0.5, 1) !important;
        }
        .archive-card:hover .archive-card-img { transform: scale(1.12); }
        .archive-card-overlay {
          position: absolute; inset: 0;
          background: linear-gradient(to top, rgba(20,27,77,0.88) 0%, rgba(20,27,77,0.55) 50%, rgba(20,27,77,0.4) 100%);
          transition: background 0.6s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .archive-card:hover .archive-card-overlay {
          background: linear-gradient(to top, rgba(20,27,77,0.92) 0%, rgba(20,27,77,0.6) 50%, rgba(20,27,77,0.45) 100%);
        }
        .archive-card-content {
          position: absolute; inset: 0; display: flex; flex-direction: column;
          justify-content: flex-end; padding: 28px; z-index: 2;
        }
        .archive-card-year { font-size: 52px; font-weight: 800; color: #fff; line-height: 1; margin-bottom: 6px; }
        .archive-card-label { font-size: 14px; color: rgba(255,255,255,0.72); margin-bottom: 16px; }
        .archive-card-btn {
          display: inline-block; padding: 8px 22px;
          border: 1.5px solid rgba(255,255,255,0.3); border-radius: 3px;
          color: #fff; font-size: 12px; font-weight: 600; letter-spacing: 1px;
          text-transform: uppercase; font-family: 'Exo 2', sans-serif; width: fit-content;
          opacity: 0; transform: translateY(8px);
          transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .archive-card:hover .archive-card-btn { opacity: 1; transform: translateY(0); }

        @media (max-width: 1024px) {
          .archive-hero { padding: 120px 32px 48px; }
          .archive-hero h1 { font-size: 34px; }
          .archive-content { padding: 60px 32px 80px; }
        }
        @media (max-width: 900px) {
          .archive-page-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 600px) {
          .archive-hero { padding: 100px 20px 40px; }
          .archive-hero h1 { font-size: 28px; }
          .archive-content { padding: 40px 20px 60px; }
          .archive-page-grid { grid-template-columns: 1fr; }
          .archive-card { aspect-ratio: 1.6; }
          .archive-card-year { font-size: 36px; }
          .archive-card-btn { opacity: 1; transform: translateY(0); }
        }
      7:["$","style",null,{"children":"$b"}]
8:["$","script","script-0",{"src":"/_next/static/chunks/0vjjfldwujcyt.js","async":true}]
9:["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]
e:null
