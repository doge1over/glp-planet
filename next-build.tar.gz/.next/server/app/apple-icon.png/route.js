var R=require("../../chunks/[turbopack]_runtime.js")("server/app/apple-icon.png/route.js")
R.c("server/chunks/[externals]_next_dist_0sqmaqd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0fco8.n.js")
R.c("server/chunks/_next-internal_server_app_apple-icon_png_route_actions_0a.wbmr.js")
R.m(94252)
module.exports=R.m(94252).exports
