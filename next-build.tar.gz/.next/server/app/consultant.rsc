1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:I[70119,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/06~brj57.o7gl.js"],"default"]
f:I[68027,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default",1]
:HL["/_next/static/chunks/0ucn.fhmshxpu.css","style"]
:HL["/_next/static/media/9cd5979df91f9479-s.p.0aav1~6p6zet5.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a626ed2fbe2db1bf-s.p.0_bmx_ioij-un.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/images/monographs/2021.jpg","image"]
:HL["/images/monographs/2022.jpg","image"]
0:{"P":null,"c":["","consultant"],"q":"","i":false,"f":[[["",{"children":["consultant",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0ucn.fhmshxpu.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/01xlw8hd842-c.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0d3shmwh5_nmn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"ru","children":["$","body",null,{"className":"exo_2_ac247d62-module__Li8Wga__className","children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[[["$","$L4",null,{}],["$","main",null,{"style":{"minHeight":"100vh"},"children":[["$","section",null,{"className":"consultant-hero","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":[["$","div",null,{"style":{"fontSize":11,"color":"#6B82C4","fontWeight":600,"textTransform":"uppercase","letterSpacing":3,"marginBottom":12},"children":"Монографии"}],["$","h1",null,{"className":"consultant-title","children":"Консультант GLP-PLANET"}],["$","p",null,{"style":{"fontSize":16,"color":"rgba(255,255,255,0.6)","lineHeight":1.8,"maxWidth":620},"children":"По итогам каждой конференции выпускается коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»"}]]}]}],["$","section",null,{"className":"consultant-content","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":["$","div",null,{"className":"monographs-grid","children":[["$","a","2021",{"href":"https://glp-planet.com/wp-content/uploads/2022/11/monografiya_consultant_glp-planet_2021_final_compressed.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2021.jpg","alt":"Консультант GLP-PLANET 2021","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2021}]]}]]}],["$","a","2022",{"href":"https://glp-planet.com/wp-content/uploads/2022/11/monografiya_consultant_glp-planet_2022f.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2022.jpg","alt":"Консультант GLP-PLANET 2022","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],"$L5"]}],"$L6","$L7","$L8"]}]}]}]]}],"$L9","$La"],["$Lb"],"$Lc"]}],{},null,false,null]},null,false,"$@d"]},null,false,null],"$Le",false]],"m":"$undefined","G":["$f",["$L10"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"Due96VcOfCdFGsHzAgsbE"}
11:I[56691,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/06~brj57.o7gl.js"],"default"]
13:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
14:"$Sreact.suspense"
17:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"ViewportBoundary"]
19:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"MetadataBoundary"]
:HL["/images/monographs/2023.png","image"]
:HL["/images/monographs/2024.png","image"]
:HL["/images/monographs/2025.jpg","image"]
5:["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2022}]]}]
6:["$","a","2023",{"href":"https://cdn.glp-planet.com/2023/book/consultant-glp-planet-2023.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2023.png","alt":"Консультант GLP-PLANET 2023","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2023}]]}]]}]
7:["$","a","2024",{"href":"https://cdn.glp-planet.com/2024/book/consultant-glp-planet-2024.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2024.png","alt":"Консультант GLP-PLANET 2024","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2024}]]}]]}]
8:["$","a","2025",{"href":"https://cdn.glp-planet.com/2025/book/consultant-glp-planet-2025.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2025.jpg","alt":"Консультант GLP-PLANET 2025","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2025}]]}]]}]
9:["$","$L11",null,{}]
12:Tb15,
        .consultant-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .consultant-title {
          font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px;
        }
        .consultant-content {
          padding: 80px 48px 100px;
        }
        .monographs-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 32px;
        }
        .monograph-card {
          text-decoration: none;
          display: block;
          transition: transform 0.6s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .monograph-card:hover {
          transform: translateY(-6px);
        }
        .monograph-cover {
          position: relative;
          border-radius: 6px;
          overflow: hidden;
          background: var(--light);
          aspect-ratio: 0.71;
          box-shadow: 0 6px 24px rgba(20, 27, 77, 0.1);
          transition: box-shadow 0.35s;
        }
        .monograph-card:hover .monograph-cover {
          box-shadow: 0 20px 50px rgba(20, 27, 77, 0.2);
        }
        .monograph-overlay {
          position: absolute;
          inset: 0;
          background: rgba(8, 12, 36, 0.75);
          display: flex;
          align-items: flex-end;
          justify-content: center;
          padding-bottom: 100px;
          opacity: 0;
          transition: opacity 0.3s;
        }
        .monograph-card:hover .monograph-overlay {
          opacity: 1;
        }
        .monograph-overlay-btn {
          padding: 12px 36px;
          border: 1.5px solid rgba(255,255,255,0.6);
          border-radius: 3px;
          color: #fff;
          font-size: 14px;
          font-weight: 600;
          letter-spacing: 1.5px;
          text-transform: uppercase;
          font-family: 'Exo 2', sans-serif;
          transition: background 0.3s, border-color 0.3s;
        }
        .monograph-overlay-btn:hover {
          background: rgba(255,255,255,0.15);
          border-color: #fff;
        }
        @media (max-width: 1024px) {
          .consultant-hero { padding: 120px 32px 48px; }
          .consultant-title { font-size: 34px; }
          .consultant-content { padding: 60px 32px 80px; }
        }
        @media (max-width: 1000px) {
          .monographs-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 24px;
          }
        }
        @media (max-width: 600px) {
          .consultant-hero { padding: 100px 20px 40px; }
          .consultant-title { font-size: 28px; }
          .consultant-content { padding: 40px 20px 60px; }
          .monographs-grid {
            grid-template-columns: 1fr;
            gap: 32px;
            max-width: 380px;
            margin: 0 auto;
          }

        }
      a:["$","style",null,{"children":"$12"}]
b:["$","script","script-0",{"src":"/_next/static/chunks/06~brj57.o7gl.js","async":true,"nonce":"$undefined"}]
c:["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]
16:[]
d:"$W16"
e:["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","div",null,{"hidden":true,"children":["$","$L19",null,{"children":["$","$14",null,{"name":"Next.Metadata","children":"$L1a"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
10:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0ucn.fhmshxpu.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
15:null
1a:[["$","title","0",{"children":"Консультант GLP-PLANET — Монографии"}],["$","meta","1",{"name":"description","content":"Коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»"}]]
