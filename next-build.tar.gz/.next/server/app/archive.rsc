1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:I[70119,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0vjjfldwujcyt.js"],"default"]
5:I[5500,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0vjjfldwujcyt.js"],"Image"]
11:I[68027,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default",1]
:HL["/_next/static/chunks/0ucn.fhmshxpu.css","style"]
:HL["/_next/static/media/9cd5979df91f9479-s.p.0aav1~6p6zet5.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a626ed2fbe2db1bf-s.p.0_bmx_ioij-un.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"P":null,"c":["","archive"],"q":"","i":false,"f":[[["",{"children":["archive",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0ucn.fhmshxpu.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/01xlw8hd842-c.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0d3shmwh5_nmn.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"ru","children":["$","body",null,{"className":"exo_2_ac247d62-module__Li8Wga__className","children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[[["$","$L4",null,{}],["$","main",null,{"style":{"minHeight":"100vh"},"children":[["$","section",null,{"className":"archive-hero","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":[["$","div",null,{"style":{"fontSize":11,"color":"#6B82C4","fontWeight":600,"textTransform":"uppercase","letterSpacing":3,"marginBottom":12},"children":"История"}],["$","h1",null,{"style":{"fontSize":42,"fontWeight":700,"color":"#fff","lineHeight":1.2,"marginBottom":16},"children":"Архив конференций"}],["$","p",null,{"style":{"fontSize":16,"color":"rgba(255,255,255,0.72)","lineHeight":1.8,"maxWidth":560},"children":"Все прошедшие конференции GLP-PLANET"}]]}]}],["$","section",null,{"className":"archive-content","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":["$","div",null,{"className":"archive-page-grid","children":[["$","a","2020",{"href":"/archive/2020","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L5",null,{"src":"/images/archive/2020.jpg","alt":"GLP — Planet конференция 1.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2020}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 1.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2021",{"href":"/archive/2021","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L5",null,{"src":"/images/archive/2021.jpg","alt":"GLP — Planet конференция 2.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2021}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 2.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}],["$","a","2022",{"href":"/archive/2022","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L5",null,{"src":"/images/archive/2022.jpg","alt":"GLP — Planet конференция 3.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],"$L6","$L7"]}],"$L8","$L9","$La"]}]}]}]]}],"$Lb","$Lc"],["$Ld"],"$Le"]}],{},null,false,null]},null,false,"$@f"]},null,false,null],"$L10",false]],"m":"$undefined","G":["$11",["$L12"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"Due96VcOfCdFGsHzAgsbE"}
13:I[56691,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0vjjfldwujcyt.js"],"default"]
15:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
16:"$Sreact.suspense"
19:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"ViewportBoundary"]
1b:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"MetadataBoundary"]
6:["$","div",null,{"className":"archive-card-overlay"}]
7:["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2022}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 3.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]
8:["$","a","2023",{"href":"/archive/2023","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L5",null,{"src":"/images/archive/2023.jpg","alt":"GLP — Planet конференция 4.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2023}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 4.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}]
9:["$","a","2024",{"href":"/archive/2024","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L5",null,{"src":"/images/archive/2024.jpg","alt":"GLP — Planet конференция 5.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2024}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 5.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}]
a:["$","a","2025",{"href":"/archive/2025","target":"_blank","rel":"noopener noreferrer","className":"archive-card","children":[["$","$L5",null,{"src":"/images/archive/2020.jpg","alt":"GLP — Planet конференция 6.0","fill":true,"sizes":"(max-width: 600px) 100vw, (max-width: 900px) 50vw, 33vw","className":"archive-card-img"}],["$","div",null,{"className":"archive-card-overlay"}],["$","div",null,{"className":"archive-card-content","children":[["$","div",null,{"className":"archive-card-year","children":2025}],["$","div",null,{"className":"archive-card-label","children":"GLP — Planet конференция 6.0"}],["$","div",null,{"className":"archive-card-btn","children":"Перейти"}]]}]]}]
b:["$","$L13",null,{}]
14:Tb1c,
        .archive-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .archive-content { padding: 80px 48px 100px; }
        .archive-page-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .archive-card {
          display: block; position: relative; overflow: hidden;
          border-radius: 6px; aspect-ratio: 1.5; text-decoration: none;
        }
        .archive-card-img {
          object-fit: cover;
          transition: transform 1.2s cubic-bezier(0.25, 1, 0.5, 1) !important;
        }
        .archive-card:hover .archive-card-img { transform: scale(1.12); }
        .archive-card-overlay {
          position: absolute; inset: 0;
          background: linear-gradient(to top, rgba(20,27,77,0.88) 0%, rgba(20,27,77,0.55) 50%, rgba(20,27,77,0.4) 100%);
          transition: background 0.6s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .archive-card:hover .archive-card-overlay {
          background: linear-gradient(to top, rgba(20,27,77,0.92) 0%, rgba(20,27,77,0.6) 50%, rgba(20,27,77,0.45) 100%);
        }
        .archive-card-content {
          position: absolute; inset: 0; display: flex; flex-direction: column;
          justify-content: flex-end; padding: 28px; z-index: 2;
        }
        .archive-card-year { font-size: 52px; font-weight: 800; color: #fff; line-height: 1; margin-bottom: 6px; }
        .archive-card-label { font-size: 14px; color: rgba(255,255,255,0.72); margin-bottom: 16px; }
        .archive-card-btn {
          display: inline-block; padding: 8px 22px;
          border: 1.5px solid rgba(255,255,255,0.3); border-radius: 3px;
          color: #fff; font-size: 12px; font-weight: 600; letter-spacing: 1px;
          text-transform: uppercase; font-family: 'Exo 2', sans-serif; width: fit-content;
          opacity: 0; transform: translateY(8px);
          transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .archive-card:hover .archive-card-btn { opacity: 1; transform: translateY(0); }

        @media (max-width: 1024px) {
          .archive-hero { padding: 120px 32px 48px; }
          .archive-hero h1 { font-size: 34px; }
          .archive-content { padding: 60px 32px 80px; }
        }
        @media (max-width: 900px) {
          .archive-page-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 600px) {
          .archive-hero { padding: 100px 20px 40px; }
          .archive-hero h1 { font-size: 28px; }
          .archive-content { padding: 40px 20px 60px; }
          .archive-page-grid { grid-template-columns: 1fr; }
          .archive-card { aspect-ratio: 1.6; }
          .archive-card-year { font-size: 36px; }
          .archive-card-btn { opacity: 1; transform: translateY(0); }
        }
      c:["$","style",null,{"children":"$14"}]
d:["$","script","script-0",{"src":"/_next/static/chunks/0vjjfldwujcyt.js","async":true,"nonce":"$undefined"}]
e:["$","$L15",null,{"children":["$","$16",null,{"name":"Next.MetadataOutlet","children":"$@17"}]}]
18:[]
f:"$W18"
10:["$","$1","h",{"children":[null,["$","$L19",null,{"children":"$L1a"}],["$","div",null,{"hidden":true,"children":["$","$L1b",null,{"children":["$","$16",null,{"name":"Next.Metadata","children":"$L1c"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
12:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0ucn.fhmshxpu.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
1a:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
17:null
1c:[["$","title","0",{"children":"Архив конференций — GLP-Planet"}],["$","meta","1",{"name":"description","content":"Архив конференций GLP-PLANET с 2020 по 2025 год"}]]
