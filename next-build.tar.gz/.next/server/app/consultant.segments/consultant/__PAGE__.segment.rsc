1:"$Sreact.fragment"
2:I[70119,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/06~brj57.o7gl.js"],"default"]
9:I[56691,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/06~brj57.o7gl.js"],"default"]
b:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
c:"$Sreact.suspense"
:HL["/images/monographs/2021.jpg","image"]
:HL["/images/monographs/2022.jpg","image"]
:HL["/images/monographs/2023.png","image"]
:HL["/images/monographs/2024.png","image"]
:HL["/images/monographs/2025.jpg","image"]
0:{"rsc":["$","$1","c",{"children":[[["$","$L2",null,{}],["$","main",null,{"style":{"minHeight":"100vh"},"children":[["$","section",null,{"className":"consultant-hero","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":[["$","div",null,{"style":{"fontSize":11,"color":"#6B82C4","fontWeight":600,"textTransform":"uppercase","letterSpacing":3,"marginBottom":12},"children":"Монографии"}],["$","h1",null,{"className":"consultant-title","children":"Консультант GLP-PLANET"}],["$","p",null,{"style":{"fontSize":16,"color":"rgba(255,255,255,0.6)","lineHeight":1.8,"maxWidth":620},"children":"По итогам каждой конференции выпускается коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»"}]]}]}],["$","section",null,{"className":"consultant-content","children":["$","div",null,{"style":{"maxWidth":1200,"margin":"0 auto"},"children":["$","div",null,{"className":"monographs-grid","children":[["$","a","2021",{"href":"https://glp-planet.com/wp-content/uploads/2022/11/monografiya_consultant_glp-planet_2021_final_compressed.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2021.jpg","alt":"Консультант GLP-PLANET 2021","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2021}]]}]]}],["$","a","2022",{"href":"https://glp-planet.com/wp-content/uploads/2022/11/monografiya_consultant_glp-planet_2022f.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2022.jpg","alt":"Консультант GLP-PLANET 2022","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2022}]]}]]}],["$","a","2023",{"href":"https://cdn.glp-planet.com/2023/book/consultant-glp-planet-2023.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2023.png","alt":"Консультант GLP-PLANET 2023","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2023}]]}]]}],["$","a","2024",{"href":"https://cdn.glp-planet.com/2024/book/consultant-glp-planet-2024.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":[["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2024.png","alt":"Консультант GLP-PLANET 2024","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}],["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2024}]]}]]}],["$","a","2025",{"href":"https://cdn.glp-planet.com/2025/book/consultant-glp-planet-2025.pdf","target":"_blank","rel":"noopener noreferrer","className":"monograph-card","children":["$L3","$L4"]}]]}]}]}]]}],"$L5","$L6"],["$L7"],"$L8"]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Due96VcOfCdFGsHzAgsbE"}
3:["$","div",null,{"className":"monograph-cover","children":[["$","img",null,{"src":"/images/monographs/2025.jpg","alt":"Консультант GLP-PLANET 2025","style":{"width":"100%","height":"100%","objectFit":"cover","display":"block"}}],["$","div",null,{"className":"monograph-overlay","children":["$","div",null,{"className":"monograph-overlay-btn","children":"Читать"}]}]]}]
4:["$","div",null,{"style":{"padding":"20px 4px 12px","textAlign":"center"},"children":[["$","div",null,{"style":{"fontSize":14,"fontWeight":600,"color":"var(--primary)","letterSpacing":0.5},"children":"Консультант GLP-PLANET"}],["$","div",null,{"style":{"fontSize":28,"fontWeight":800,"color":"var(--primary)","marginTop":4},"children":2025}]]}]
5:["$","$L9",null,{}]
a:Tb15,
        .consultant-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .consultant-title {
          font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px;
        }
        .consultant-content {
          padding: 80px 48px 100px;
        }
        .monographs-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 32px;
        }
        .monograph-card {
          text-decoration: none;
          display: block;
          transition: transform 0.6s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .monograph-card:hover {
          transform: translateY(-6px);
        }
        .monograph-cover {
          position: relative;
          border-radius: 6px;
          overflow: hidden;
          background: var(--light);
          aspect-ratio: 0.71;
          box-shadow: 0 6px 24px rgba(20, 27, 77, 0.1);
          transition: box-shadow 0.35s;
        }
        .monograph-card:hover .monograph-cover {
          box-shadow: 0 20px 50px rgba(20, 27, 77, 0.2);
        }
        .monograph-overlay {
          position: absolute;
          inset: 0;
          background: rgba(8, 12, 36, 0.75);
          display: flex;
          align-items: flex-end;
          justify-content: center;
          padding-bottom: 100px;
          opacity: 0;
          transition: opacity 0.3s;
        }
        .monograph-card:hover .monograph-overlay {
          opacity: 1;
        }
        .monograph-overlay-btn {
          padding: 12px 36px;
          border: 1.5px solid rgba(255,255,255,0.6);
          border-radius: 3px;
          color: #fff;
          font-size: 14px;
          font-weight: 600;
          letter-spacing: 1.5px;
          text-transform: uppercase;
          font-family: 'Exo 2', sans-serif;
          transition: background 0.3s, border-color 0.3s;
        }
        .monograph-overlay-btn:hover {
          background: rgba(255,255,255,0.15);
          border-color: #fff;
        }
        @media (max-width: 1024px) {
          .consultant-hero { padding: 120px 32px 48px; }
          .consultant-title { font-size: 34px; }
          .consultant-content { padding: 60px 32px 80px; }
        }
        @media (max-width: 1000px) {
          .monographs-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 24px;
          }
        }
        @media (max-width: 600px) {
          .consultant-hero { padding: 100px 20px 40px; }
          .consultant-title { font-size: 28px; }
          .consultant-content { padding: 40px 20px 60px; }
          .monographs-grid {
            grid-template-columns: 1fr;
            gap: 32px;
            max-width: 380px;
            margin: 0 auto;
          }

        }
      6:["$","style",null,{"children":"$a"}]
7:["$","script","script-0",{"src":"/_next/static/chunks/06~brj57.o7gl.js","async":true}]
8:["$","$Lb",null,{"children":["$","$c",null,{"name":"Next.MetadataOutlet","children":"$@d"}]}]
d:null
