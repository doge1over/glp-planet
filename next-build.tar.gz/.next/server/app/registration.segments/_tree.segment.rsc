:HL["/_next/static/chunks/0ucn.fhmshxpu.css","style"]
:HL["/_next/static/media/9cd5979df91f9479-s.p.0aav1~6p6zet5.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a626ed2fbe2db1bf-s.p.0_bmx_ioij-un.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"registration","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"Due96VcOfCdFGsHzAgsbE"}
