module.exports=[99641,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_seats_route_actions_0c4a-m1.js.map