module.exports=[92924,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workshops_seats_route_actions_0wi3l71.js.map