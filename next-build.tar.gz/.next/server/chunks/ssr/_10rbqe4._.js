module.exports=[30089,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"setAttributesFromProps",{enumerable:!0,get:function(){return g}});let d={acceptCharset:"accept-charset",className:"class",htmlFor:"for",httpEquiv:"http-equiv",noModule:"noModule"},e=["onLoad","onReady","dangerouslySetInnerHTML","children","onError","strategy","stylesheets"];function f(a){return["async","defer","noModule"].includes(a)}function g(a,b){for(let[c,g]of Object.entries(b)){if(!b.hasOwnProperty(c)||e.includes(c)||void 0===g)continue;let h=d[c]||c.toLowerCase();"SCRIPT"===a.tagName&&f(h)?a[h]=!!g:a.setAttribute(h,String(g)),(!1===g||"SCRIPT"===a.tagName&&f(h)&&(!g||"false"===g))&&(a.setAttribute(h,""),a.removeAttribute(h))}}("function"==typeof c.default||"object"==typeof c.default&&null!==c.default)&&void 0===c.default.__esModule&&(Object.defineProperty(c.default,"__esModule",{value:!0}),Object.assign(c.default,c),b.exports=c.default)},12962,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={cancelIdleCallback:function(){return g},requestIdleCallback:function(){return f}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f="u">typeof self&&self.requestIdleCallback&&self.requestIdleCallback.bind(window)||function(a){let b=Date.now();return self.setTimeout(function(){a({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-b))}})},1)},g="u">typeof self&&self.cancelIdleCallback&&self.cancelIdleCallback.bind(window)||function(a){return clearTimeout(a)};("function"==typeof c.default||"object"==typeof c.default&&null!==c.default)&&void 0===c.default.__esModule&&(Object.defineProperty(c.default,"__esModule",{value:!0}),Object.assign(c.default,c),b.exports=c.default)},96665,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={default:function(){return t},handleClientScriptLoad:function(){return q},initScriptLoader:function(){return r}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f=a.r(33354),g=a.r(46058),h=a.r(87924),i=f._(a.r(35112)),j=g._(a.r(72131)),k=a.r(92966),l=a.r(30089),m=a.r(12962),n=new Map,o=new Set,p=a=>{let{src:b,id:c,onLoad:d=()=>{},onReady:e=null,dangerouslySetInnerHTML:f,children:g="",strategy:h="afterInteractive",onError:j,stylesheets:k}=a,m=c||b;if(m&&o.has(m))return;if(n.has(b)){o.add(m),n.get(b).then(d,j);return}let p=()=>{e&&e(),o.add(m)},q=document.createElement("script"),r=new Promise((a,b)=>{q.addEventListener("load",function(b){a(),d&&d.call(this,b),p()}),q.addEventListener("error",function(a){b(a)})}).catch(function(a){j&&j(a)});f?(q.innerHTML=f.__html||"",p()):g?(q.textContent="string"==typeof g?g:Array.isArray(g)?g.join(""):"",p()):b&&(q.src=b,n.set(b,r)),(0,l.setAttributesFromProps)(q,a),"worker"===h&&q.setAttribute("type","text/partytown"),q.setAttribute("data-nscript",h),k&&(a=>{if(i.default.preinit)return a.forEach(a=>{i.default.preinit(a,{as:"style"})})})(k),document.body.appendChild(q)};function q(a){let{strategy:b="afterInteractive"}=a;"lazyOnload"===b?window.addEventListener("load",()=>{(0,m.requestIdleCallback)(()=>p(a))}):p(a)}function r(a){a.forEach(q),[...document.querySelectorAll('[data-nscript="beforeInteractive"]'),...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(a=>{let b=a.id||a.getAttribute("src");o.add(b)})}function s(a){let{id:b,src:c="",onLoad:d=()=>{},onReady:e=null,strategy:f="afterInteractive",onError:g,stylesheets:l,...n}=a,{updateScripts:q,scripts:r,getIsSsr:s,appDir:t,nonce:u}=(0,j.useContext)(k.HeadManagerContext);u=n.nonce||u;let v=(0,j.useRef)(!1);(0,j.useEffect)(()=>{let a=b||c;v.current||(e&&a&&o.has(a)&&e(),v.current=!0)},[e,b,c]);let w=(0,j.useRef)(!1);if((0,j.useEffect)(()=>{if(!w.current){if("afterInteractive"===f)p(a);else"lazyOnload"===f&&("complete"===document.readyState?(0,m.requestIdleCallback)(()=>p(a)):window.addEventListener("load",()=>{(0,m.requestIdleCallback)(()=>p(a))}));w.current=!0}},[a,f]),("beforeInteractive"===f||"worker"===f)&&(q?(r[f]=(r[f]||[]).concat([{id:b,src:c,onLoad:d,onReady:e,onError:g,...n,nonce:u}]),q(r)):s&&s()?o.add(b||c):s&&!s()&&p({...a,nonce:u})),t){if(l&&l.forEach(a=>{i.default.preinit(a,{as:"style"})}),"beforeInteractive"===f)if(!c)return n.dangerouslySetInnerHTML&&(n.children=n.dangerouslySetInnerHTML.__html,delete n.dangerouslySetInnerHTML),(0,h.jsx)("script",{nonce:u,dangerouslySetInnerHTML:{__html:`(self.__next_s=self.__next_s||[]).push(${JSON.stringify([0,{...n,id:b}])})`}});else return i.default.preload(c,n.integrity?{as:"script",integrity:n.integrity,nonce:u,crossOrigin:n.crossOrigin}:{as:"script",nonce:u,crossOrigin:n.crossOrigin}),(0,h.jsx)("script",{nonce:u,dangerouslySetInnerHTML:{__html:`(self.__next_s=self.__next_s||[]).push(${JSON.stringify([c,{...n,id:b}])})`}});"afterInteractive"===f&&c&&i.default.preload(c,n.integrity?{as:"script",integrity:n.integrity,nonce:u,crossOrigin:n.crossOrigin}:{as:"script",nonce:u,crossOrigin:n.crossOrigin})}return null}Object.defineProperty(s,"__nextScript",{value:!0});let t=s;("function"==typeof c.default||"object"==typeof c.default&&null!==c.default)&&void 0===c.default.__esModule&&(Object.defineProperty(c.default,"__esModule",{value:!0}),Object.assign(c.default,c),b.exports=c.default)},47283,(a,b,c)=>{b.exports=a.r(96665)},44692,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(47283),e=a.i(38679),f=a.i(783);let g=[{id:"video-1",title:"Давлианидзе Татьяна Алексеевна",description:"Массовое разведение насекомых в лаборатории: от яйца до тест-объекта в исследовании эффективности инсектицидов · младший научный сотрудник Института дезинфектологии ФБУН «ФНЦГ им. Ф.Ф. Эрисмана» Роспотребнадзора",password:"glpplanet2026",videoSrc:"/videos/SVID_20260605_054509_1.mp4"},{id:"video-2",title:"Dasha Fuentes, CENPALAB — Vaxira",description:"Conferencia Evento Rusia 2026 preclínica Vaxira · видеодоклад",password:"glpplanet2026",videoSrc:"/videos/Conferencia Evento Rusia 2026 preclínica Vaxira p.mp4"}],h="glp_unlocked_videos_v1";function i(){let[a,d]=(0,c.useState)({}),[e,f]=(0,c.useState)({}),[i,j]=(0,c.useState)({}),[k,l]=(0,c.useState)(null),[m,n]=(0,c.useState)(!1);(0,c.useEffect)(()=>{n(!0);try{let a=localStorage.getItem(h);a&&d(JSON.parse(a))}catch{}},[]);let o=b=>{if((e[b.id]||"").trim()===b.password){let c={...a,[b.id]:!0};d(c);try{localStorage.setItem(h,JSON.stringify(c))}catch{}l(null),f({...e,[b.id]:""})}else j({...i,[b.id]:!0}),setTimeout(()=>j(a=>({...a,[b.id]:!1})),1200)};return(0,b.jsxs)("section",{className:"pv-section",children:[(0,b.jsxs)("div",{className:"pv-container",children:[(0,b.jsxs)("div",{className:"pv-header",children:[(0,b.jsx)("div",{className:"pv-label",children:"Записи"}),(0,b.jsx)("h2",{className:"pv-title",children:"Видео доклады"}),(0,b.jsx)("p",{className:"pv-subtitle",children:"Для доступа к каждой записи введите пароль участника"})]}),(0,b.jsx)("div",{className:"pv-grid",children:g.map(c=>{let d=m&&!!a[c.id],g=k===c.id,h=!!i[c.id];return(0,b.jsxs)("div",{className:"pv-card",children:[(0,b.jsx)("div",{className:"pv-frame",children:d&&"presentation"===c.fileType?(0,b.jsxs)("div",{className:"pv-file",children:[(0,b.jsx)("div",{className:"pv-file-icon",children:"PPTX"}),(0,b.jsxs)("div",{className:"pv-file-actions",children:[(0,b.jsx)("a",{className:"pv-file-btn",href:c.videoSrc,target:"_blank",rel:"noreferrer",children:"Открыть презентацию"}),(0,b.jsx)("a",{className:"pv-file-link",href:c.videoSrc,download:!0,children:"Скачать файл"})]})]}):d?(0,b.jsx)("video",{src:c.videoSrc,controls:!0,controlsList:"nodownload",playsInline:!0,className:"pv-video",poster:c.thumbnail}):(0,b.jsxs)("div",{className:"pv-locked",children:[(0,b.jsx)("div",{className:"pv-locked-bg",style:c.thumbnail?{backgroundImage:`url(${c.thumbnail})`}:{}}),(0,b.jsx)("div",{className:"pv-locked-overlay"}),g?(0,b.jsxs)("div",{className:"pv-form",onClick:a=>a.stopPropagation(),children:[(0,b.jsx)("input",{type:"password",placeholder:"Пароль",value:e[c.id]||"",onChange:a=>f({...e,[c.id]:a.target.value}),onKeyDown:a=>{"Enter"===a.key&&o(c),"Escape"===a.key&&l(null)},autoFocus:!0,className:`pv-input ${h?"pv-input-error":""}`}),(0,b.jsx)("button",{type:"button",className:"pv-submit-btn",onClick:()=>o(c),children:(0,b.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,b.jsx)("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),(0,b.jsx)("polyline",{points:"12,5 19,12 12,19"})]})})]}):(0,b.jsxs)("button",{type:"button",className:"pv-unlock-btn",onClick:()=>l(c.id),children:[(0,b.jsx)("div",{className:"pv-lock-icon",children:(0,b.jsxs)("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,b.jsx)("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2"}),(0,b.jsx)("path",{d:"M7 11V7a5 5 0 0110 0v4"})]})}),(0,b.jsx)("span",{className:"pv-unlock-text",children:"Введите пароль"})]})]})}),(0,b.jsxs)("div",{className:"pv-info",children:[(0,b.jsx)("h3",{className:"pv-card-title",children:c.title}),c.description&&(0,b.jsx)("p",{className:"pv-card-desc",children:c.description})]})]},c.id)})})]}),(0,b.jsx)("style",{children:`
                .pv-section {
                    padding: 60px 48px 100px;
                    background: #141B4D;
                }
                .pv-container { max-width: 1240px; margin: 0 auto; }

                .pv-header { margin-bottom: 40px; }
                .pv-label {
                    font-size: 11px; color: #6B82C4; font-weight: 600;
                    text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px;
                }
                .pv-title {
                    font-size: 32px; font-weight: 700; color: #fff;
                    line-height: 1.2; margin: 0 0 12px;
                }
                .pv-subtitle {
                    font-size: 14px; color: rgba(255,255,255,0.5);
                    line-height: 1.6; max-width: 500px; margin: 0;
                }

                .pv-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 24px;
                }

                .pv-card {
                    background: rgba(8,12,36,0.4);
                    border: 1px solid rgba(107,130,196,0.15);
                    border-radius: 8px;
                    overflow: hidden;
                    transition: border-color 0.3s, transform 0.3s;
                }
                .pv-card:hover {
                    border-color: rgba(107,130,196,0.3);
                    transform: translateY(-3px);
                }

                .pv-frame {
                    position: relative;
                    width: 100%;
                    aspect-ratio: 16 / 9;
                    overflow: hidden;
                    background: #000;
                }
                .pv-video {
                    position: absolute;
                    inset: 0;
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                    background: #000;
                    display: block;
                }
                .pv-file {
                    position: absolute;
                    inset: 0;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    gap: 18px;
                    padding: 22px;
                    background:
                        radial-gradient(circle at 50% 30%, rgba(107,130,196,0.28), transparent 48%),
                        linear-gradient(135deg, #101740 0%, #1b2460 100%);
                }
                .pv-file-icon {
                    width: 78px;
                    height: 78px;
                    border-radius: 8px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: rgba(255,255,255,0.1);
                    border: 1px solid rgba(255,255,255,0.18);
                    color: #fff;
                    font-size: 15px;
                    font-weight: 700;
                    letter-spacing: 1px;
                }
                .pv-file-actions {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    flex-wrap: wrap;
                    justify-content: center;
                }
                .pv-file-btn,
                .pv-file-link {
                    min-height: 40px;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 5px;
                    font-family: 'Exo 2', sans-serif;
                    font-size: 13px;
                    font-weight: 600;
                    text-decoration: none;
                    transition: background 0.25s, border-color 0.25s;
                }
                .pv-file-btn {
                    padding: 0 18px;
                    background: var(--secondary, #4964A2);
                    color: #fff;
                }
                .pv-file-btn:hover { background: #6B82C4; }
                .pv-file-link {
                    padding: 0 14px;
                    border: 1px solid rgba(255,255,255,0.18);
                    color: rgba(255,255,255,0.76);
                    background: rgba(255,255,255,0.04);
                }
                .pv-file-link:hover {
                    border-color: rgba(255,255,255,0.34);
                    background: rgba(255,255,255,0.08);
                }

                .pv-locked {
                    position: absolute;
                    inset: 0;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .pv-locked-bg {
                    position: absolute;
                    inset: -10px;
                    background: linear-gradient(135deg, #1a2460 0%, #2a3680 50%, #141B4D 100%);
                    background-size: cover;
                    background-position: center;
                    filter: blur(14px);
                    transform: scale(1.1);
                }
                .pv-locked-overlay {
                    position: absolute;
                    inset: 0;
                    background:
                        radial-gradient(circle at center, transparent 0%, rgba(8,12,36,0.6) 100%),
                        repeating-linear-gradient(45deg, transparent 0 8px, rgba(255,255,255,0.02) 8px 9px);
                }

                .pv-unlock-btn {
                    position: relative;
                    z-index: 2;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 12px;
                    padding: 16px 28px;
                    background: rgba(8,12,36,0.65);
                    backdrop-filter: blur(10px);
                    -webkit-backdrop-filter: blur(10px);
                    border: 1px solid rgba(107,130,196,0.35);
                    border-radius: 8px;
                    color: #fff;
                    cursor: pointer;
                    font-family: 'Exo 2', sans-serif;
                    transition: all 0.3s;
                }
                .pv-unlock-btn:hover {
                    border-color: #6B82C4;
                    background: rgba(20,27,77,0.85);
                    transform: translateY(-2px);
                }
                .pv-lock-icon {
                    width: 44px; height: 44px;
                    border-radius: 50%;
                    background: rgba(107,130,196,0.18);
                    color: #6B82C4;
                    display: flex; align-items: center; justify-content: center;
                }
                .pv-unlock-text {
                    font-size: 12px;
                    font-weight: 600;
                    letter-spacing: 1.5px;
                    text-transform: uppercase;
                    color: rgba(255,255,255,0.85);
                }

                .pv-form {
                    position: relative;
                    z-index: 2;
                    display: flex;
                    gap: 6px;
                    align-items: center;
                    padding: 8px;
                    background: rgba(8,12,36,0.85);
                    backdrop-filter: blur(14px);
                    -webkit-backdrop-filter: blur(14px);
                    border: 1px solid rgba(107,130,196,0.4);
                    border-radius: 8px;
                    width: min(86%, 320px);
                }
                .pv-input {
                    flex: 1;
                    min-width: 0;
                    padding: 10px 14px;
                    background: rgba(255,255,255,0.05);
                    border: 1px solid rgba(107,130,196,0.25);
                    border-radius: 5px;
                    color: #fff;
                    font-family: 'Exo 2', sans-serif;
                    font-size: 14px;
                    outline: none;
                    transition: all 0.25s;
                }
                .pv-input:focus {
                    border-color: #6B82C4;
                    background: rgba(255,255,255,0.08);
                }
                .pv-input::placeholder {
                    color: rgba(255,255,255,0.35);
                }
                .pv-input-error {
                    border-color: #e15a5a !important;
                    animation: pvShake 0.4s;
                }
                @keyframes pvShake {
                    0%, 100% { transform: translateX(0); }
                    20%, 60% { transform: translateX(-4px); }
                    40%, 80% { transform: translateX(4px); }
                }
                .pv-submit-btn {
                    flex-shrink: 0;
                    width: 38px; height: 38px;
                    display: flex; align-items: center; justify-content: center;
                    background: var(--secondary, #4964A2);
                    border: none;
                    border-radius: 5px;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.25s;
                }
                .pv-submit-btn:hover { background: #6B82C4; }

                .pv-info {
                    padding: 18px 20px 22px;
                }
                .pv-card-title {
                    font-size: 16px;
                    font-weight: 700;
                    color: #fff;
                    margin: 0 0 6px;
                    line-height: 1.35;
                }
                .pv-card-desc {
                    font-size: 13px;
                    color: rgba(255,255,255,0.5);
                    line-height: 1.55;
                    margin: 0;
                }

                @media (max-width: 1024px) {
                    .pv-section { padding: 50px 32px 80px; }
                    .pv-title { font-size: 28px; }
                    .pv-grid { gap: 20px; }
                }
                @media (max-width: 768px) {
                    .pv-grid { grid-template-columns: 1fr 1fr; }
                }
                @media (max-width: 600px) {
                    .pv-section { padding: 36px 16px 56px; }
                    .pv-header { margin-bottom: 28px; }
                    .pv-title { font-size: 22px; }
                    .pv-subtitle { font-size: 13px; }
                    .pv-grid { grid-template-columns: 1fr; gap: 16px; }
                    .pv-info { padding: 14px 16px 18px; }
                    .pv-card-title { font-size: 15px; }
                    .pv-card-desc { font-size: 12px; }
                    .pv-unlock-btn { padding: 14px 22px; }
                    .pv-lock-icon { width: 38px; height: 38px; }
                    .pv-unlock-text { font-size: 11px; }
                }
            `})]})}let j=[{hash:"YpiOqOhG",activityId:"10741",label:"1. Зал «Санкт-Петербург»"},{hash:"QXbaznQV",activityId:"10742",label:"2. Зал «Стрельна»"},{hash:"liBQmque",activityId:"10743",label:"3. Зал «Выборг»"}],k="platform";a.s(["default",0,function(){let[a,g]=(0,c.useState)(j[0].hash),h=(0,c.useRef)(null);return(0,c.useEffect)(()=>{let b=h.current;if(!b)return;let c=j.find(b=>b.hash===a);if(!c)return;let d=`pml-iframe-container-${c.hash}-${k}`,e=`pml-iframe-${c.hash}-${k}`,f=`https://embed-cdn.mashroom.online/?hash=${c.hash}`,g=document.createElement("div");g.setAttribute("id",d),g.setAttribute("iframe-name",e),g.setAttribute("src",f),g.setAttribute("mode",k),g.setAttribute("activity-id",c.activityId),g.classList.add(`pml-container-iframe-${k}`),b.innerHTML="",b.appendChild(g);let i=null,l=()=>!!window.initIframe&&(window.initIframe(d),!0);return l()||(i=setInterval(()=>{l()&&i&&clearInterval(i)},50)),()=>{if(i&&clearInterval(i),window.destroyIframe)try{window.destroyIframe(e)}catch{}}},[a]),(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(e.default,{}),(0,b.jsxs)("main",{className:"bc-main",children:[(0,b.jsx)("section",{className:"bc-hero",children:(0,b.jsxs)("div",{className:"bc-container",children:[(0,b.jsx)("div",{className:"bc-label",children:"Онлайн"}),(0,b.jsx)("h1",{className:"bc-title",children:"Трансляция конференции"}),(0,b.jsx)("p",{className:"bc-subtitle",children:"Прямая трансляция и записи сессий VII Международной научно-практической конференции GLP-PLANET"}),(0,b.jsxs)("a",{href:"/schedule",target:"_blank",rel:"noopener noreferrer",className:"bc-schedule-btn",children:[(0,b.jsxs)("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,b.jsx)("rect",{x:"3",y:"4",width:"18",height:"18",rx:"2"}),(0,b.jsx)("line",{x1:"16",y1:"2",x2:"16",y2:"6"}),(0,b.jsx)("line",{x1:"8",y1:"2",x2:"8",y2:"6"}),(0,b.jsx)("line",{x1:"3",y1:"10",x2:"21",y2:"10"})]}),(0,b.jsx)("span",{children:"Онлайн расписание"})]})]})}),(0,b.jsx)("section",{className:"bc-player-section",children:(0,b.jsxs)("div",{className:"bc-container",children:[(0,b.jsx)("div",{className:"bc-player-wrap",children:(0,b.jsxs)("div",{className:"tabs",children:[(0,b.jsx)("div",{className:"tabs__controls",children:j.map(c=>(0,b.jsx)("button",{type:"button",className:`tabs__control${c.hash===a?" active":""}`,onClick:()=>g(c.hash),children:c.label},c.hash))}),(0,b.jsx)("div",{className:"tabs__content",children:(0,b.jsx)("div",{className:"bc-player-frame",children:(0,b.jsx)("div",{ref:h})})})]})}),(0,b.jsx)("div",{className:"bc-info",children:(0,b.jsxs)("div",{className:"bc-info-card",children:[(0,b.jsx)("div",{className:"bc-info-icon",children:(0,b.jsxs)("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,b.jsx)("circle",{cx:"12",cy:"12",r:"10"}),(0,b.jsx)("line",{x1:"12",y1:"6",x2:"12",y2:"12"}),(0,b.jsx)("line",{x1:"12",y1:"12",x2:"16",y2:"14"})]})}),(0,b.jsx)("div",{className:"bc-info-text",children:"Если плеер не загружается — обновите страницу или попробуйте отключить блокировщик рекламы"})]})})]})}),(0,b.jsx)(i,{})]}),(0,b.jsx)(f.default,{}),(0,b.jsx)("link",{rel:"stylesheet",href:"https://embed-cdn.mashroom.online/iframe/css/index.css"}),(0,b.jsx)(d.default,{src:"https://embed-cdn.mashroom.online/iframe/js/index.js",strategy:"afterInteractive"}),(0,b.jsx)("style",{children:`
        .bc-main {
          min-height: 100vh;
          background: #141B4D;
        }
        .bc-container { max-width: 1240px; margin: 0 auto; }

        .bc-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 100%);
        }
        .bc-label {
          font-size: 11px; color: #6B82C4; font-weight: 600;
          text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px;
        }
        .bc-title {
          font-size: 42px; font-weight: 700; color: #fff;
          line-height: 1.2; margin-bottom: 16px;
        }
        .bc-subtitle {
          font-size: 15px; color: rgba(255,255,255,0.6); line-height: 1.7;
          max-width: 600px;
        }
        .bc-schedule-btn {
          display: inline-flex; align-items: center; gap: 10px;
          margin-top: 24px; padding: 12px 24px;
          border: 1px solid #559CD6; border-radius: 4px;
          background: transparent; color: #fff;
          font-size: 15px; font-weight: 600; text-decoration: none;
          transition: all 0.2s ease;
        }
        .bc-schedule-btn:hover { background: #559CD6; }
        .bc-schedule-btn svg { flex-shrink: 0; color: #559CD6; transition: color 0.2s ease; }
        .bc-schedule-btn:hover svg { color: #fff; }

        .bc-player-section {
          padding: 50px 48px 100px;
          background: #141B4D;
        }

        .bc-player-wrap {
          width: 100%;
          max-width: 1240px;
          margin: 0 auto 32px;
          border-radius: 8px;
          background: #000;
          box-shadow: 0 30px 80px rgba(0,0,0,0.4);
          border: 1px solid rgba(107,130,196,0.15);
        }

        .tabs {
          --border-color: #559CD6;
          --bg-color: #FFFFFF;
          --text-color: #559CD6;
          --bg-active-color: #559CD6;
          --text-active-color: #FFFFFF;
        }
        .tabs__controls {
          display: flex;
          flex-wrap: wrap;
        }
        .tabs__control {
          position: relative;
          padding: 8px 24px;
          flex: 1 50%;
          font-size: 20px;
          line-height: 1.6;
          color: var(--text-color);
          letter-spacing: 0.9px;
          text-transform: uppercase;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          border: none;
          box-shadow: 0 0 0 1px var(--border-color);
          background-color: var(--bg-color);
          border-radius: 0;
          cursor: pointer;
          transition: background-color 0.2s ease, color 0.2s ease;
        }
        .tabs__content {
          margin-top: 1px;
          width: 100%;
        }
        .tabs__control.active {
          cursor: initial;
          color: var(--text-active-color);
          background-color: var(--bg-active-color);
        }
        @media (min-width: 1024px) {
          .tabs__control {
            flex: 1 20%;
          }
        }

        .bc-player-frame {
          width: 100%;
        }
        .bc-player-frame > div {
          width: 100%;
        }
        .bc-player-frame iframe {
          width: 100% !important;
          border: 0;
          display: block;
        }

        .bc-info {
          display: flex;
          flex-direction: column;
          gap: 12px;
          max-width: 1240px;
          margin: 0 auto;
        }
        .bc-info-card {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          padding: 16px 20px;
          background: rgba(73,100,162,0.1);
          border: 1px solid rgba(107,130,196,0.18);
          border-left: 3px solid #6B82C4;
          border-radius: 4px;
        }
        .bc-info-icon {
          flex-shrink: 0;
          width: 36px; height: 36px;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          background: rgba(107,130,196,0.18);
          color: #6B82C4;
        }
        .bc-info-text {
          font-size: 13px;
          color: rgba(255,255,255,0.7);
          line-height: 1.6;
          padding-top: 7px;
        }

        @media (max-width: 1024px) {
          .bc-hero { padding: 120px 32px 48px; }
          .bc-title { font-size: 34px; }
          .bc-player-section { padding: 40px 32px 70px; }
          .tabs__control { font-size: 16px; padding: 8px 16px; }
        }
        @media (max-width: 768px) {
          .tabs__control { font-size: 14px; padding: 8px 12px; letter-spacing: 0.5px; }
        }
        @media (max-width: 600px) {
          .bc-hero { padding: 100px 20px 36px; }
          .bc-label { font-size: 10px; letter-spacing: 2px; }
          .bc-title { font-size: 26px; margin-bottom: 12px; }
          .bc-subtitle { font-size: 14px; line-height: 1.65; }
          .bc-player-section { padding: 28px 16px 56px; }
          .bc-player-wrap { border-radius: 6px; margin-bottom: 20px; }
          .bc-info-card { padding: 14px 16px; gap: 12px; }
          .bc-info-icon { width: 32px; height: 32px; }
          .bc-info-icon svg { width: 16px; height: 16px; }
          .bc-info-text { font-size: 12px; padding-top: 5px; }
          .tabs__control { font-size: 12px; padding: 6px 8px; letter-spacing: 0.3px; }
        }
      `})]})}],44692)}];

//# sourceMappingURL=_10rbqe4._.js.map