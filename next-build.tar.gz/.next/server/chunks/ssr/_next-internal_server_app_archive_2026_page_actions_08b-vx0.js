module.exports=[42408,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2026_page_actions_08b-vx0.js.map