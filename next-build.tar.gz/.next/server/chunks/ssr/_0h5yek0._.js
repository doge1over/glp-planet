module.exports=[38067,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Header.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Header.tsx <module evaluation>","default")},16100,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Header.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Header.tsx","default")},21680,a=>{"use strict";a.i(38067);var b=a.i(16100);a.n(b)},40471,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Footer.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx <module evaluation>","default")},34497,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Footer.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx","default")},91677,a=>{"use strict";a.i(40471);var b=a.i(34497);a.n(b)},84698,a=>{"use strict";var b=a.i(7997),c=a.i(21680),d=a.i(91677);let e=[{author:"Соттаева М.М.",title:"Доклад"},{author:"Шохин И., Колганова",title:"Доклад"},{author:"Завьялов Е.Л.",title:"Доклад"},{author:"Мурашев А.Н.",title:"Доклад"},{author:"Макарова М.Н.",title:"Доклад"},{author:"Енгалычева Г.Н.",title:"Доклад"},{author:"Попов В.С.",title:"Доклад"},{author:"Тулегенова А.У.",title:"Доклад"},{author:"Шнаукшта В.С.",title:"Доклад"},{author:"Ситко Т.И.",title:"Доклад"},{author:"Рождественский Д.А.",title:"Доклад"},{author:"Гордейчук И.",title:"Доклад"},{author:"Макаров В.Г.",title:"Доклад"},{author:"Устюгов А.А.",title:"Доклад"},{author:"Абрамович Р.А.",title:"Доклад"},{author:"Флисюк Е.В.",title:"Доклад"},{author:"Матвеев А.В.",title:"Доклад"},{author:"Гришина Ю.И.",title:"Доклад"},{author:"Чудинова Е.С.",title:"Доклад"},{author:"Дейкин А.",title:"Доклад"},{author:"Крышень К.Л.",title:"Доклад"},{author:"Исакова-Сивак И.Н.",title:"Доклад"},{author:"Гремякова П.В.",title:"Доклад"},{author:"Косман В.М.",title:"Доклад"},{author:"Карлина М.В.",title:"Доклад"},{author:"Тернинко И.И.",title:"Доклад"},{author:"Устенко Ж.Ю.",title:"Доклад"},{author:"Родионова Н.В.",title:"Доклад"},{author:"Гуляева Е.П.",title:"Доклад"},{author:"Кузнецова А.И.",title:"Доклад"},{author:"Кириченко",title:"Доклад"},{author:"Саканян К.М.",title:"Доклад"},{author:"Фальковский И.В.",title:"Доклад"},{author:"Ловат М.Л.",title:"Доклад"},{author:"Акимов Д.Ю.",title:"Доклад"},{author:"Акимова М.А.",title:"Доклад"},{author:"Волков А.В.",title:"Доклад"},{author:"Салминьш Д.",title:"Доклад"},{author:"Литвинова Е.А.",title:"Доклад"},{author:"Карал-оглы Д.Д.",title:"Доклад"},{author:"Добрянская С.С.",title:"Доклад"},{author:"Аверина О.А.",title:"Доклад"},{author:"Кушнир Е.А.",title:"Доклад"},{author:"Усатов А.В.",title:"Доклад"},{author:"Фаустова Н.М.",title:"Доклад"},{author:"Мирошников М.В.",title:"Доклад"},{author:"Васютина М.Л.",title:"Доклад"},{author:"Гущин Я.А.",title:"Доклад"},{author:"Торопова Я.Г.",title:"Доклад"},{author:"Ивкин Д.Ю.",title:"Доклад"},{author:"Хан С.О.",title:"Доклад"},{author:"Караваева А.В.",title:"Доклад"},{author:"Билялетдинова М.М.",title:"Доклад"},{author:"Березкин В.А.",title:"Доклад"},{author:"Ковалева М.А.",title:"ARRIVE"},{author:"Ильинский Н.С.",title:"Доклад"},{author:"Ходько С.В.",title:"Доклад"},{author:"Матуа А.З.",title:"Доклад"},{author:"Корель А.В.",title:"Доклад"},{author:"Галагудза М.М.",title:"Доклад"},{author:"Самохин А.Г.",title:"Доклад"},{author:"Сергеева М.В.",title:"Доклад"},{author:"Рудько О.И.",title:"Доклад"},{author:"Буренков П.В.",title:"Доклад"},{author:"Покровский М.В.",title:"Доклад"},{author:"Тюренков И.В.",title:"Доклад"},{author:"Суханов И.М.",title:"Доклад"},{author:"Чалов С.Е.",title:"Доклад"},{author:"Бондарева Е.Д.",title:"Доклад"},{author:"Кривцов А.",title:"Доклад"},{author:"Ниязов Р.Р.",title:"Доклад"},{author:"Чалов С.Е.",title:"Доклад (2)"},{author:"Саяхов Р.",title:"Доклад"},{author:"Шипаева Е.В.",title:"Доклад"}];a.s(["default",0,function(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(c.default,{}),(0,b.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,b.jsx)("section",{className:"conf-hero",children:(0,b.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,b.jsx)("div",{className:"conf-hero-label",children:"III Конференция · 2022"}),(0,b.jsx)("h1",{className:"conf-hero-title",children:"GLP-Planet конференция 3.0"}),(0,b.jsxs)("div",{className:"conf-hero-meta",children:[(0,b.jsx)("span",{children:"30 июня – 1 июля 2022"}),(0,b.jsx)("span",{className:"conf-hero-dot",children:"·"}),(0,b.jsx)("span",{children:"г. Санкт-Петербург, Россия"})]})]})}),(0,b.jsx)("section",{className:"conf-about",children:(0,b.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,b.jsx)("h2",{className:"conf-section-title",children:"О конференции"}),(0,b.jsx)("div",{className:"conf-divider"}),(0,b.jsxs)("div",{className:"conf-text",children:[(0,b.jsxs)("p",{children:["30.06 — 01.07. 2022 г. в Санкт-Петербурге прошла ",(0,b.jsx)("strong",{children:"III Международная научная конференция GLP-PLANET"}),". В работе конференции приняли участие научно-исследовательские институты и испытательные центры, фармацевтические компании, независимые эксперты и представители регуляторных органов из ",(0,b.jsx)("strong",{children:"30 городов России"}),", а также Абхазии, Армении, Беларуси, Казахстана и США. Конференция собрала более ",(0,b.jsx)("strong",{children:"380 человек"}),"."]}),(0,b.jsx)("p",{children:"Участники подробно обсудили достижения и ближайшие цели GxP для устойчивого развития фармацевтической отрасли в ЕАЭС. Особый интерес у слушателей вызвали темы методики поиска альтернативных методов исследования, возможности использования метаанализа для планирования доклинических исследований, применения принципов ARRIVE для проведения исследований и повышения качества заключительных отчётов, опыт исследований COVID-19, а также вопросы зоотехнии и ветеринарного обеспечения."}),(0,b.jsx)("p",{children:"В этом году в рамках конференции прошли сразу четыре мастер-класса:"}),(0,b.jsxs)("ul",{className:"conf-list",children:[(0,b.jsx)("li",{children:"Альтернативные методы исследования"}),(0,b.jsx)("li",{children:"Оценка степени тяжести экспериментальных процедур в исследованиях на животных"}),(0,b.jsx)("li",{children:"Основы работы с оборудованием в зоне содержания лабораторных животных"}),(0,b.jsx)("li",{children:"Предоперационное и послеоперационное содержание лабораторных животных"})]}),(0,b.jsx)("p",{children:"Участники получили не только знания и практические навыки, но и ценные подарки. По результатам голосования участников состоялось награждение лучших лекторов."}),(0,b.jsx)("p",{children:(0,b.jsx)("strong",{children:"Мы благодарим всех участников мероприятия за активное участие и спонсоров — за поддержку конференции!"})})]})]})}),(0,b.jsx)("section",{id:"materials",className:"conf-materials",children:(0,b.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,b.jsx)("h2",{className:"conf-section-title",children:"Материалы конференции"}),(0,b.jsx)("div",{className:"conf-materials-grid",children:e.map((a,c)=>(0,b.jsxs)("div",{className:"conf-material-card",children:[(0,b.jsxs)("div",{className:"conf-material-placeholder",children:[(0,b.jsxs)("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1",strokeLinecap:"round",strokeLinejoin:"round",style:{opacity:.4},children:[(0,b.jsx)("path",{d:"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"}),(0,b.jsx)("polyline",{points:"14,2 14,8 20,8"}),(0,b.jsx)("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),(0,b.jsx)("line",{x1:"16",y1:"17",x2:"8",y2:"17"}),(0,b.jsx)("polyline",{points:"10,9 9,9 8,9"})]}),(0,b.jsx)("span",{children:"PDF"})]}),(0,b.jsxs)("div",{className:"conf-material-info",children:[(0,b.jsx)("div",{className:"conf-material-author",children:a.author}),(0,b.jsx)("div",{className:"conf-material-title",children:a.title})]})]},c))})]})})]}),(0,b.jsx)(d.default,{}),(0,b.jsx)("style",{children:`
                .conf-hero {
                    padding: 140px 48px 60px;
                    background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
                }
                .conf-hero-label {
                    font-size: 11px; color: #6B82C4; font-weight: 600;
                    text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px;
                }
                .conf-hero-title {
                    font-size: 42px; font-weight: 700; color: #fff;
                    line-height: 1.2; margin-bottom: 16px;
                }
                .conf-hero-meta {
                    font-size: 15px; color: rgba(255,255,255,0.4);
                    display: flex; align-items: center; gap: 0;
                }
                .conf-hero-dot {
                    margin: 0 10px; color: #6B82C4;
                }

                .conf-about {
                    padding: 80px 48px;
                    background: linear-gradient(155deg, #0D1330 0%, #141B4D 50%, #1A2460 100%);
                }
                .conf-section-title {
                    font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 16px;
                }
                .conf-divider {
                    width: 40px; height: 3px; background: var(--secondary);
                    border-radius: 1px; margin-bottom: 32px;
                }
                .conf-text { color: rgba(255,255,255,0.55); font-size: 15px; line-height: 1.85; }
                .conf-text p { margin-bottom: 16px; }
                .conf-text strong { color: rgba(255,255,255,0.8); }
                .conf-list {
                    list-style: none; padding: 0; margin: 0 0 16px 0;
                }
                .conf-list li {
                    position: relative; padding-left: 20px; margin-bottom: 8px;
                    color: rgba(255,255,255,0.55); font-size: 15px; line-height: 1.6;
                }
                .conf-list li::before {
                    content: ''; position: absolute; left: 0; top: 10px;
                    width: 6px; height: 6px; border-radius: 50%;
                    background: var(--secondary);
                }

                .conf-materials {
                    padding: 80px 48px 100px;
                    background: #fff;
                }
                .conf-materials .conf-section-title { color: var(--primary); margin-bottom: 36px; }
                .conf-materials-grid {
                    display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;
                }
                .conf-material-card {
                    border: 1px solid rgba(73,100,162,0.08); border-radius: 6px;
                    overflow: hidden; display: block;
                    transition: all 0.5s cubic-bezier(0.33,1,0.68,1);
                    cursor: default;
                }
                .conf-material-card:hover {
                    transform: translateY(-4px);
                    box-shadow: 0 16px 40px rgba(20,27,77,0.08);
                    border-color: rgba(73,100,162,0.15);
                }
                .conf-material-placeholder {
                    aspect-ratio: 1.33; background: var(--light);
                    display: flex; flex-direction: column; align-items: center;
                    justify-content: center; gap: 8px; color: var(--muted);
                    font-size: 11px; font-weight: 600; letter-spacing: 2px;
                }
                .conf-material-info { padding: 16px 18px; }
                .conf-material-author {
                    font-size: 13px; font-weight: 700; color: var(--primary); margin-bottom: 4px;
                }
                .conf-material-title {
                    font-size: 12px; color: #666; line-height: 1.5;
                }

                @media (max-width: 1024px) {
                    .conf-hero { padding: 120px 32px 48px; }
                    .conf-hero-title { font-size: 34px; }
                    .conf-about { padding: 60px 32px; }
                    .conf-materials { padding: 60px 32px 80px; }
                }
                @media (max-width: 900px) {
                    .conf-materials-grid { grid-template-columns: 1fr 1fr; }
                }
                @media (max-width: 600px) {
                    .conf-hero { padding: 100px 20px 40px; }
                    .conf-hero-title { font-size: 28px; }
                    .conf-hero-meta { flex-direction: column; align-items: flex-start; gap: 4px; font-size: 13px; }
                    .conf-hero-dot { display: none; }
                    .conf-about { padding: 48px 20px; }
                    .conf-text { font-size: 14px; }
                    .conf-materials { padding: 40px 20px 60px; }
                    .conf-materials-grid { grid-template-columns: 1fr; }
                    .conf-section-title { font-size: 24px; }
                }
            `})]})},"metadata",0,{title:"GLP-Planet конференция 2022 — GLP-Planet",description:"III Международная научная конференция GLP-Planet, 30 июня – 1 июля 2022 г., Санкт-Петербург"}])},60295,a=>{a.n(a.i(84698))}];

//# sourceMappingURL=_0h5yek0._.js.map