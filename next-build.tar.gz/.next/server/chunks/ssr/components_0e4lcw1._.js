module.exports=[57005,a=>{"use strict";var b=a.i(87924),c=a.i(72131);let d=a=>a*Math.PI/180,e=[{lat:59.94,lon:30.31,label:"Санкт-Петербург",offsetX:14,offsetY:-18},{lat:55.75,lon:37.62,label:"Москва",offsetX:14,offsetY:-10},{lat:53.9,lon:27.57,label:"Беларусь",offsetX:-14,offsetY:-12},{lat:40.18,lon:44.51,label:"Армения",offsetX:14,offsetY:-10},{lat:43,lon:41.02,label:"Абхазия",offsetX:-14,offsetY:-10},{lat:41.72,lon:44.79,label:"Грузия",offsetX:14,offsetY:14},{lat:51.17,lon:71.43,label:"Казахстан",offsetX:14,offsetY:-14},{lat:41.31,lon:69.28,label:"Узбекистан",offsetX:14,offsetY:14},{lat:51.51,lon:-.13,label:"Великобритания",offsetX:-14,offsetY:-18},{lat:48.86,lon:2.35,label:"Франция",offsetX:-14,offsetY:14},{lat:52.52,lon:13.41,label:"Германия",offsetX:14,offsetY:16},{lat:50.85,lon:4.35,label:"Бельгия",offsetX:-14,offsetY:16},{lat:55.68,lon:12.57,label:"Дания",offsetX:-14,offsetY:-16},{lat:40.42,lon:-3.7,label:"Испания",offsetX:-14,offsetY:-14},{lat:41.9,lon:12.5,label:"Италия",offsetX:-14,offsetY:-10},{lat:46.95,lon:7.45,label:"Швейцария",offsetX:-14,offsetY:16},{lat:44.82,lon:20.46,label:"Сербия",offsetX:14,offsetY:12},{lat:39.9,lon:116.4,label:"Китай",offsetX:14,offsetY:-12},{lat:28.61,lon:77.21,label:"Индия",offsetX:14,offsetY:-12},{lat:38.91,lon:-77.04,label:"США",offsetX:-14,offsetY:-14},{lat:23.11,lon:-82.37,label:"Куба",offsetX:-14,offsetY:12},{lat:-33.93,lon:18.42,label:"ЮАР",offsetX:14,offsetY:14}].map(a=>({cosLat:Math.cos(d(a.lat)),sinLat:Math.sin(d(a.lat)),lonR:d(a.lon),label:a.label,offsetX:a.offsetX,offsetY:a.offsetY}));function f({size:a=440}){let g=(0,c.useRef)(null),h=(0,c.useRef)(0),i=(0,c.useRef)(0),j=(0,c.useRef)([]),k=(0,c.useRef)(!1),[l,m]=(0,c.useState)(!1);(0,c.useEffect)(()=>{let b=g.current;if(!b||k.current)return;k.current=!0;let c=window.devicePixelRatio||1;b.width=a*c,b.height=a*c,b.style.width=a+"px",b.style.height=a+"px",b.getContext("2d").setTransform(c,0,0,c,0,0)},[a]),(0,c.useEffect)(()=>{fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json").then(a=>a.json()).then(a=>{let b=function(a){let b=document.createElement("canvas");b.width=720,b.height=360;let c=b.getContext("2d");for(let b of(c.fillStyle="#000",c.fillRect(0,0,720,360),c.fillStyle="#fff",a)){c.beginPath();for(let a=0;a<b.length;a++){let d=(b[a][0]+180)/360*720,e=(90-b[a][1])/180*360;0===a?c.moveTo(d,e):c.lineTo(d,e)}c.closePath(),c.fill()}let d=c.getImageData(0,0,720,360),e=new Uint8Array(259200);for(let a=0;a<e.length;a++)e[a]=+(d.data[4*a]>128);return e}(function(a){let{scale:b,translate:c}=a.transform,d=a.arcs.map(a=>{let d=0,e=0;return a.map(([a,f])=>(d+=a,e+=f,[d*b[0]+c[0],e*b[1]+c[1]]))}),e=[],f=a.objects.land;for(let a of"GeometryCollection"===f.type?f.geometries:[f])for(let b of"MultiPolygon"===a.type?a.arcs.flat():a.arcs||[]){let a=[];for(let c of b){let b=c>=0?d[c]:[...d[~c]].reverse(),e=+(a.length>0);for(let c=e;c<b.length;c++)a.push(b[c])}a.length>2&&e.push(a)}return e}(a)),c=[];for(let a=88;a>=-88;a-=2.5){let e=d(a),f=Math.cos(e),g=Math.sin(e),h=2.5/Math.max(f,.2);for(let e=-180;e<180;e+=h){let h=Math.floor((e+180)/360*720);h>=720&&(h-=720);let i=Math.floor((90-a)/180*360),j=i>=0&&i<360&&1===b[720*i+h];c.push({cosLat:f,sinLat:g,lonR:d(e),land:j})}}j.current=c,m(!0)}).catch(()=>m(!0))},[]);let n=(0,c.useCallback)(()=>{let b=g.current;if(!b)return;let c=b.getContext("2d");if(!c)return;let d=a/2,f=a/2,k=.42*a,l=i.current,m=Math.cos(l),o=Math.sin(l);c.clearRect(0,0,a,a),c.fillStyle="rgba(50,100,200,0.04)",c.beginPath(),c.arc(d,f,1.12*k,0,2*Math.PI),c.fill(),c.strokeStyle="rgba(60,130,240,0.06)",c.lineWidth=8,c.beginPath(),c.arc(d,f,1.04*k,0,2*Math.PI),c.stroke(),c.strokeStyle="rgba(80,140,230,0.18)",c.lineWidth=1,c.beginPath(),c.arc(d,f,k,0,2*Math.PI),c.stroke(),c.strokeStyle="rgba(60,110,200,0.03)",c.lineWidth=.3;for(let a=1;a<6;a++){let b=-Math.PI/2+Math.PI*a/6,e=f-k*Math.sin(b),g=k*Math.cos(b);c.beginPath(),c.ellipse(d,e,g,.06*g,0,0,2*Math.PI),c.stroke()}for(let a=0;a<10;a++){let b=Math.abs(Math.cos(a/10*Math.PI+l));c.strokeStyle=`rgba(60,110,200,${.01+.03*b})`,c.beginPath(),c.ellipse(d,f,b*k,k,0,0,2*Math.PI),c.stroke()}let p=j.current;c.fillStyle="rgba(50,90,170,0.035)",c.beginPath();for(let a=0;a<p.length;a++){let b=p[a],e=Math.sin(b.lonR)*m+Math.cos(b.lonR)*o,g=Math.cos(b.lonR)*m-Math.sin(b.lonR)*o;if(b.cosLat*g<.02||b.land)continue;let h=d+k*b.cosLat*e,i=f-k*b.sinLat;c.rect(h-.35,i-.35,.7,.7)}for(let[a,b,e,g]of(c.fill(),[[.02,.3,"rgba(90,165,250,0.22)",1.2],[.3,.6,"rgba(100,175,255,0.42)",1.5],[.6,1.1,"rgba(120,190,255,0.62)",1.8]])){c.fillStyle=e.replace(/[\d.]+\)$/,`${g>1.5?.1:.06})`),c.beginPath();for(let e=0;e<p.length;e++){let h=p[e];if(!h.land)continue;let i=Math.sin(h.lonR)*m+Math.cos(h.lonR)*o,j=Math.cos(h.lonR)*m-Math.sin(h.lonR)*o,l=h.cosLat*j;if(l<a||l>=b)continue;let n=d+k*h.cosLat*i,q=f-k*h.sinLat,r=g+1.5;c.rect(n-r/2,q-r/2,r,r)}c.fill(),c.fillStyle=e,c.beginPath();for(let e=0;e<p.length;e++){let h=p[e];if(!h.land)continue;let i=Math.sin(h.lonR)*m+Math.cos(h.lonR)*o,j=Math.cos(h.lonR)*m-Math.sin(h.lonR)*o,l=h.cosLat*j;if(l<a||l>=b)continue;let n=d+k*h.cosLat*i,q=f-k*h.sinLat;c.rect(n-g/2,q-g/2,g,g)}c.fill()}let q=(Math.sin(3*l)+1)*.5,r=[];for(let a=0;a<e.length;a++){let b=e[a],c=Math.sin(b.lonR)*m+Math.cos(b.lonR)*o,g=Math.cos(b.lonR)*m-Math.sin(b.lonR)*o,h=b.cosLat*g;if(h<.15)continue;let i=d+k*b.cosLat*c,j=f-k*b.sinLat,l=.3+.7*h;r.push({m:b,px:i,py:j,z:h,alpha:l})}r.sort((a,b)=>b.z-a.z);let s=[];for(let{m:b,px:d,py:e,alpha:f}of(c.font="500 8px 'Exo 2', sans-serif",r)){c.fillStyle=`rgba(190,225,255,${.08*f})`,c.beginPath(),c.arc(d,e,8+3*q,0,2*Math.PI),c.fill(),c.fillStyle=`rgba(210,235,255,${.85*f})`,c.beginPath(),c.arc(d,e,2.2+.3*q,0,2*Math.PI),c.fill(),c.fillStyle=`rgba(240,250,255,${.7*f})`,c.beginPath(),c.arc(d,e,.9,0,2*Math.PI),c.fill();let g=b.offsetX>0?1:-1,h=b.offsetY>0?1:-1,i=d+22*g,j=e+h*Math.abs(b.offsetY/b.offsetX)*22,k=i+15*g,l=c.measureText(b.label).width,m=g>0?k-3:k-l-3,n=g>0?k+l+3:k+3,o=j-14,p=j+3,r=h;for(let b=0;b<12;b++){let b=!1;for(let a of s)if(m<a.x2&&n>a.x1&&o<a.y2&&p>a.y1){b=!0;break}if(!b)break;o<8&&r<0&&(r=1),p>a-8&&r>0&&(r=-1);let c=16*r;j+=c,o+=c,p+=c}if(o<4){let a=4-o;j+=a,o+=a,p+=a}if(p>a-4){let b=p-(a-4);j-=b,o-=b,p-=b}s.push({x1:m,y1:o,x2:n,y2:p}),c.strokeStyle=`rgba(160,210,255,${.25*f})`,c.lineWidth=.6,c.beginPath(),c.moveTo(d,e),c.lineTo(i,j),c.stroke(),c.beginPath(),c.moveTo(i,j),c.lineTo(i+12*g,j),c.stroke(),c.fillStyle=`rgba(255,255,255,${.75*f})`,c.textBaseline="bottom",c.textAlign=g>0?"left":"right",c.fillText(b.label,k,j-1)}i.current+=.0015,h.current=requestAnimationFrame(n)},[a]);return(0,c.useEffect)(()=>{if(l)return h.current=requestAnimationFrame(n),()=>cancelAnimationFrame(h.current)},[n,l]),(0,b.jsx)("canvas",{ref:g,style:{width:a,height:a,opacity:+!!l,transition:"opacity 0.5s"}})}var g=a.i(99361);let h=new Date("2026-07-01T09:00:00+03:00").getTime();a.s(["default",0,function(){let a=function(){let[a,b]=(0,c.useState)(!1),[d,e]=(0,c.useState)(h);(0,c.useEffect)(()=>{b(!0),e(Date.now());let a=setInterval(()=>e(Date.now()),1e3);return()=>clearInterval(a)},[]);let f=a?Math.max(0,h-d):0;return{days:Math.floor(f/864e5),hours:Math.floor(f%864e5/36e5),minutes:Math.floor(f%36e5/6e4),seconds:Math.floor(f%6e4/1e3)}}();return(0,b.jsxs)("section",{style:{position:"relative",minHeight:"100vh",display:"flex",alignItems:"center",background:"linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%)",overflow:"hidden"},children:[(0,b.jsx)("div",{className:"grid-pattern",style:{position:"absolute",inset:0,pointerEvents:"none"}}),(0,b.jsxs)("div",{className:"hero-grid",children:[(0,b.jsxs)("div",{style:{flex:"1 1 52%",minWidth:0},children:[(0,b.jsxs)("div",{className:"hero-date-badge",style:{animation:"fadeUp 0.6s ease-out"},children:[(0,b.jsx)("div",{style:{width:5,height:5,borderRadius:1,background:"#6B82C4"}}),(0,b.jsx)("span",{children:"01 — 03 июля 2026 · Санкт-Петербург"})]}),(0,b.jsx)("h1",{className:"hero-title-light",style:{animation:"fadeUp 0.65s ease-out 0.08s both"},children:"Конференция"}),(0,b.jsxs)("h1",{className:"hero-title-bold",style:{animation:"fadeUp 0.65s ease-out 0.16s both"},children:["GLP-PLANET ",(0,b.jsx)("span",{style:{fontWeight:300,color:"#fff"},children:"VII"})]}),(0,b.jsx)("p",{className:"hero-subtitle",style:{animation:"fadeUp 0.65s ease-out 0.24s both"},children:"Совместно с Русской ассоциацией специалистов по лабораторным животным Rus-LASA"}),(0,b.jsx)("p",{className:"hero-desc",style:{animation:"fadeUp 0.65s ease-out 0.28s both"},children:"10 тематических сессий, мастер-классы и круглые столы. Очное и онлайн участие."}),(0,b.jsxs)("div",{className:"hero-buttons",style:{animation:"fadeUp 0.65s ease-out 0.32s both"},children:[(0,b.jsxs)("a",{href:"/registration",className:"btn-primary",style:{textDecoration:"none"},children:[(0,b.jsx)("span",{children:"Регистрация"}),(0,b.jsx)(g.IconArrow,{})]}),(0,b.jsxs)("a",{href:"/docs/info-letter-2026.pdf",target:"_blank",rel:"noopener noreferrer",className:"btn-outline",style:{textDecoration:"none"},children:[(0,b.jsx)(g.IconFile,{}),(0,b.jsx)("span",{children:"Информационное письмо"})]})]})]}),(0,b.jsx)("div",{className:"hero-globe",style:{flex:"0 0 auto",position:"relative",animation:"fadeIn 1.2s ease-out 0.5s both"},children:(0,b.jsx)(f,{size:440})})]}),(0,b.jsx)("div",{className:"hero-countdown",style:{animation:"fadeUp 0.8s ease-out 0.5s both"},children:[{value:a.days,label:"дней"},{value:a.hours,label:"часов"},{value:a.minutes,label:"минут"},{value:a.seconds,label:"секунд"}].map((a,c)=>(0,b.jsxs)("div",{className:"hero-countdown-item",children:[(0,b.jsx)("div",{className:"hero-countdown-value",children:String(a.value).padStart(2,"0")}),(0,b.jsx)("div",{className:"hero-countdown-label",children:a.label})]},c))}),(0,b.jsx)("style",{children:`
        .hero-grid {
          max-width: 1240px; margin: 0 auto; padding: 120px 48px 140px;
          position: relative; z-index: 2; width: 100%;
          display: flex; align-items: center; justify-content: space-between; gap: 24px;
        }
        .hero-date-badge {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 7px 18px; border: 1px solid rgba(107,130,196,0.2);
          border-radius: 2px; margin-bottom: 32px;
        }
        .hero-date-badge span {
          color: rgba(255,255,255,0.75); font-size: 11px; font-weight: 500;
          letter-spacing: 2.5px; text-transform: uppercase;
        }
        .hero-title-light {
          font-size: 52px; font-weight: 300; color: #fff;
          line-height: 1.12; margin-bottom: 4px; letter-spacing: -0.5px;
        }
        .hero-title-bold {
          font-size: 52px; font-weight: 800; color: #fff;
          line-height: 1.12; margin-bottom: 28px; letter-spacing: 1.5px;
        }
        .hero-subtitle {
          font-size: 15px; color: rgba(255,255,255,0.85); line-height: 1.85;
          max-width: 520px; margin-bottom: 14px;
        }
        .hero-desc {
          font-size: 14px; color: rgba(255,255,255,0.7); line-height: 1.7;
          max-width: 520px; margin-bottom: 40px;
        }
        .hero-buttons { display: flex; gap: 12px; flex-wrap: wrap; }

        /* Countdown — always centered */
        .hero-countdown {
          position: absolute; bottom: 44px; left: 0; right: 0;
          display: flex; justify-content: center; align-items: center;
          gap: 36px; z-index: 3; padding: 0 20px;
          box-sizing: border-box;
        }
        .hero-countdown-item { text-align: center; min-width: 0; }
        .hero-countdown-value {
          font-size: 44px; font-weight: 800; color: rgba(255,255,255,0.9);
          line-height: 1; font-variant-numeric: tabular-nums;
          letter-spacing: 2px;
        }
        .hero-countdown-label {
          font-size: 10px; color: rgba(255,255,255,0.45);
          text-transform: uppercase; letter-spacing: 2.5px;
          margin-top: 8px;
        }

        /* Tablet */
        @media (max-width: 1024px) {
          .hero-grid { padding: 110px 32px 130px; }
          .hero-title-light, .hero-title-bold { font-size: 42px; }
          .hero-globe { display: none; }
          .hero-countdown { bottom: 36px; gap: 28px; }
          .hero-countdown-value { font-size: 36px; letter-spacing: 1.5px; }
          .hero-countdown-label { font-size: 9px; letter-spacing: 2px; }
        }

        /* Small tablet / large phone */
        @media (max-width: 768px) {
          .hero-grid { padding: 100px 24px 120px; }
          .hero-title-light, .hero-title-bold { font-size: 36px; }
          .hero-subtitle { font-size: 14px; }
          .hero-desc { font-size: 13px; margin-bottom: 32px; }
          .hero-countdown { bottom: 28px; gap: 24px; }
          .hero-countdown-value { font-size: 30px; }
        }

        /* Mobile */
        @media (max-width: 600px) {
          .hero-grid { padding: 96px 20px 110px; flex-direction: column; }
          .hero-title-light, .hero-title-bold { font-size: 30px; }
          .hero-date-badge { margin-bottom: 24px; }
          .hero-date-badge span { font-size: 9px; letter-spacing: 1.5px; }
          .hero-subtitle { font-size: 13px; max-width: 100%; }
          .hero-desc { font-size: 12px; margin-bottom: 28px; max-width: 100%; }
          .hero-buttons { flex-direction: column; }
          .hero-countdown { bottom: 20px; gap: 16px; padding: 0 16px; }
          .hero-countdown-value { font-size: 26px; letter-spacing: 1px; }
          .hero-countdown-label { font-size: 8px; letter-spacing: 1.5px; margin-top: 6px; }
        }

        /* Very small screens */
        @media (max-width: 380px) {
          .hero-grid { padding: 90px 16px 100px; }
          .hero-title-light, .hero-title-bold { font-size: 26px; }
          .hero-countdown { gap: 12px; bottom: 16px; padding: 0 12px; }
          .hero-countdown-value { font-size: 22px; }
          .hero-countdown-label { font-size: 7px; letter-spacing: 1px; }
        }
      `})]})}],57005)},88457,a=>{"use strict";var b=a.i(87924),c=a.i(72131);let d=new Map,e=null,f={up:"translateY(40px)",left:"translateX(-40px)",right:"translateX(40px)",scale:"scale(0.96)"};a.s(["default",0,function({children:a,delay:g=0,direction:h="up"}){let i=(0,c.useRef)(null),[j,k]=(0,c.useState)(!1),l=(0,c.useCallback)(()=>k(!0),[]);return(0,c.useEffect)(()=>{let a=i.current;if(!a)return;let b=(e||(e=new IntersectionObserver(a=>{for(let b of a)if(b.isIntersecting){let a=d.get(b.target);a&&(a(),d.delete(b.target),e?.unobserve(b.target))}},{threshold:.1})),e);return d.set(a,l),b.observe(a),()=>{d.delete(a),b.unobserve(a)}},[l]),(0,b.jsx)("div",{ref:i,style:{opacity:+!!j,transform:j?"none":f[h],transition:`all 0.65s cubic-bezier(0.16, 1, 0.3, 1) ${g}ms`,willChange:j?"auto":"opacity, transform"},children:a})}])},59400,a=>{"use strict";var b=a.i(87924),c=a.i(88457),d=a.i(99361);a.s(["default",0,function(){return(0,b.jsxs)("section",{id:"about",className:"about-section",children:[(0,b.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,b.jsx)(c.default,{children:(0,b.jsx)("div",{className:"section-label",children:"Участникам"})}),(0,b.jsx)(c.default,{delay:60,children:(0,b.jsx)("h2",{className:"section-title",children:"О конференции"})}),(0,b.jsx)(c.default,{delay:100,children:(0,b.jsx)("div",{className:"section-divider"})}),(0,b.jsx)(c.default,{delay:140,children:(0,b.jsx)("p",{className:"about-text",children:"Конференция GLP-PLANET ежегодно объединяет специалистов научно-исследовательских центров, представителей контрактных исследовательских организаций и фармацевтических компаний, разработчиков, экспертов в области биоэтики, представителей регуляторных и надзорных органов, технических специалистов и поставщиков решений, инвесторов, экспертов в области систем менеджмента качества и надлежащей лабораторной практики (GLP)."})}),(0,b.jsx)(c.default,{delay:200,children:(0,b.jsx)("p",{className:"about-text",style:{marginBottom:36},children:"Целями конференции являются распространение знаний и создание единого информационного поля в области надлежащей лабораторной практики, выработка единой стратегии в области разработки и исследований лекарственных препаратов, гуманного обращения с лабораторными животными, подготовка кадров, развитие отрасли, что будет способствовать выводу отечественных препаратов на зарубежный рынок."})}),(0,b.jsx)(c.default,{delay:260,children:(0,b.jsxs)("div",{className:"about-info-row",children:[(0,b.jsxs)("div",{className:"about-info-card",children:[(0,b.jsxs)("div",{className:"about-info-card-title",children:[(0,b.jsx)(d.IconPin,{}),"Место проведения"]}),(0,b.jsx)("div",{className:"about-info-card-text",children:"Отель «Санкт-Петербург», Пироговская набережная, д. 5/2, г. Санкт-Петербург"})]}),(0,b.jsxs)("div",{className:"about-info-card",children:[(0,b.jsxs)("div",{className:"about-info-card-title",children:[(0,b.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,b.jsx)("path",{d:"M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"}),(0,b.jsx)("circle",{cx:"9",cy:"7",r:"4"}),(0,b.jsx)("path",{d:"M22 21v-2a4 4 0 00-3-3.87"}),(0,b.jsx)("path",{d:"M16 3.13a4 4 0 010 7.75"})]}),"Регистрация участников"]}),(0,b.jsx)("div",{className:"about-info-card-text",children:"Очное и онлайн участие — регистрация через систему Timepad. Для оплаты от юридического лица свяжитесь с Организационным комитетом. Лектор участвует без организационного взноса."})]})]})})]}),(0,b.jsx)("style",{children:`
                .about-section { padding: 110px 48px; }
                .about-text { font-size: 15px; line-height: 1.9; color: #333; margin-bottom: 20px; }
                .about-info-row {
                    display: grid;
                    grid-template-columns: 1fr 2fr;
                    gap: 16px;
                }
                .about-info-card {
                    padding: 22px 24px;
                    background: var(--light);
                    border-radius: 4px;
                    border-left: 3px solid var(--secondary);
                    display: flex;
                    flex-direction: column;
                }
                .about-info-card-title {
                    font-weight: 600;
                    margin-bottom: 8px;
                    color: var(--primary);
                    font-size: 13px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .about-info-card-text {
                    color: #444;
                    line-height: 1.6;
                    font-size: 13px;
                    flex: 1;
                }
                @media (max-width: 1024px) {
                    .about-section { padding: 80px 32px; }
                }
                @media (max-width: 700px) {
                    .about-info-row { grid-template-columns: 1fr; }
                }
                @media (max-width: 600px) {
                    .about-section { padding: 60px 20px; }
                    .about-text { font-size: 14px; line-height: 1.75; }
                }
            `})]})}])},48441,a=>{"use strict";var b=a.i(87924),c=a.i(88457),d=a.i(72131);let e=[{num:1,title:"GLP-инжиниринг. Строительные технологии и инженерные решения для испытательных центров, проводящих доклинические исследования",topics:["Вентиляционное оборудование, от подбора до обслуживания","Проектирование и строительство вивария","Эксплуатация технического оборудования","Структурированные кабельные системы. Автоматизация и обслуживание","Управление отходами вивария"]},{num:2,title:"Аналитические исследования в жизненном цикле биопрепаратов",topics:["Изучение физико-химических характеристик различных видов оригинальных и воспроизведенных биопрепаратов: ключевые показатели, аналитические методы, сложности и пути решения при разработке, валидации, серийном применении методик","Оценка активности in vitro в отношении рецепторов, мембран, клеток/культуры клеток и тканей: методы (иммуноферментный анализ, биослойная интерферометрия), приемы, поисковые исследования и применение в стандартизации и доказательстве биоаналогичности","Оценка фармакокинетики и биоаналогичности, определение активности in vivo в отношении рецепторов, маркеров в исследованиях на животных и людях, особенности изучения различных групп биопрепаратов (моноклональных антител, генотерапевтических, соматотерапевтических)","Прогноз иммуногенности в исследованиях in vitro и in vivo: методы, особенности валидации методик, практическое применение"]},{num:3,title:"Репродуктивные технологии, криобанкирование половых продуктов и эмбрионов",topics:["Методы и способы оценки качества получения и сохранения половых продуктов","Программы искусственного оплодотворения и биобанкинга","Репродуктивные технологии в доклинических исследованиях"]},{num:4,title:"Экспериментальные модели и методы. Положительные контроли и релевантность тест-систем для моделирования",topics:["Практические подходы к выбору релевантной тест-системы","Выбор положительного контроля для исследования. Золотые стандарты","Выбор экспериментальной модели в соответствии с целями исследования","P-значимо? А смысл?"]},{num:5,title:"Доклинические исследования медицинских изделий: мост между инженерным замыслом и клинической практикой",topics:["Современные требования регуляторных органов","Доклинические исследования эффективности","Доклиническая оценка безопасности"]},{num:6,title:"Микробиология в доклинических исследованиях",topics:["Доклинические исследования в лаборатории микробиологии: микроорганизмы как основополагающий фактор качественных и правдоподобных результатов. Способы хранения, восстановления и поддержания жизнеспособности культур микроорганизмов. Учет и систематизация штаммов","Биобанкирование микроорганизмов","Особенности работы в лаборатории микробиологии: внутренний контроль качества","Микробиологические исследования in vivo и in vitro: методы и их практическое применение"]},{num:7,title:"Доклинические исследования биологических лекарственных средств",topics:["Применение риск-ориентированного подхода при обосновании программы исследований","Выбор и обоснование конечных точек в эксперименте","Методические аспекты оценки изучения эффективности, безопасности, фармакокинетики и биораспределения лекарственных средств","Доклинические аспекты фармацевтической разработки","Выбор релевантных тест-систем"],note:"Сессия делится на тематические блоки: биотехнологические ЛП, высокотехнологичные ЛП, иммунобиологические ЛП для человека и животных"},{num:8,title:"Гистология как неотъемлемая часть доклинических исследований",topics:["Воспроизводимость гистологических данных в доклинических исследованиях","Корреляция гистологии с другими типами данных","Кросс-реактивность гистологии с другими типами данных","Вызовы преаналитики и новые технологические решения в гистологии","Анализ и интерпретация данных: особенности в доклинических исследованиях и современные решения"]},{num:9,title:"Культура доклинических исследований: качество лабораторных животных",topics:["От SPF к LAQIS: эволюция представлений о «золотом стандарте»","Санитарные мероприятия в питомниках и вивариях","Мониторинг ключевых параметров окружающей среды в вивариях и питомниках испытательных центров. Программа мониторинга здоровья животных","Качество манипуляций — основа надежных данных исследования. Принцип «не навреди» в доклинических исследованиях","Ведение колоний","Генотипирование","Вопросы терапии колоний. Эвтаназировать нельзя лечить: где ставить запятую?","Влияние патогенов на ход исследования"]},{num:10,title:"Ярмарка выпускных квалификационных работ (сессия для студентов старших курсов и магистров)",topics:[]}];a.s(["default",0,function(){let[a,f]=(0,d.useState)(null);return(0,b.jsxs)("section",{id:"program",className:"program-section",children:[(0,b.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,b.jsx)(c.default,{children:(0,b.jsx)("div",{className:"section-label",children:"Программа"})}),(0,b.jsx)(c.default,{delay:60,children:(0,b.jsx)("h2",{className:"section-title",style:{marginBottom:12},children:"Тематические сессии"})}),(0,b.jsx)(c.default,{delay:90,children:(0,b.jsx)("p",{className:"program-desc",children:"Программа предстоящей конференции включает тематические сессии, мастер-классы и круглые столы. По итогам конференции выпускается коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»."})}),(0,b.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:10},children:e.map((d,e)=>{let g=a===d.num,h=d.topics.length>0;return(0,b.jsx)(c.default,{delay:100+30*e,children:(0,b.jsxs)("div",{style:{background:"var(--light)",borderRadius:4,border:g?"1px solid rgba(73,100,162,0.15)":"1px solid rgba(73,100,162,0.05)",overflow:"hidden",transition:"border-color 0.3s"},children:[(0,b.jsxs)("button",{onClick:()=>{let b;return h&&f(a===(b=d.num)?null:b)},className:"program-session-btn",children:[(0,b.jsx)("div",{className:"program-session-num",style:{background:g?"var(--primary)":"var(--secondary)"},children:d.num}),(0,b.jsxs)("div",{style:{flex:1,paddingTop:6},children:[(0,b.jsx)("h3",{className:"program-session-title",children:d.title}),d.note&&(0,b.jsx)("p",{className:"program-session-note",children:d.note})]}),h&&(0,b.jsx)("div",{style:{flexShrink:0,marginTop:8,width:20,height:20,display:"flex",alignItems:"center",justifyContent:"center",color:"var(--secondary)",transition:"transform 0.3s",transform:g?"rotate(180deg)":"rotate(0deg)"},children:(0,b.jsx)("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:(0,b.jsx)("polyline",{points:"6,9 12,15 18,9"})})})]}),g&&h&&(0,b.jsxs)("div",{className:"program-topics",style:{animation:"fadeIn 0.25s ease-out"},children:[(0,b.jsx)("div",{style:{fontSize:12,fontWeight:600,color:"var(--secondary)",textTransform:"uppercase",letterSpacing:1.5,marginBottom:14},children:"Темы для обсуждений"}),(0,b.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:10},children:d.topics.map((a,c)=>(0,b.jsxs)("div",{style:{display:"flex",gap:12,alignItems:"flex-start"},children:[(0,b.jsx)("div",{style:{width:5,height:5,borderRadius:1,background:"var(--secondary)",marginTop:7,flexShrink:0}}),(0,b.jsx)("span",{style:{color:"#3a3f4a",fontSize:14,lineHeight:1.65},children:a})]},c))})]})]})},d.num)})})]}),(0,b.jsx)("style",{children:`
        .program-section { padding: 110px 48px; background: var(--white); }
        .program-desc { font-size: 15px; color: #4a5060; line-height: 1.7; margin-bottom: 48px; max-width: 720px; }
        .program-session-btn {
          width: 100%; display: flex; gap: 18px; align-items: flex-start;
          padding: 24px 28px; background: none; border: none;
          cursor: pointer; text-align: left; font-family: 'Exo 2', sans-serif;
        }
        .program-session-num {
          display: flex; align-items: center; justify-content: center;
          min-width: 40px; height: 40px; border-radius: 3px;
          color: #fff; font-size: 15px; font-weight: 700; flex-shrink: 0; transition: background 0.3s;
        }
        .program-session-title { color: var(--primary); font-size: 15px; font-weight: 600; line-height: 1.5; margin: 0; }
        .program-session-note { font-size: 13px; color: var(--muted); margin-top: 6px; line-height: 1.5; font-style: italic; }
        .program-topics { padding: 0 28px 24px 86px; }

        @media (max-width: 1024px) {
          .program-section { padding: 80px 32px; }
        }
        @media (max-width: 600px) {
          .program-section { padding: 60px 20px; }
          .program-desc { font-size: 14px; margin-bottom: 32px; }
          .program-session-btn { padding: 18px 16px; gap: 12px; }
          .program-session-num { min-width: 32px; height: 32px; font-size: 13px; }
          .program-session-title { font-size: 14px; }
          .program-topics { padding: 0 16px 20px 56px; }
          .program-topics span { font-size: 13px; }
        }
      `})]})}])},25433,a=>{"use strict";var b=a.i(87924),c=a.i(88457),d=a.i(72131);function e({end:a,suffix:c=""}){let[f,g]=(0,d.useState)(0),h=(0,d.useRef)(null),[i,j]=(0,d.useState)(!1);return(0,d.useEffect)(()=>{let a=new IntersectionObserver(([a])=>{a.isIntersecting&&j(!0)},{threshold:.5});return h.current&&a.observe(h.current),()=>a.disconnect()},[]),(0,d.useEffect)(()=>{if(!i)return;let b=0,c=a/100,d=setInterval(()=>{(b+=c)>=a?(g(a),clearInterval(d)):g(Math.floor(b))},16);return()=>clearInterval(d)},[i,a]),(0,b.jsxs)("span",{ref:h,children:[f,c]})}let f=[{roman:"VII",l:"Конференция"},{n:10,s:"",l:"Сессий"},{n:3,s:"",l:"Дня программы"},{n:500,s:"+",l:"Участников"}];a.s(["default",0,function(){return(0,b.jsxs)("section",{className:"stats-section",children:[(0,b.jsx)("div",{style:{maxWidth:1200,margin:"0 auto"},children:(0,b.jsx)("div",{className:"stats-grid",children:f.map((a,d)=>(0,b.jsx)(c.default,{delay:60*d,children:(0,b.jsxs)("div",{style:{textAlign:"center",padding:20},children:[(0,b.jsx)("div",{className:"stats-number",children:a.roman?a.roman:(0,b.jsx)(e,{end:a.n,suffix:a.s})}),(0,b.jsx)("div",{className:"stats-label",children:a.l})]})},d))})}),(0,b.jsx)("style",{children:`
        .stats-section {
          padding: 70px 48px;
          border-top: 1px solid var(--light);
          border-bottom: 1px solid var(--light);
        }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .stats-number { font-size: 44px; font-weight: 800; color: var(--primary); line-height: 1; margin-bottom: 6px; }
        .stats-label { font-size: 11px; color: var(--muted); font-weight: 500; letter-spacing: 1.5px; text-transform: uppercase; }

        @media (max-width: 1024px) {
          .stats-section { padding: 56px 32px; }
        }
        @media (max-width: 600px) {
          .stats-section { padding: 40px 20px; }
          .stats-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
          .stats-number { font-size: 32px; }
          .stats-label { font-size: 10px; }
        }
      `})]})}],25433)},46640,a=>{"use strict";var b=a.i(87924),c=a.i(88457),d=a.i(71987);let e=[{name:"Журнал «Разработка и регистрация лекарственных средств»",img:"/images/partners/rrl.png",href:"https://www.pharmjournal.ru/jour/announcement/view/618"},{name:"Laboratory Animals Journal",img:"/images/partners/laj.png",href:null},{name:"SciCat — платформа научных каталогов",img:"/images/partners/scicat.png",href:"https://sci-cat.ru/"}];function f({p:a}){let c=(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(d.default,{src:a.img,alt:a.name,width:200,height:80,className:"partner-logo",style:{width:"auto",height:"auto",maxWidth:200,maxHeight:80,objectFit:"contain"}}),(0,b.jsx)("div",{className:"partner-name",children:a.name})]});return a.href?(0,b.jsx)("a",{href:a.href,target:"_blank",rel:"noopener noreferrer",className:"partner-card",children:c}):(0,b.jsx)("div",{className:"partner-card",children:c})}a.s(["default",0,function(){return(0,b.jsxs)("section",{className:"partners-section",children:[(0,b.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,b.jsx)(c.default,{children:(0,b.jsx)("div",{className:"section-label",children:"Партнёры"})}),(0,b.jsx)(c.default,{delay:60,children:(0,b.jsx)("h2",{className:"section-title",style:{marginBottom:44},children:"Сотрудничество"})}),(0,b.jsx)("div",{className:"partners-grid",children:e.map((a,d)=>(0,b.jsx)(c.default,{delay:120+80*d,direction:"scale",children:(0,b.jsx)(f,{p:a})},d))})]}),(0,b.jsx)("style",{children:`
        .partners-section { padding: 110px 48px; background: var(--white); }
        .partners-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .partner-card {
          display: flex; flex-direction: column; align-items: center; justify-content: center;
          padding: 40px 32px 28px; background: var(--light); border-radius: 4px;
          border: 1px solid rgba(73,100,162,0.06); text-decoration: none; text-align: center;
          transition: all 0.5s cubic-bezier(0.33, 1, 0.68, 1); min-height: 200px;
        }
        .partner-card:hover {
          transform: translateY(-5px); box-shadow: 0 20px 44px rgba(20,27,77,0.08);
          border-color: rgba(73,100,162,0.12);
        }
        .partner-logo { margin-bottom: 20px; transition: opacity 0.4s; }
        .partner-card:hover .partner-logo { opacity: 0.85; }
        .partner-name { font-size: 13px; font-weight: 600; color: var(--primary); line-height: 1.5; }

        @media (max-width: 1024px) {
          .partners-section { padding: 80px 32px; }
        }
        @media (max-width: 900px) {
          .partners-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 600px) {
          .partners-section { padding: 60px 20px; }
          .partners-grid { grid-template-columns: 1fr; }
          .partner-card { min-height: 160px; padding: 28px 20px 20px; }
        }
      `})]})}])}];

//# sourceMappingURL=components_0e4lcw1._.js.map