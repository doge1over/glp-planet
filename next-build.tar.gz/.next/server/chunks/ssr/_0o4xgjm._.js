module.exports=[33354,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}},88457,a=>{"use strict";var b=a.i(87924),c=a.i(72131);let d=new Map,e=null,f={up:"translateY(40px)",left:"translateX(-40px)",right:"translateX(40px)",scale:"scale(0.96)"};a.s(["default",0,function({children:a,delay:g=0,direction:h="up"}){let i=(0,c.useRef)(null),[j,k]=(0,c.useState)(!1),l=(0,c.useCallback)(()=>k(!0),[]);return(0,c.useEffect)(()=>{let a=i.current;if(!a)return;let b=(e||(e=new IntersectionObserver(a=>{for(let b of a)if(b.isIntersecting){let a=d.get(b.target);a&&(a(),d.delete(b.target),e?.unobserve(b.target))}},{threshold:.1})),e);return d.set(a,l),b.observe(a),()=>{d.delete(a),b.unobserve(a)}},[l]),(0,b.jsx)("div",{ref:i,style:{opacity:+!!j,transform:j?"none":f[h],transition:`all 0.65s cubic-bezier(0.16, 1, 0.3, 1) ${g}ms`,willChange:j?"auto":"opacity, transform"},children:a})}])},13921,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(88457),e=a.i(71987);let f=[{label:"Генеральные спонсоры",sponsors:[{name:"FarmBioLine",img:"/images/sponsors/logo_bronzovyj_sponsor_farmbiolajn-1.png",href:"https://farmbioline.ru/",scale:1.6}],speed:28},{label:"Золотые спонсоры",sponsors:[{name:"БиоГен-Аналитика",img:"/images/sponsors/@logo.png",href:"https://bga.ru/"},{name:"БиоЛайн",img:"/images/sponsors/BL_rus_LOGO.png",href:"https://bioline.ru/"}],speed:32},{label:"Спонсоры",sponsors:[{name:"ТехноИнфо",img:"/images/sponsors/ТехноИнфо_LOGO_2024 (5).png",href:"https://technoinfo.ru/"},{name:"Группа компаний «Р-Фарм»",img:"/images/sponsors/Р-Фарм.png",href:"https://www.r-pharm.com"},{name:"LUMINON",img:"/images/sponsors/Logo-487х183.png",href:"https://luminon.ru"},{name:"LabNeo",img:"/images/sponsors/labneo.png",href:"https://labneo.ru/"},{name:"SciCat — платформа научных каталогов",img:"/images/partners/scicat.png",href:"https://sci-cat.ru/"},{name:"ООО «ФИЗЛАБПРИБОР»",img:"/images/sponsors/fizlab.png",href:"https://fizlab.ru/"},{name:"Биокад",img:"/images/sponsors/logo_BIOCAD_25_color_2.png",href:"https://biocad.ru/"},{name:"АО «НПО «ДОМ ФАРМАЦИИ»",img:"/images/sponsors/logo-vector.png",href:"https://doclinika.ru/"},{name:"ООО «ВЕТКОРМТОРГ»",img:"/images/sponsors/веткт лого.png",href:"https://vetkt.ru/"},{name:"ООО «БМТ-МММ»",img:"/images/sponsors/BMT_logo.jpg",href:"https://bmt-mmm.ru/ ",scale:1.6},{name:"BioInn Labs",img:"/images/sponsors/логотип.jpg",href:"https://bioinnlabs.ru",scale:1.2},{name:"АНО АВТех",img:"/images/sponsors/Логотип AWTECH.png",href:"https://awt.ru/product/vivariy/"},{name:"Группа компаний «ЭДВАНСД»",img:"/images/sponsors/logo_advanced.png",scale:1.4,className:"sponsor-edvansed"}],speed:35},{label:"Информационные партнёры",sponsors:[{name:"Журнал «Разработка и регистрация лекарственных средств»",img:"/images/partners/rrl.png",href:"https://www.pharmjournal.ru/jour/announcement/view/618"},{name:"Лабораторные животные",img:"/images/sponsors/laj-logo-1862x518-transparent-bg.png",href:"https://labanimalsjournal.ru/"},{name:"StereotaX",img:"/images/sponsors/STAX_LOGO_BLACK-01.png",href:"https://stereotax.info/",scale:1.6},{name:"НАИИО",img:"/images/sponsors/NAIIO_RUS_Logo1-01.png",href:"https://наиио.рф/рабочие-группы/"}],speed:38}];function g({s:a}){let c=(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("div",{className:"sponsor-slide-inner",children:(0,b.jsx)(e.default,{src:a.img,alt:a.name,width:200,height:80,style:{width:"auto",height:"auto",maxWidth:180*(a.scale??1),maxHeight:70*(a.scale??1),objectFit:"contain",transform:a.offsetY?`translateY(${a.offsetY}px)`:void 0}})}),(0,b.jsx)("div",{className:"sponsor-slide-name",children:a.name})]});return a.href?(0,b.jsx)("a",{href:a.href,target:"_blank",rel:"noopener noreferrer",className:`sponsor-slide sponsor-slide-link${a.className?` ${a.className}`:""}`,children:c}):(0,b.jsx)("div",{className:`sponsor-slide${a.className?` ${a.className}`:""}`,children:c})}function h({tier:a}){let{label:d,sponsors:e,speed:f=30}=a,i=(0,c.useRef)(null),[j,k]=(0,c.useState)(!1);(0,c.useEffect)(()=>{if(e.length<2)return void k(!1);let a=i.current;if(!a)return;let b=()=>{let b=a.clientWidth,c=window.innerWidth,d=240,f=32;c<=600?(d=170,f=20):c<=1024&&(d=200,f=32),k(e.length*d+(e.length-1)*f>b-16)};b();let c=new ResizeObserver(b);return c.observe(a),()=>c.disconnect()},[e.length]);let l=j?Array.from({length:8},()=>e).flat():e;return(0,b.jsxs)("div",{className:"tier-row",ref:i,children:[(0,b.jsxs)("div",{className:"tier-label-wrap",children:[(0,b.jsx)("div",{className:"tier-label",children:d}),(0,b.jsx)("div",{className:"tier-divider"})]}),0===e.length?(0,b.jsx)("div",{className:"tier-empty-wrap",children:(0,b.jsx)("div",{className:"tier-empty",children:"Скоро…"})}):j?(0,b.jsx)("div",{className:"tier-carousel",children:(0,b.jsx)("div",{className:"tier-track tier-track-scroll",style:{animationDuration:`${f}s`,"--count":e.length},children:l.map((a,c)=>(0,b.jsx)(g,{s:a},c))})}):(0,b.jsx)("div",{className:"tier-static-wrap",children:e.map((a,c)=>(0,b.jsx)(g,{s:a},c))})]})}a.s(["default",0,function(){return(0,b.jsxs)("section",{className:"sponsors-section",children:[(0,b.jsxs)("div",{className:"sponsors-header",children:[(0,b.jsx)(d.default,{children:(0,b.jsx)("div",{className:"section-label",children:"Спонсоры"})}),(0,b.jsx)(d.default,{delay:60,children:(0,b.jsx)("h2",{className:"section-title",style:{marginBottom:16},children:"Нас поддерживают"})}),(0,b.jsx)(d.default,{delay:100,children:(0,b.jsx)("p",{className:"sponsors-desc",children:"Мы благодарим наших партнёров и спонсоров за поддержку конференции"})})]}),(0,b.jsx)("div",{className:"tiers-wrap",children:f.map((a,c)=>(0,b.jsx)(d.default,{delay:140+80*c,children:(0,b.jsx)(h,{tier:a})},c))}),(0,b.jsx)("style",{children:`
                .sponsors-section {
                    padding: 100px 0 110px;
                    background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
                    position: relative;
                }
                .sponsors-header { max-width: 1200px; margin: 0 auto; padding: 0 48px; }
                .sponsors-section .section-label { color: #6B82C4; }
                .sponsors-section .section-title { color: #fff; }
                .sponsors-desc {
                    font-size: 15px;
                    color: rgba(255,255,255,0.4);
                    line-height: 1.7;
                    max-width: 480px;
                    margin-bottom: 56px;
                }

                .tiers-wrap {
                    display: flex;
                    flex-direction: column;
                    gap: 48px;
                }

                .tier-row { width: 100%; }

                .tier-label-wrap {
                    max-width: 1200px;
                    margin: 0 auto 20px;
                    padding: 0 48px;
                    display: flex;
                    align-items: center;
                    gap: 16px;
                }
                .tier-label {
                    font-size: 11px;
                    color: rgba(255,255,255,0.5);
                    font-weight: 600;
                    letter-spacing: 2.5px;
                    text-transform: uppercase;
                    flex-shrink: 0;
                }
                .tier-divider {
                    flex: 1;
                    height: 1px;
                    background: linear-gradient(to right, rgba(107,130,196,0.3), transparent);
                }

                .tier-empty-wrap {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 0 48px;
                    box-sizing: border-box;
                }
                .tier-empty {
                    height: 110px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: rgba(255,255,255,0.2);
                    font-size: 12px;
                    font-style: italic;
                    letter-spacing: 1px;
                    border: 1px dashed rgba(107,130,196,0.12);
                    border-radius: 6px;
                }

                .tier-static-wrap {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 16px 48px;
                    display: flex;
                    gap: 32px;
                    justify-content: center;
                    flex-wrap: wrap;
                    box-sizing: border-box;
                }

                .tier-carousel {
                    width: 100%;
                    overflow-x: hidden;
                    overflow-y: visible;
                    padding: 16px 0;
                    -webkit-mask-image: linear-gradient(to right, transparent 0%, black 6%, black 94%, transparent 100%);
                    mask-image: linear-gradient(to right, transparent 0%, black 6%, black 94%, transparent 100%);
                }

                .tier-track {
                    --slide-w: 240px;
                    --gap: 32px;
                    display: flex;
                    gap: var(--gap);
                    align-items: flex-start;
                }
                .tier-track-scroll {
                    width: max-content;
                    animation-name: sponsorScroll;
                    animation-timing-function: linear;
                    animation-iteration-count: infinite;
                    will-change: transform;
                }
                .tier-track-scroll:hover {
                    animation-play-state: paused;
                }

                @keyframes sponsorScroll {
                    from { transform: translate3d(0, 0, 0); }
                    to   { transform: translate3d(calc(-1 * var(--count) * (var(--slide-w) + var(--gap))), 0, 0); }
                }

                .sponsor-slide {
                    flex-shrink: 0;
                    width: 240px;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 16px;
                    text-decoration: none;
                }
                .sponsor-slide-inner {
                    width: 240px;
                    height: 110px;
                    background: #fff;
                    isolation: isolate;
                    border-radius: 6px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px 24px;
                    transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
                    border: 1px solid rgba(107,130,196,0.1);
                    overflow: hidden;
                    box-sizing: border-box;
                }
                .sponsor-slide-inner img {
                    mix-blend-mode: multiply;
                }
                .sponsor-slide:hover .sponsor-slide-inner {
                    transform: translateY(-6px);
                    box-shadow: 0 16px 40px rgba(0,0,0,0.2);
                    border-color: rgba(107,130,196,0.25);
                }
                .sponsor-slide-name {
                    font-size: 11px;
                    color: rgba(255,255,255,0.35);
                    font-weight: 500;
                    letter-spacing: 0.5px;
                    text-align: center;
                    transition: color 0.3s;
                    max-width: 240px;
                    line-height: 1.4;
                }
                .sponsor-slide:hover .sponsor-slide-name {
                    color: rgba(255,255,255,0.6);
                }

                @media (max-width: 1024px) {
                    .sponsors-section { padding: 80px 0 90px; }
                    .sponsors-header { padding: 0 32px; }
                    .sponsors-desc { margin-bottom: 44px; }
                    .tier-label-wrap { padding: 0 32px; }
                    .tier-empty-wrap { padding: 0 32px; }
                    .tier-static-wrap { padding: 16px 32px; gap: 24px; }
                    .tier-track { --slide-w: 200px; }
                    .sponsor-slide { width: 200px; }
                    .sponsor-slide-inner { width: 200px; height: 100px; padding: 18px 20px; }
                    .sponsor-slide-name { max-width: 200px; }
                    .tiers-wrap { gap: 36px; }
                }
                @media (max-width: 600px) {
                    .sponsors-section { padding: 60px 0 70px; }
                    .sponsors-header { padding: 0 20px; }
                    .sponsors-desc { font-size: 14px; margin-bottom: 36px; }
                    .tier-label-wrap { padding: 0 20px; margin-bottom: 14px; }
                    .tier-empty-wrap { padding: 0 20px; }
                    .tier-empty { height: 90px; font-size: 11px; }
                    .tier-static-wrap { padding: 16px 20px; gap: 16px; }
                    .tier-track { --slide-w: 170px; --gap: 20px; }
                    .sponsor-slide { width: 170px; }
                    .sponsor-slide-inner { width: 170px; height: 85px; padding: 16px; }
                    .sponsor-slide-inner img { max-width: 140px !important; max-height: 55px !important; }
                    .sponsor-edvansed .sponsor-slide-inner img { max-width: 165px !important; max-height: 76px !important; transform: none !important; }
                    .sponsor-slide-name { font-size: 10px; max-width: 170px; }
                    .tiers-wrap { gap: 28px; }
                    .tier-label { font-size: 10px; letter-spacing: 1.5px; }
                }
            `})]})}])}];

//# sourceMappingURL=_0o4xgjm._.js.map