module.exports=[77754,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2020_page_actions_0~~m13w.js.map