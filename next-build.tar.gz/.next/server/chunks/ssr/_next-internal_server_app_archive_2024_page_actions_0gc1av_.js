module.exports=[54469,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2024_page_actions_0gc1av_.js.map