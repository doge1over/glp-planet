module.exports=[39474,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(72131),e=a.i(42100);let f=["доклад","доклад онлайн","доклад снят","дискуссия","перерыв","обед","выставка","фуршет","собрание","мастер-класс","круглый стол","регистрация","церемония"],g={"доклад онлайн":"#7fc18f","доклад снят":"#E08A8A"},h="ap_admin_pw_v1",i=1e5,j=`
  .al-main { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; background: linear-gradient(155deg, #080C24 0%, #141B4D 100%); font-family: 'Exo 2', sans-serif; }
  .al-card { width: 100%; max-width: 400px; background: rgba(255,255,255,0.04); border: 1px solid rgba(107,130,196,0.2); border-radius: 10px; padding: 40px 36px; }
  .al-brand { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #6B82C4; font-weight: 600; margin-bottom: 16px; }
  .al-title { font-size: 24px; font-weight: 700; color: #fff; margin-bottom: 6px; }
  .al-sub { font-size: 14px; color: rgba(255,255,255,0.55); margin-bottom: 24px; }
  .al-form { display: flex; flex-direction: column; gap: 16px; }
  .al-field { display: flex; flex-direction: column; gap: 6px; }
  .al-field span { font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 1px; }
  .al-field input { padding: 12px 14px; border-radius: 6px; background: rgba(8,12,36,0.5); border: 1px solid rgba(107,130,196,0.25); color: #fff; font-size: 14px; font-family: inherit; outline: none; transition: border-color 0.2s; }
  .al-field input:focus { border-color: #559CD6; }
  .al-err { color: #E08A8A; font-size: 13px; font-weight: 600; }
  .al-btn { margin-top: 8px; padding: 13px; border-radius: 6px; background: #559CD6; color: #fff; font-size: 15px; font-weight: 600; text-align: center; border: none; cursor: pointer; font-family: inherit; transition: background 0.2s; }
  .al-btn:hover:not(:disabled) { background: #4A8BC2; }
  .al-btn:disabled { opacity: 0.55; cursor: default; }
  .al-back { display: block; margin-top: 24px; text-align: center; color: rgba(255,255,255,0.5); font-size: 13px; text-decoration: none; transition: color 0.2s; }
  .al-back:hover { color: #fff; }
`,k=`
  .ap-wrap { min-height: 100vh; padding: 32px 40px 80px; background: #0E1330; color: #fff; font-family: 'Exo 2', sans-serif; }
  .ap-top { display: flex; align-items: flex-end; justify-content: space-between; gap: 20px; flex-wrap: wrap; margin-bottom: 16px; }
  .ap-brand { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #6B82C4; font-weight: 600; margin-bottom: 6px; }
  .ap-h1 { font-size: 26px; font-weight: 700; }
  .ap-top-right { display: flex; gap: 18px; align-items: center; }
  .ap-link { color: rgba(255,255,255,0.6); font-size: 13px; text-decoration: none; background: none; border: none; cursor: pointer; font-family: inherit; transition: color 0.2s; }
  .ap-link:hover { color: #fff; }

  .ap-legend { display: flex; gap: 14px; margin-bottom: 18px; }
  .ap-leg-item { font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 4px; }
  .leg-online { background: rgba(127,193,143,0.15); color: #7fc18f; border: 1px solid rgba(127,193,143,0.3); }
  .leg-removed { background: rgba(224,138,138,0.15); color: #E08A8A; border: 1px solid rgba(224,138,138,0.3); }

  .ap-controls { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 20px; }
  .ap-seg { display: inline-flex; gap: 2px; padding: 3px; flex-wrap: wrap; background: rgba(8,12,36,0.5); border-radius: 6px; border: 1px solid rgba(107,130,196,0.2); }
  .ap-seg-btn { padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; background: transparent; color: rgba(255,255,255,0.6); font-family: inherit; font-size: 13px; font-weight: 600; transition: all 0.15s; }
  .ap-seg-btn:hover { color: #fff; }
  .ap-seg-btn.active { background: #559CD6; color: #fff; }

  .ap-table { background: rgba(255,255,255,0.03); border: 1px solid rgba(107,130,196,0.15); border-radius: 8px; overflow: hidden; }
  .ap-row {
    display: grid; grid-template-columns: 40px 80px 80px 130px 1.4fr 1fr 40px;
    gap: 10px; padding: 10px 14px; align-items: start;
    border-bottom: 1px solid rgba(107,130,196,0.1);
  }
  .ap-row:last-child { border-bottom: none; }
  .ap-head {
    background: rgba(85,156,214,0.1); align-items: center;
    font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #6B82C4; font-weight: 600;
  }
  .row-online { background: rgba(127,193,143,0.06); border-left: 3px solid rgba(127,193,143,0.4); padding-left: 11px; }
  .row-removed { background: rgba(224,138,138,0.06); border-left: 3px solid rgba(224,138,138,0.4); padding-left: 11px; }
  .ap-row.status-pending { background: rgba(224,146,52,0.12); border-left: 3px solid #E09234; padding-left: 11px; }
  .ap-row.status-verified { background: rgba(74,174,105,0.12); border-left: 3px solid #4AAE69; padding-left: 11px; }

  .ap-move { display: flex; flex-direction: column; gap: 3px; padding-top: 2px; }
  .ap-mv-btn { width: 28px; height: 20px; border-radius: 3px; cursor: pointer; background: rgba(107,130,196,0.1); border: 1px solid rgba(107,130,196,0.2); color: rgba(255,255,255,0.6); font-size: 12px; font-weight: 700; transition: all 0.15s; display: flex; align-items: center; justify-content: center; padding: 0; }
  .ap-mv-btn:hover:not(:disabled) { background: rgba(107,130,196,0.3); color: #fff; }
  .ap-mv-btn:disabled { opacity: 0.25; cursor: default; }

  .ap-in { width: 100%; padding: 9px 10px; border-radius: 5px; background: rgba(8,12,36,0.5); border: 1px solid rgba(107,130,196,0.2); color: #fff; font-size: 13px; font-family: inherit; outline: none; transition: border-color 0.2s; }
  .ap-in:focus { border-color: #559CD6; }
  .ap-time { font-variant-numeric: tabular-nums; letter-spacing: 1px; text-align: center; }
  .ap-area { resize: vertical; line-height: 1.4; }
  .ap-del { width: 30px; height: 30px; border-radius: 5px; cursor: pointer; margin-top: 2px; background: rgba(196,90,90,0.12); border: 1px solid rgba(196,90,90,0.3); color: #E08A8A; font-size: 13px; transition: all 0.15s; }
  .ap-del:hover { background: rgba(196,90,90,0.25); color: #fff; }
  .ap-empty { padding: 28px; text-align: center; color: rgba(255,255,255,0.4); font-size: 14px; }

  .ap-item-tools {
    grid-column: 2 / 7; display: flex; align-items: center; flex-wrap: wrap; gap: 8px;
    padding: 2px 0 3px;
  }
  .ap-review-check {
    display: inline-flex; align-items: center; gap: 7px; padding: 7px 10px;
    border: 1px solid rgba(224,146,52,0.45); border-radius: 5px;
    color: #F0AE5C; font-size: 11px; font-weight: 700; cursor: pointer;
    background: rgba(224,146,52,0.08); white-space: nowrap;
  }
  .ap-review-check.checked { color: #77D394; border-color: rgba(74,174,105,0.5); background: rgba(74,174,105,0.1); }
  .ap-review-check input { width: 15px; height: 15px; accent-color: #4AAE69; cursor: pointer; }
  .ap-files { display: flex; align-items: center; flex-wrap: wrap; gap: 7px; }
  .ap-file {
    display: inline-flex; align-items: stretch; max-width: 310px;
    border: 1px solid rgba(107,130,196,0.25); border-radius: 5px;
    background: rgba(8,12,36,0.38); overflow: hidden;
  }
  .ap-file a {
    display: flex; align-items: center; gap: 7px; min-width: 0; padding: 7px 9px;
    color: #AFC7F1; text-decoration: none; font-size: 11px;
  }
  .ap-file a:hover { color: #fff; }
  .ap-file-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .ap-file-size { flex-shrink: 0; color: rgba(255,255,255,0.35); font-size: 10px; }
  .ap-file button {
    flex-shrink: 0; width: 28px; border: 0; border-left: 1px solid rgba(107,130,196,0.2);
    background: rgba(196,90,90,0.08); color: #E08A8A; cursor: pointer; font-size: 16px;
  }
  .ap-file button:hover { background: rgba(196,90,90,0.22); color: #fff; }
  .ap-upload {
    display: inline-flex; align-items: center; padding: 7px 11px; border-radius: 5px;
    border: 1px dashed rgba(107,130,196,0.45); color: rgba(255,255,255,0.65);
    font-size: 11px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap;
  }
  .ap-upload:hover { border-color: #559CD6; color: #fff; background: rgba(85,156,214,0.08); }
  .ap-upload.loading { cursor: wait; opacity: 0.65; }
  .ap-upload input { display: none; }

  .ap-actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 20px; }
  .ap-add, .ap-save, .ap-export { padding: 12px 22px; border-radius: 6px; cursor: pointer; font-family: inherit; font-size: 14px; font-weight: 600; transition: all 0.2s; }
  .ap-add { background: transparent; color: #fff; border: 1px solid rgba(107,130,196,0.4); }
  .ap-add:hover { background: rgba(107,130,196,0.15); }
  .ap-save { background: #559CD6; color: #fff; border: none; }
  .ap-save:hover:not(:disabled) { background: #4A8BC2; }
  .ap-export { background: #2e9e6b; color: #fff; border: none; }
  .ap-export:hover:not(:disabled) { background: #268057; }
  .ap-save:disabled, .ap-export:disabled { opacity: 0.6; cursor: default; }

  .ap-modal-backdrop {
    position: fixed; inset: 0; z-index: 1000; display: flex; align-items: center; justify-content: center;
    padding: 20px; background: rgba(4,7,24,0.78); backdrop-filter: blur(7px);
  }
  .ap-modal {
    width: 100%; max-width: 520px; padding: 30px; border-radius: 10px;
    background: #151C43; border: 1px solid rgba(107,130,196,0.3);
    box-shadow: 0 28px 80px rgba(0,0,0,0.5);
  }
  .ap-modal-icon {
    width: 42px; height: 42px; margin-bottom: 16px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    color: #77D394; background: rgba(74,174,105,0.12); border: 1px solid rgba(74,174,105,0.35);
    font-size: 20px; font-weight: 800;
  }
  .ap-modal h2 { margin: 0 0 10px; color: #fff; font-size: 21px; }
  .ap-modal p { margin: 0 0 14px; color: rgba(255,255,255,0.55); font-size: 13px; line-height: 1.6; }
  .ap-modal-event {
    margin-bottom: 12px; padding: 11px 13px; border-radius: 6px;
    background: rgba(8,12,36,0.45); color: rgba(255,255,255,0.82);
    font-size: 13px; font-weight: 600; line-height: 1.45;
  }
  .ap-modal-files {
    display: flex; flex-direction: column; gap: 6px; max-height: 190px; overflow-y: auto;
    margin: 0 0 24px; padding: 0; list-style: none;
  }
  .ap-modal-files li {
    display: flex; align-items: center; justify-content: space-between; gap: 12px;
    padding: 8px 10px; border-radius: 5px; border: 1px solid rgba(107,130,196,0.16);
    color: #AFC7F1; font-size: 12px;
  }
  .ap-modal-files li span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .ap-modal-files li small { flex-shrink: 0; color: rgba(255,255,255,0.35); }
  .ap-modal-actions { display: flex; justify-content: flex-end; gap: 10px; }
  .ap-modal-actions button {
    padding: 11px 17px; border-radius: 6px; font-family: inherit;
    font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s;
  }
  .ap-modal-cancel { color: rgba(255,255,255,0.7); background: transparent; border: 1px solid rgba(107,130,196,0.35); }
  .ap-modal-cancel:hover { color: #fff; background: rgba(107,130,196,0.12); }
  .ap-modal-confirm { color: #fff; background: #3C9D5D; border: 1px solid #3C9D5D; }
  .ap-modal-confirm:hover { background: #348A51; border-color: #348A51; }

  .ap-toast {
    position: fixed; bottom: 28px; left: 50%; transform: translateX(-50%);
    padding: 14px 22px; border-radius: 8px; background: #1a3a2a;
    border: 1px solid rgba(127,193,143,0.5); color: #fff; font-size: 13px; max-width: 90vw;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
  }
  .ap-toast.err { background: #3a1a1a; border-color: rgba(224,138,138,0.5); }

  @media (max-width: 900px) {
    .ap-wrap { padding: 24px 16px 60px; }
    .ap-table { overflow-x: auto; }
    .ap-row { min-width: 820px; }
  }
  @media (max-width: 600px) {
    .ap-modal { padding: 22px 18px; }
    .ap-modal-actions { flex-direction: column-reverse; }
    .ap-modal-actions button { width: 100%; }
  }
`;a.s(["default",0,function(){let[a,l]=(0,d.useState)(!1),[m,n]=(0,d.useState)(""),[o,p]=(0,d.useState)(!1),[q,r]=(0,d.useState)(null),[s,t]=(0,d.useState)(!1),[u,v]=(0,d.useState)(!1),[w,x]=(0,d.useState)(!1),[y,z]=(0,d.useState)(null),[A,B]=(0,d.useState)([]),[C,D]=(0,d.useState)(null),[E,F]=(0,d.useState)(e.DAYS[0].id),[G,H]=(0,d.useState)(e.HALLS[0]),[I,J]=(0,d.useState)([]),[K,L]=(0,d.useState)(null),[M,N]=(0,d.useState)(!0);async function O(a){t(!0),r(null);try{let b=await fetch(`/api/admin/program?pw=${encodeURIComponent(a)}`),c=await b.json();if(b.ok&&c.ok){let b=Array.isArray(c.items)?c.items:function(){let a=[],b=0;for(let c of e.PROGRAM)if(c.talks&&c.talks.length)for(let d of c.talks)a.push({id:b++,day:c.day,hall:c.hall,start:d.start,end:d.end,title:d.title,speaker:d.speaker??"",type:d.kind??"доклад"});else a.push({id:b++,day:c.day,hall:c.hall,start:c.start,end:c.end,title:c.title,speaker:c.moderators??"",type:"сессия"===c.kind?"доклад":c.kind});return a}();J(b.map(a=>({...a,attachments:Array.isArray(a.attachments)?a.attachments:[],verified:!0===a.verified}))),p(!0);try{sessionStorage.setItem(h,a)}catch{}}else{p(!1),r(c.message||"Неверный пароль.");try{sessionStorage.removeItem(h)}catch{}}}catch{r("Ошибка соединения.")}finally{t(!1)}}(0,d.useEffect)(()=>{l(!0);try{let a=sessionStorage.getItem(h);a&&(n(a),O(a))}catch{}},[]),(0,d.useEffect)(()=>{if(null===C)return;let a=a=>{"Escape"===a.key&&D(null)};return window.addEventListener("keydown",a),()=>window.removeEventListener("keydown",a)},[C]);let P=(0,d.useMemo)(()=>I.filter(a=>a.day===E&&a.hall===G),[I,E,G]),Q=(a,b)=>J(c=>c.map(c=>c.id===a?{...c,...b,verified:!1}:c)),R=(a,b)=>J(c=>c.map(c=>c.id===a?{...c,verified:b}:c)),S=(a,b)=>{J(c=>{let d=c.filter(a=>a.day===E&&a.hall===G).map(a=>a.id),e=d.indexOf(a)+b;if(e<0||e>=d.length)return c;let f=c.findIndex(b=>b.id===a),g=c.findIndex(a=>a.id===d[e]);if(-1===f||-1===g)return c;let h=[...c];return[h[f],h[g]]=[h[g],h[f]],h})},T=(a,b)=>{L(a),N(b),setTimeout(()=>L(null),3500)},U=async()=>{v(!0);try{let a=await fetch(`/api/admin/program?pw=${encodeURIComponent(m)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:I})}),b=await a.json();if(a.ok&&b.ok){let a=[...A];a.length&&(await Promise.all(a.map(a=>fetch(`/api/admin/program/files?pw=${encodeURIComponent(m)}&file=${encodeURIComponent(a)}`,{method:"DELETE"}).catch(()=>null))),B(b=>b.filter(b=>!a.includes(b)))),T("Сохранено успешно.",!0)}else T(b.message||"Ошибка сохранения.",!1)}catch{T("Ошибка соединения.",!1)}finally{v(!1)}},V=async()=>{x(!0);try{let a=e.DAYS.flatMap(a=>e.HALLS.flatMap(b=>I.filter(c=>c.day===a.id&&c.hall===b))),b=await fetch(`/api/admin/program/export?pw=${encodeURIComponent(m)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:a})});if(!b.ok){let a=await b.json().catch(()=>null);T(a?.message||"Ошибка выгрузки.",!1);return}let c=await b.blob(),d=URL.createObjectURL(c),f=document.createElement("a");f.href=d,f.download=`raspisanie-glp-planet-2026-${new Date().toISOString().slice(0,10)}.xlsx`,document.body.appendChild(f),f.click(),f.remove(),URL.revokeObjectURL(d),T("Расписание выгружено в Excel.",!0)}catch{T("Ошибка соединения.",!1)}finally{x(!1)}},W=async(a,b)=>{if(!b?.length)return;z(a);let c=[],d=[];try{for(let a of Array.from(b)){let b=new FormData;b.append("file",a);try{let e=await fetch(`/api/admin/program/files?pw=${encodeURIComponent(m)}`,{method:"POST",body:b}),f=await e.json().catch(()=>null);if(!e.ok||!f?.attachment){d.push(f?.message||`${a.name}: ошибка загрузки`);continue}c.push(f.attachment)}catch{d.push(`${a.name}: ошибка соединения`)}}c.length&&J(b=>b.map(b=>b.id===a?{...b,attachments:[...b.attachments??[],...c],verified:!1}:b)),d.length?T(c.length?`Загружено: ${c.length}. Ошибок: ${d.length}.`:d[0],!1):T(`Файлы загружены: ${c.length}. Нажмите \xabСохранить\xbb.`,!0)}finally{z(null)}},X=a=>a<1024?`${a} Б`:a<1048576?`${Math.round(a/1024)} КБ`:`${(a/1048576).toFixed(1)} МБ`,Y=null===C?null:I.find(a=>a.id===C)??null,Z=a=>{let b=a.replace(/\D/g,"").slice(0,4);return b.length>2?b.slice(0,2)+":"+b.slice(2):b};return a?o?(0,b.jsxs)("div",{className:"ap-wrap",children:[(0,b.jsxs)("header",{className:"ap-top",children:[(0,b.jsxs)("div",{className:"ap-top-left",children:[(0,b.jsx)("div",{className:"ap-brand",children:"GLP-PLANET · Админ"}),(0,b.jsx)("h1",{className:"ap-h1",children:"Расписание конференции"})]}),(0,b.jsxs)("div",{className:"ap-top-right",children:[(0,b.jsx)(c.default,{href:"/admin/registrations",className:"ap-link",children:"Заявки на МК"}),(0,b.jsx)(c.default,{href:"/schedule",className:"ap-link",target:"_blank",children:"Публичная страница ↗"}),(0,b.jsx)("button",{className:"ap-link",onClick:()=>{try{sessionStorage.removeItem(h)}catch{}p(!1),n("")},children:"Выйти"})]})]}),(0,b.jsxs)("div",{className:"ap-controls",children:[(0,b.jsx)("div",{className:"ap-seg",children:e.DAYS.map(a=>(0,b.jsx)("button",{className:`ap-seg-btn${a.id===E?" active":""}`,onClick:()=>F(a.id),children:a.label},a.id))}),(0,b.jsx)("div",{className:"ap-seg",children:e.HALLS.map(a=>(0,b.jsx)("button",{className:`ap-seg-btn${a===G?" active":""}`,onClick:()=>H(a),children:a},a))})]}),(0,b.jsxs)("div",{className:"ap-table",children:[(0,b.jsxs)("div",{className:"ap-row ap-head",children:[(0,b.jsx)("div",{}),(0,b.jsx)("div",{children:"Начало"}),(0,b.jsx)("div",{children:"Конец"}),(0,b.jsx)("div",{children:"Тип"}),(0,b.jsx)("div",{children:"Название"}),(0,b.jsx)("div",{children:"Докладчик / организация"}),(0,b.jsx)("div",{})]}),0===P.length&&(0,b.jsx)("div",{className:"ap-empty",children:"В этом зале на выбранный день событий нет. Нажмите «Добавить»."}),P.map((a,c)=>(0,b.jsxs)("div",{className:`ap-row${"доклад снят"===a.type?" row-removed":"доклад онлайн"===a.type?" row-online":""}${(a.attachments?.length??0)>0&&!0!==a.verified?" status-pending":(a.attachments?.length??0)>0&&!0===a.verified?" status-verified":""}`,children:[(0,b.jsxs)("div",{className:"ap-move",children:[(0,b.jsx)("button",{className:"ap-mv-btn",onClick:()=>S(a.id,-1),disabled:0===c,title:"Вверх",children:"↑"}),(0,b.jsx)("button",{className:"ap-mv-btn",onClick:()=>S(a.id,1),disabled:c===P.length-1,title:"Вниз",children:"↓"})]}),(0,b.jsx)("input",{className:"ap-in ap-time",value:a.start,placeholder:"10:00",inputMode:"numeric",maxLength:5,onChange:b=>Q(a.id,{start:Z(b.target.value)})}),(0,b.jsx)("input",{className:"ap-in ap-time",value:a.end,placeholder:"11:30",inputMode:"numeric",maxLength:5,onChange:b=>Q(a.id,{end:Z(b.target.value)})}),(0,b.jsx)("select",{className:"ap-in",value:a.type,onChange:b=>Q(a.id,{type:b.target.value}),style:{color:g[a.type]??"inherit"},children:f.map(a=>(0,b.jsx)("option",{value:a,style:{color:g[a]??"#fff"},children:a},a))}),(0,b.jsx)("textarea",{className:"ap-in ap-area",rows:2,value:a.title,placeholder:"Название",onChange:b=>Q(a.id,{title:b.target.value})}),(0,b.jsx)("textarea",{className:"ap-in ap-area",rows:2,value:a.speaker,placeholder:"—",onChange:b=>Q(a.id,{speaker:b.target.value})}),(0,b.jsx)("button",{className:"ap-del",onClick:()=>{var b;let c;return b=a.id,void((c=I.find(a=>a.id===b)?.attachments?.map(a=>a.id)??[]).length&&B(a=>[...new Set([...a,...c])]),J(a=>a.filter(a=>a.id!==b)))},title:"Удалить","aria-label":"Удалить",children:"✕"}),(0,b.jsxs)("div",{className:"ap-item-tools",children:[(a.attachments?.length??0)>0&&(0,b.jsxs)("label",{className:`ap-review-check${!0===a.verified?" checked":""}`,children:[(0,b.jsx)("input",{type:"checkbox",checked:!0===a.verified,onChange:b=>{b.target.checked?D(a.id):R(a.id,!1)}}),(0,b.jsx)("span",{children:!0===a.verified?"Проверено":"Не проверено"})]}),(0,b.jsx)("div",{className:"ap-files",children:(a.attachments??[]).map(c=>(0,b.jsxs)("div",{className:"ap-file",children:[(0,b.jsxs)("a",{href:c.url,target:"_blank",rel:"noopener noreferrer",title:c.name,children:[(0,b.jsx)("span",{className:"ap-file-name",children:c.name}),(0,b.jsx)("span",{className:"ap-file-size",children:X(c.size)})]}),(0,b.jsx)("button",{type:"button",onClick:()=>{var b,d;return b=a.id,d=c.id,void(B(a=>[...new Set([...a,d])]),J(a=>a.map(a=>a.id===b?{...a,attachments:(a.attachments??[]).filter(a=>a.id!==d),verified:!1}:a)))},title:"Открепить файл","aria-label":`Открепить ${c.name}`,children:"×"})]},c.id))}),(0,b.jsxs)("label",{className:`ap-upload${y===a.id?" loading":""}`,children:[(0,b.jsx)("input",{type:"file",multiple:!0,disabled:null!==y,accept:".pdf,.ppt,.pptx,.doc,.docx,.xls,.xlsx,.csv,.txt,.rtf,.zip,.rar,.7z,.jpg,.jpeg,.png,.webp,.mp4",onChange:b=>{W(a.id,b.target.files),b.currentTarget.value=""}}),y===a.id?"Загрузка…":"+ Прикрепить файлы"]})]})]},a.id))]}),(0,b.jsxs)("div",{className:"ap-actions",children:[(0,b.jsx)("button",{className:"ap-add",onClick:()=>J(a=>[...a,{id:++i,day:E,hall:G,start:"",end:"",title:"",speaker:"",type:"доклад",attachments:[],verified:!1}]),children:"+ Добавить строку"}),(0,b.jsx)("button",{className:"ap-save",onClick:U,disabled:u,children:u?"Сохранение…":"Сохранить"}),(0,b.jsx)("button",{className:"ap-export",onClick:V,disabled:w,children:w?"Выгрузка…":"Выгрузить в Excel"})]}),Y&&(0,b.jsx)("div",{className:"ap-modal-backdrop",onMouseDown:a=>{a.target===a.currentTarget&&D(null)},children:(0,b.jsxs)("div",{className:"ap-modal",role:"dialog","aria-modal":"true","aria-labelledby":"verify-modal-title",children:[(0,b.jsx)("div",{className:"ap-modal-icon",children:"✓"}),(0,b.jsx)("h2",{id:"verify-modal-title",children:"Подтвердить проверку файлов?"}),(0,b.jsx)("p",{children:"Убедитесь, что вы открыли и проверили все файлы, прикреплённые к мероприятию:"}),(0,b.jsx)("div",{className:"ap-modal-event",children:Y.title||"Без названия"}),(0,b.jsx)("ul",{className:"ap-modal-files",children:(Y.attachments??[]).map(a=>(0,b.jsxs)("li",{children:[(0,b.jsx)("span",{children:a.name}),(0,b.jsx)("small",{children:X(a.size)})]},a.id))}),(0,b.jsxs)("div",{className:"ap-modal-actions",children:[(0,b.jsx)("button",{type:"button",className:"ap-modal-cancel",onClick:()=>D(null),children:"Отмена"}),(0,b.jsx)("button",{type:"button",className:"ap-modal-confirm",onClick:()=>{R(Y.id,!0),D(null)},autoFocus:!0,children:"Да, файлы проверены"})]})]})}),K&&(0,b.jsx)("div",{className:`ap-toast${M?"":" err"}`,children:K}),(0,b.jsx)("style",{children:k})]}):(0,b.jsxs)("main",{className:"al-main",children:[(0,b.jsxs)("div",{className:"al-card",children:[(0,b.jsx)("div",{className:"al-brand",children:"GLP-PLANET · Админ"}),(0,b.jsx)("h1",{className:"al-title",children:"Расписание конференции"}),(0,b.jsx)("p",{className:"al-sub",children:"Введите пароль администратора"}),(0,b.jsxs)("form",{className:"al-form",onSubmit:a=>{a.preventDefault(),O(m)},children:[(0,b.jsxs)("label",{className:"al-field",children:[(0,b.jsx)("span",{children:"Пароль"}),(0,b.jsx)("input",{type:"password",value:m,onChange:a=>n(a.target.value),placeholder:"••••••••",autoFocus:!0,autoComplete:"off"})]}),q&&(0,b.jsx)("div",{className:"al-err",children:q}),(0,b.jsx)("button",{type:"submit",className:"al-btn",disabled:s||!m,children:s?"Проверка…":"Войти"})]}),(0,b.jsx)(c.default,{href:"/",className:"al-back",children:"← На главную"})]}),(0,b.jsx)("style",{children:j})]}):null}])}];

//# sourceMappingURL=app_admin_program_page_tsx_0_1bbp6._.js.map