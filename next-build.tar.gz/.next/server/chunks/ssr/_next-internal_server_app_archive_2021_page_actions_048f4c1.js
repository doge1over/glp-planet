module.exports=[68242,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2021_page_actions_048f4c1.js.map