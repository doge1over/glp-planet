module.exports=[38067,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Header.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Header.tsx <module evaluation>","default")},16100,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Header.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Header.tsx","default")},21680,a=>{"use strict";a.i(38067);var b=a.i(16100);a.n(b)},40471,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Footer.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx <module evaluation>","default")},34497,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Footer.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx","default")},91677,a=>{"use strict";a.i(40471);var b=a.i(34497);a.n(b)},91160,a=>{"use strict";var b=a.i(7997),c=a.i(21680),d=a.i(91677);let e="https://glp-planet.com/wp-content/uploads/2025/07",f=[{author:"Крышень К.Л.",href:`${e}/kryshen_prezentacziya.pdf`},{author:"Рождественский Д.А.",href:`${e}/rozhdestvenskij_prezentacziya.pdf`},{author:"Таубэ А.А.",href:`${e}/taube_prezentacziya.pdf`},{author:"Устюгов А.А.",href:`${e}/ustyugov_prezentacziya.pdf`},{author:"Дейкин А.В.",href:`${e}/dejkin_prezentacziya.pdf`},{author:"Тулупова Е.В.",href:`${e}/tulupova_prezentacziya.pdf`},{author:"Стрелкова М.В.",href:`${e}/strelkova_prezentacziya.pdf`},{author:"Рябцев С.Е.",href:`${e}/ryabczev_prezentacziya.pdf`},{author:"Попова М.О.",href:`${e}/popova_prezentacziya.pdf`},{author:"Плешков Д.Н.",href:`${e}/pleshkov_prezentacziya.pdf`},{author:"Платонова О.И.",href:`${e}/platonova_prezentacziya.pdf`},{author:"Лукинов Ю.А.",href:`${e}/lukinov_prezentacziya.pdf`},{author:"Васютина М.Л.",href:`${e}/vasyutina_prezentacziya.pdf`},{author:"Павлов А.Ю.",href:`${e}/pavlov_prezentacziya.pdf`},{author:"Салминьш Д.А.",href:`${e}/salminsh_prezentacziya.pdf`},{author:"Косоногов И.И.",href:`${e}/kosonogov_prezentacziya.pdf`},{author:"Кильдибеков К.Ю.",href:`${e}/kildibekov_prezentacziya.pdf`},{author:"Волков А.В.",href:`${e}/volkov_prezentacziya.pdf`},{author:"Варнакова Л.А.",href:`${e}/varnakova_prezentacziya.pdf`},{author:"Сапрыкина",href:`${e}/saprykina_prezentacziya.pdf`},{author:"Рыжков И.А.",href:`${e}/ryzhkov_prezentacziya.pdf`},{author:"Носова",href:`${e}/nosova_prezentacziya.pdf`},{author:"Мазукина Е.В.",href:`${e}/mazukina_prezentacziya.pdf`},{author:"Литвинов",href:`${e}/litvinov_titul.jpg`},{author:"Кукушкина",href:`${e}/kukushkina_prezentacziya.pdf`},{author:"Карачевцева Д.М.",href:`${e}/karachevczeva_prezentacziya.pdf`},{author:"Ефимова",href:`${e}/efimova_prezentacziya.pdf`},{author:"Селиванова",href:`${e}/selivanova_prezentacziya.pdf`},{author:"Трещалин",href:`${e}/treshhalin_prezentacziya.pdf`},{author:"Фонова",href:`${e}/fonova_prezentacziya.pdf`},{author:"Головина",href:`${e}/golovina_prezentacziya.pdf`},{author:"Родионова К.Н.",href:`${e}/rodionova_prezentacziya.pdf`},{author:"Бородина А.Ю.",href:`${e}/borodina_prezentacziya.pdf`},{author:"Акимов Д.Ю.",href:`${e}/akimov_prezentacziya.pdf`},{author:"Шохин",href:`${e}/shohin_prezentacziya.pdf`},{author:"Ходько С.В.",href:`${e}/hodko_prezentacziya.pdf`},{author:"Торопова Я.Г.",href:`${e}/toropova_prezentacziya.pdf`},{author:"Тернинко",href:`${e}/terninko_prezentacziya.pdf`},{author:"Суханов И.М.",href:`${e}/suhanov_prezentacziya.pdf`},{author:"Сорокина Е.Ю., Солодовников А.Г.",href:`${e}/sorokina_solodovnikov_prezentacziya.pdf`},{author:"Попов В.С.",href:`${e}/popov_prezentacziya.pdf`},{author:"Полозкова",href:`${e}/polozkova_prezentacziya.pdf`},{author:"Милутинович К.С.",href:`${e}/milutinovich_prezentacziya.pdf`},{author:"Макарова М.Н.",href:`${e}/makarova_prezentacziya.pdf`},{author:"Майер А.И.",href:`${e}/majer_prezentacziya.pdf`},{author:"Лужанин В.Г.",href:`${e}/luzhanin_prezentacziya.pdf`},{author:"Комогоров",href:`${e}/komogorov_prezentacziya.pdf`},{author:"Ковалева",href:`${e}/kovaleva_prezentacziya.pdf`},{author:"Гущин",href:`${e}/gushhin_prezentacziya.pdf`},{author:"Гиба И.С.",href:`${e}/giba_prezentacziya.pdf`},{author:"Багаева Н.С.",href:`${e}/bagaeva_prezentacziya.pdf`},{author:"Авдеева",href:`${e}/avdeeva_prezentacziya.pdf`},{author:"Лычева Н.А.",href:`${e}/lycheva_prezentacziya.pdf`},{author:"Денисова",href:`${e}/denisova_prezentacziya.pdf`},{author:"Исакова-Сивак",href:`${e}/isakova-sivak_prezentacziya.pdf`},{author:"Кательникова А.Е.",href:`${e}/katelnikova_prezentacziya-1.pdf`},{author:"Ладыгина",href:`${e}/ladygina_prezentacziya.pdf`},{author:"Матуа А.З.",href:`${e}/matua_prezentacziya.pdf`},{author:"Сазонова",href:`${e}/sazonova_prezentacziya.pdf`},{author:"Сивак",href:`${e}/sivak_prezentacziya.pdf`},{author:"Стосман",href:`${e}/stosman_prezentacziya.pdf`},{author:"Суханова",href:`${e}/suhanova_prezentacziya.pdf`},{author:"Штро",href:`${e}/shtro_prezentacziya.pdf`},{author:"Гордейчук",href:`${e}/gordejchuk_prezentacziya.pdf`},{author:"Мун В.В.",href:`${e}/mun_prezentacziya.pdf`},{author:"Егорихина М.Н.",href:`${e}/egorihina_prezentacziya.pdf`},{author:"Григорьева О.А.",href:`${e}/grigoreva_prezentacziya.pdf`},{author:"Зайцева М.А.",href:`${e}/zajczeva_prezentacziya.pdf`},{author:"Монакова А.О.",href:`${e}/monakova_prezentacziya.pdf`},{author:"Комаров",href:`${e}/komarov_prezentacziya.pdf`},{author:"Чернышенко",href:`${e}/chernyshenko_prezentacziya.pdf`},{author:"Щелгачева-Арчакова",href:`${e}/shhelgacheva-archakova_prezentacziya.pdf`},{author:"Фаустова",href:`${e}/faustova_prezentacziya.pdf`},{author:"Михайлова",href:`${e}/mihajlova_prezentacziya.pdf`},{author:"Устенко Ж.Ю.",href:`${e}/ustenko_prezentacziya.pdf`},{author:"Косман",href:`${e}/kosman_prezentacziya.pdf`},{author:"Валуев И.А.",href:`${e}/valuev_prezentacziya.pdf`},{author:"Зелинская",href:`${e}/zelinskaya_prezentacziya.pdf`},{author:"Смирягин",href:`${e}/smiryagin_prezentacziya.pdf`},{author:"Старшинова А.А.",href:`${e}/starshinova_prezentacziya.pdf`},{author:"Князева (Федорова) И.В.",href:`${e}/knyazevafedorova_prezentacziya.pdf`},{author:"Бикчурина Е.В.",href:`${e}/bikchurina_prezentacziya.pdf`},{author:"Савостьянова Е.В.",href:`${e}/savostyanova_prezentacziya.pdf`},{author:"Кательникова А.Е.",title:"Доклад (2)",href:`${e}/katelnikova_prezentacziya.pdf`},{author:"Углева Е.М.",href:`${e}/ugleva_prezentacziya.pdf`},{author:"Павлова А.Н.",href:`${e}/pavlova_prezentacziya.pdf`},{author:"Шалов",href:`${e}/shalov_prezentacziya.pdf`},{author:"Михель А.В.",href:`${e}/mihel_prezentacziya.pdf`},{author:"Диффинэ Е.А.",href:`${e}/diffine_prezentacziya.pdf`},{author:"Есенеева Я.К.",href:`${e}/eseneeva_prezentacziya.pdf`},{author:"Чалышева",href:`${e}/chalysheva_prezentacziya.pdf`},{author:"Торкунова Е.В.",href:`${e}/torkunova_prezentacziya.pdf`},{author:"Снежкова Ю.В.",href:`${e}/snezhkova_prezentacziya.pdf`},{author:"Маршан",href:`${e}/marshan_prezentacziya.pdf`},{author:"Валлин Е.Ж.",href:`${e}/vallin_prezentacziya.pdf`},{author:"Карнакова П.К.",href:`${e}/karnakova_prezentacziya.pdf`},{author:"Домнина Т.Н.",href:`${e}/domnina_prezentacziya.pdf`},{author:"Семушина",href:`${e}/semushina_prezentacziya.pdf`},{author:"Наделяева",href:`${e}/nadelyaeva_prezentacziya.pdf`},{author:"Кушнир",href:`${e}/kushnir_prezentacziya.pdf`},{author:"Казакова",href:`${e}/kazakova_prezentacziya.pdf`},{author:"Брызгалина",href:`${e}/bryzgalina_prezentacziya.pdf`},{author:"Белозерцева",href:`${e}/belozerczeva_prezentacziya.pdf`},{author:"Андяржанова",href:`${e}/andyarzhanova_-prezentacziya.pdf`},{author:"Акимов Д.Ю.",title:"Доклад (2)",href:`${e}/akimov_prezentacziya-1.pdf`},{author:"Зиновьев С.В.",href:`${e}/zinovev_prezentacziya.pdf`},{author:"Воротилов",href:`${e}/vorotilov_prezentacziya.pdf`},{author:"Абзалов",href:`${e}/abzalov_prezentacziya.pdf`},{author:"Карпов",href:`${e}/karpov_prezetacziya.pdf`},{author:"Качалов",href:`${e}/kachalov_prezentacziya.pdf`},{author:"Кузьмина",href:`${e}/kuzmina_prezentacziya.pdf`},{author:"Матичин А.А.",href:`${e}/matichin_prezentacziya.pdf`},{author:"Мизгирев",href:`${e}/mizgirev_prezentacziya.pdf`},{author:"Муразов Я.Г.",href:`${e}/murazov_prezentacziya.pdf`},{author:"Мурашова",href:`${e}/murashova_prezentacziya.pdf`},{author:"Пашинская",href:`${e}/pashinskaya_prezentacziya.pdf`},{author:"Подьячева",href:`${e}/podyacheva_prezentacziya.pdf`},{author:"Пугач В.А.",href:`${e}/pugach_prezentacziya.pdf`},{author:"Смирнова",href:`${e}/smirnova_prezentacziya.pdf`},{author:"Тильченко Д.А.",href:`${e}/tilchenko_prezentacziya.pdf`},{author:"Шамаев Н.Д.",href:`${e}/shamaev_prezentacziya.pdf`},{author:"Шумега",href:`${e}/shumega_prezentacziya.pdf`},{author:"Ярушкина, Пунин",href:`${e}/yarushkina_punin_prezentacziya.pdf`},{author:"Гоглева",href:`${e}/gogleva_prezentacziya.pdf`},{author:"Корочкина",href:`${e}/korochkina_prezentacziya.pdf`},{author:"Акимова М.А.",href:`${e}/akimova_prezentacziya.pdf`},{author:"Бабенко",href:`${e}/babenko_prezentacziya.pdf`},{author:"Вербицкая Е.В.",href:`${e}/verbiczkaya_prezentacziya.pdf`},{author:"Каранина",href:`${e}/karanina_prezentacziya.pdf`},{author:"Крепкова",href:`${e}/krepkova_prezentacziya.pdf`},{author:"Пастухова",href:`${e}/pastuhova_prezentacziya.pdf`},{author:"Перебоева",href:`${e}/pereboeva_prezentacziya.pdf`},{author:"Филиппова",href:`${e}/filippova_prezentacziya.pdf`},{author:"Хоцькина",href:`${e}/hoczkina_prezentacziya.pdf`},{author:"Потапова",href:`${e}/potapova_prezentacziya.pdf`}];a.s(["default",0,function(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(c.default,{}),(0,b.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,b.jsx)("section",{className:"c25-hero",children:(0,b.jsxs)("div",{className:"c25-container",children:[(0,b.jsx)("div",{className:"c25-label",children:"VI Конференция · 2025"}),(0,b.jsx)("h1",{className:"c25-hero-title",children:"GLP-Planet конференция 6.0"}),(0,b.jsxs)("div",{className:"c25-hero-meta",children:[(0,b.jsx)("span",{children:"2–4 июля 2025"}),(0,b.jsx)("span",{className:"c25-dot",children:"·"}),(0,b.jsx)("span",{children:"г. Санкт-Петербург, Россия"})]})]})}),(0,b.jsx)("section",{className:"c25-about",children:(0,b.jsxs)("div",{className:"c25-container",children:[(0,b.jsx)("h2",{className:"c25-section-title",children:"О конференции"}),(0,b.jsx)("div",{className:"c25-divider"}),(0,b.jsxs)("div",{className:"c25-text",children:[(0,b.jsxs)("p",{children:["02.07 — 04.07.2025 г. в Санкт-Петербурге прошла"," ",(0,b.jsx)("strong",{children:"VI Международная научно-практическая конференция GLP-PLANET, совместно с Русской ассоциацией специалистов по лабораторным животным (Rus-LASA)"}),". В работе конференции приняли участие специалисты научно-исследовательских институтов и испытательных центров, ВУЗов, фармацевтических компаний, питомников, поставщики оборудования и расходных материалов, независимые эксперты и представители регуляторных органов из"," ",(0,b.jsx)("strong",{children:"34 городов России"}),", а также Абхазии, Беларуси, Грузии, Китая, Кубы, Сербии, Узбекистана и ЮАР. GLP-PLANET собрала более ",(0,b.jsx)("strong",{children:"500 человек"}),". За три дня участники могли посетить"," ",(0,b.jsx)("strong",{children:"13 сессий и 9 мастер-классов"}),"."]}),(0,b.jsx)("p",{children:"По результатам голосования состоялось награждение лучших лекторов."}),(0,b.jsx)("p",{children:(0,b.jsx)("strong",{children:"Организационный комитет выражает благодарность спонсорам, лекторам и участникам. До встречи в следующем году!"})})]})]})}),(0,b.jsx)("section",{className:"c25-materials",children:(0,b.jsxs)("div",{className:"c25-container",children:[(0,b.jsx)("h2",{className:"c25-section-title c25-section-title--dark",children:"Материалы конференции"}),(0,b.jsx)("div",{className:"c25-divider c25-divider--dark"}),(0,b.jsx)("div",{className:"c25-grid",children:f.map((a,c)=>(0,b.jsxs)("a",{href:a.href,target:"_blank",rel:"noopener noreferrer",className:"c25-card",children:[(0,b.jsxs)("div",{className:"c25-card-thumb",children:[(0,b.jsxs)("svg",{width:"28",height:"28",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,b.jsx)("path",{d:"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"}),(0,b.jsx)("polyline",{points:"14,2 14,8 20,8"}),(0,b.jsx)("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),(0,b.jsx)("line",{x1:"16",y1:"17",x2:"8",y2:"17"})]}),(0,b.jsx)("span",{className:"c25-card-pdf",children:"PDF"})]}),(0,b.jsxs)("div",{className:"c25-card-info",children:[(0,b.jsx)("div",{className:"c25-card-author",children:a.author}),(0,b.jsx)("div",{className:"c25-card-title",children:a.title||"Доклад"})]})]},c))})]})})]}),(0,b.jsx)(d.default,{}),(0,b.jsx)("style",{children:`
        /* ── Layout ── */
        .c25-container { max-width: 1000px; margin: 0 auto; }

        /* ── Hero ── */
        .c25-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .c25-label {
          font-size: 11px; color: #6B82C4; font-weight: 600;
          text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px;
        }
        .c25-hero-title {
          font-size: 42px; font-weight: 700; color: #fff;
          line-height: 1.2; margin-bottom: 16px;
        }
        .c25-hero-meta {
          font-size: 15px; color: rgba(255,255,255,0.4);
          display: flex; align-items: center; gap: 0;
        }
        .c25-dot { margin: 0 10px; color: #6B82C4; }

        /* ── About ── */
        .c25-about {
          padding: 80px 48px;
          background: linear-gradient(155deg, #0D1330 0%, #141B4D 50%, #1A2460 100%);
        }
        .c25-section-title {
          font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 16px;
        }
        .c25-divider {
          width: 40px; height: 3px; background: var(--secondary, #4964A2);
          border-radius: 1px; margin-bottom: 32px;
        }
        .c25-text { color: rgba(255,255,255,0.55); font-size: 15px; line-height: 1.85; }
        .c25-text p { margin-bottom: 16px; }
        .c25-text strong { color: rgba(255,255,255,0.8); }

        /* ── Materials ── */
        .c25-materials { padding: 80px 48px 100px; background: #fff; }
        .c25-section-title--dark { color: var(--primary, #141B4D); }
        .c25-divider--dark { background: var(--secondary, #4964A2); }

        .c25-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }

        .c25-card {
          display: block; text-decoration: none;
          border: 1px solid rgba(73,100,162,0.1);
          border-radius: 6px; overflow: hidden;
          transition: all 0.4s cubic-bezier(0.33,1,0.68,1);
        }
        .c25-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 16px 40px rgba(20,27,77,0.1);
          border-color: rgba(73,100,162,0.2);
        }

        .c25-card-thumb {
          aspect-ratio: 1.33;
          background: #F4F6FB;
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 8px; color: #8A9CC4;
        }
        .c25-card-pdf {
          font-size: 10px; font-weight: 700;
          letter-spacing: 2px; color: #8A9CC4;
        }

        .c25-card-info { padding: 14px 16px; }
        .c25-card-author {
          font-size: 13px; font-weight: 700;
          color: var(--primary, #141B4D); margin-bottom: 4px;
        }
        .c25-card-title { font-size: 11px; color: #888; }

        /* ── Responsive ── */
        @media (max-width: 1024px) {
          .c25-hero   { padding: 120px 32px 48px; }
          .c25-about  { padding: 60px 32px; }
          .c25-materials { padding: 60px 32px 80px; }
          .c25-hero-title { font-size: 34px; }
        }
        @media (max-width: 900px) {
          .c25-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 600px) {
          .c25-hero { padding: 100px 20px 40px; }
          .c25-hero-title { font-size: 28px; }
          .c25-hero-meta { flex-direction: column; align-items: flex-start; gap: 4px; font-size: 13px; }
          .c25-dot { display: none; }
          .c25-about  { padding: 48px 20px; }
          .c25-materials { padding: 40px 20px 60px; }
          .c25-grid { grid-template-columns: 1fr; }
          .c25-section-title { font-size: 24px; }
          .c25-text { font-size: 14px; }
        }
      `})]})},"metadata",0,{title:"GLP-Planet конференция 2025 — GLP-Planet",description:"VI Международная научно-практическая конференция GLP-Planet совместно с RUS-Lasa, 2–4 июля 2025 г., Санкт-Петербург"}])},90552,a=>{a.n(a.i(91160))}];

//# sourceMappingURL=_0li7ctc._.js.map