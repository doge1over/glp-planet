module.exports=[55200,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_consultant_page_actions_060du85.js.map