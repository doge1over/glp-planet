module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},38067,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Header.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Header.tsx <module evaluation>","default")},16100,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Header.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Header.tsx","default")},21680,a=>{"use strict";a.i(38067);var b=a.i(16100);a.n(b)},40471,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Footer.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx <module evaluation>","default")},34497,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/Footer.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx","default")},91677,a=>{"use strict";a.i(40471);var b=a.i(34497);a.n(b)},76789,a=>{a.v("/_next/static/media/apple-icon.06b5hegi~w45e.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},59310,a=>{"use strict";let b={src:a.i(76789).default,width:180,height:180};a.s(["default",0,b])},26758,a=>{a.v("/_next/static/media/favicon.0y7j9ngb5somr.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},38872,a=>{"use strict";let b={src:a.i(26758).default,width:256,height:256};a.s(["default",0,b])},71224,a=>{a.v("/_next/static/media/icon.03_uxo6ldu04c.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},1022,a=>{"use strict";let b={src:a.i(71224).default,width:512,height:512};a.s(["default",0,b])},78224,a=>{"use strict";var b=a.i(7997),c=a.i(21680),d=a.i(91677);let e=[{year:2021,cover:"/images/monographs/2021.jpg",pdf:"https://glp-planet.com/wp-content/uploads/2022/11/monografiya_consultant_glp-planet_2021_final_compressed.pdf"},{year:2022,cover:"/images/monographs/2022.jpg",pdf:"https://glp-planet.com/wp-content/uploads/2022/11/monografiya_consultant_glp-planet_2022f.pdf"},{year:2023,cover:"/images/monographs/2023.png",pdf:"https://cdn.glp-planet.com/2023/book/consultant-glp-planet-2023.pdf"},{year:2024,cover:"/images/monographs/2024.png",pdf:"https://cdn.glp-planet.com/2024/book/consultant-glp-planet-2024.pdf"},{year:2025,cover:"/images/monographs/2025.jpg",pdf:"https://cdn.glp-planet.com/2025/book/consultant-glp-planet-2025.pdf"}];a.s(["default",0,function(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(c.default,{}),(0,b.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,b.jsx)("section",{className:"consultant-hero",children:(0,b.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,b.jsx)("div",{style:{fontSize:11,color:"#6B82C4",fontWeight:600,textTransform:"uppercase",letterSpacing:3,marginBottom:12},children:"Монографии"}),(0,b.jsx)("h1",{className:"consultant-title",children:"Консультант GLP-PLANET"}),(0,b.jsx)("p",{style:{fontSize:16,color:"rgba(255,255,255,0.6)",lineHeight:1.8,maxWidth:620},children:"По итогам каждой конференции выпускается коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»"})]})}),(0,b.jsx)("section",{className:"consultant-content",children:(0,b.jsx)("div",{style:{maxWidth:1200,margin:"0 auto"},children:(0,b.jsx)("div",{className:"monographs-grid",children:e.map(a=>(0,b.jsxs)("a",{href:a.pdf,target:"_blank",rel:"noopener noreferrer",className:"monograph-card",children:[(0,b.jsxs)("div",{className:"monograph-cover",children:[(0,b.jsx)("img",{src:a.cover,alt:`Консультант GLP-PLANET ${a.year}`,style:{width:"100%",height:"100%",objectFit:"cover",display:"block"}}),(0,b.jsx)("div",{className:"monograph-overlay",children:(0,b.jsx)("div",{className:"monograph-overlay-btn",children:"Читать"})})]}),(0,b.jsxs)("div",{style:{padding:"20px 4px 12px",textAlign:"center"},children:[(0,b.jsx)("div",{style:{fontSize:14,fontWeight:600,color:"var(--primary)",letterSpacing:.5},children:"Консультант GLP-PLANET"}),(0,b.jsx)("div",{style:{fontSize:28,fontWeight:800,color:"var(--primary)",marginTop:4},children:a.year})]})]},a.year))})})})]}),(0,b.jsx)(d.default,{}),(0,b.jsx)("style",{children:`
        .consultant-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .consultant-title {
          font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px;
        }
        .consultant-content {
          padding: 80px 48px 100px;
        }
        .monographs-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 32px;
        }
        .monograph-card {
          text-decoration: none;
          display: block;
          transition: transform 0.6s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .monograph-card:hover {
          transform: translateY(-6px);
        }
        .monograph-cover {
          position: relative;
          border-radius: 6px;
          overflow: hidden;
          background: var(--light);
          aspect-ratio: 0.71;
          box-shadow: 0 6px 24px rgba(20, 27, 77, 0.1);
          transition: box-shadow 0.35s;
        }
        .monograph-card:hover .monograph-cover {
          box-shadow: 0 20px 50px rgba(20, 27, 77, 0.2);
        }
        .monograph-overlay {
          position: absolute;
          inset: 0;
          background: rgba(8, 12, 36, 0.75);
          display: flex;
          align-items: flex-end;
          justify-content: center;
          padding-bottom: 100px;
          opacity: 0;
          transition: opacity 0.3s;
        }
        .monograph-card:hover .monograph-overlay {
          opacity: 1;
        }
        .monograph-overlay-btn {
          padding: 12px 36px;
          border: 1.5px solid rgba(255,255,255,0.6);
          border-radius: 3px;
          color: #fff;
          font-size: 14px;
          font-weight: 600;
          letter-spacing: 1.5px;
          text-transform: uppercase;
          font-family: 'Exo 2', sans-serif;
          transition: background 0.3s, border-color 0.3s;
        }
        .monograph-overlay-btn:hover {
          background: rgba(255,255,255,0.15);
          border-color: #fff;
        }
        @media (max-width: 1024px) {
          .consultant-hero { padding: 120px 32px 48px; }
          .consultant-title { font-size: 34px; }
          .consultant-content { padding: 60px 32px 80px; }
        }
        @media (max-width: 1000px) {
          .monographs-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 24px;
          }
        }
        @media (max-width: 600px) {
          .consultant-hero { padding: 100px 20px 40px; }
          .consultant-title { font-size: 28px; }
          .consultant-content { padding: 40px 20px 60px; }
          .monographs-grid {
            grid-template-columns: 1fr;
            gap: 32px;
            max-width: 380px;
            margin: 0 auto;
          }

        }
      `})]})},"metadata",0,{title:"Консультант GLP-PLANET — Монографии",description:"Коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»"}])},56799,a=>{a.n(a.i(78224))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0424cn8._.js.map