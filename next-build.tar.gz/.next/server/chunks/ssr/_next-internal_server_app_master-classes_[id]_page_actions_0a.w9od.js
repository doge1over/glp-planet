module.exports=[80529,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_master-classes_%5Bid%5D_page_actions_0a.w9od.js.map