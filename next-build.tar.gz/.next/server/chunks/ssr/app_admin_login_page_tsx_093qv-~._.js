module.exports=[31068,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(72131);a.s(["default",0,function(){let[a,e]=(0,d.useState)(""),[f,g]=(0,d.useState)(null),[h,i]=(0,d.useState)(!1);async function j(b){b.preventDefault(),g(null),i(!0);try{let b=await fetch(`/api/admin/program?pw=${encodeURIComponent(a)}`),c=await b.json();if(b.ok&&c.ok){try{sessionStorage.setItem("ap_admin_pw_v1",a)}catch{}window.location.href="/admin/program"}else g(c.message||"Неверный пароль.")}catch{g("Ошибка соединения.")}finally{i(!1)}}return(0,b.jsxs)("main",{className:"al-main",children:[(0,b.jsxs)("div",{className:"al-card",children:[(0,b.jsx)("div",{className:"al-brand",children:"GLP-PLANET · Админ"}),(0,b.jsx)("h1",{className:"al-title",children:"Вход в панель"}),(0,b.jsx)("p",{className:"al-sub",children:"Расписание и управление конференцией"}),(0,b.jsxs)("form",{className:"al-form",onSubmit:j,children:[(0,b.jsxs)("label",{className:"al-field",children:[(0,b.jsx)("span",{children:"Пароль"}),(0,b.jsx)("input",{type:"password",value:a,onChange:a=>e(a.target.value),placeholder:"••••••••",autoFocus:!0,autoComplete:"off"})]}),f&&(0,b.jsx)("div",{className:"al-err",children:f}),(0,b.jsx)("button",{type:"submit",className:"al-btn",disabled:h||!a,children:h?"Проверка…":"Войти"})]}),(0,b.jsx)("div",{className:"al-divider"}),(0,b.jsx)("div",{className:"al-links",children:(0,b.jsx)(c.default,{href:"/admin/registrations",className:"al-alt-link",children:"Заявки на мастер-классы →"})}),(0,b.jsx)(c.default,{href:"/",className:"al-back",children:"← На главную"})]}),(0,b.jsx)("style",{children:`
        .al-main {
          min-height: 100vh; display: flex; align-items: center; justify-content: center;
          padding: 24px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 100%);
          font-family: 'Exo 2', sans-serif;
        }
        .al-card {
          width: 100%; max-width: 400px;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(107,130,196,0.2);
          border-radius: 10px;
          padding: 40px 36px;
        }
        .al-brand {
          font-size: 11px; letter-spacing: 3px; text-transform: uppercase;
          color: #6B82C4; font-weight: 600; margin-bottom: 16px;
        }
        .al-title { font-size: 26px; font-weight: 700; color: #fff; margin-bottom: 6px; }
        .al-sub { font-size: 14px; color: rgba(255,255,255,0.55); margin-bottom: 28px; }
        .al-form { display: flex; flex-direction: column; gap: 16px; }
        .al-field { display: flex; flex-direction: column; gap: 6px; }
        .al-field span {
          font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.7);
          text-transform: uppercase; letter-spacing: 1px;
        }
        .al-field input {
          padding: 12px 14px; border-radius: 6px;
          background: rgba(8,12,36,0.5);
          border: 1px solid rgba(107,130,196,0.25);
          color: #fff; font-size: 14px; font-family: inherit;
          outline: none; transition: border-color 0.2s;
        }
        .al-field input:focus { border-color: #559CD6; }
        .al-err { color: #E08A8A; font-size: 13px; font-weight: 600; }
        .al-btn {
          margin-top: 8px; padding: 13px; border-radius: 6px;
          background: #559CD6; color: #fff; border: none; cursor: pointer;
          font-size: 15px; font-weight: 600; font-family: inherit;
          transition: background 0.2s;
        }
        .al-btn:hover:not(:disabled) { background: #4A8BC2; }
        .al-btn:disabled { opacity: 0.55; cursor: default; }
        .al-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 24px 0; }
        .al-links { display: flex; flex-direction: column; gap: 10px; }
        .al-alt-link {
          color: rgba(255,255,255,0.5); font-size: 13px; text-decoration: none;
          transition: color 0.2s;
        }
        .al-alt-link:hover { color: #fff; }
        .al-back {
          display: block; margin-top: 24px; text-align: center;
          color: rgba(255,255,255,0.35); font-size: 13px; text-decoration: none;
          transition: color 0.2s;
        }
        .al-back:hover { color: #fff; }
      `})]})}])}];

//# sourceMappingURL=app_admin_login_page_tsx_093qv-~._.js.map