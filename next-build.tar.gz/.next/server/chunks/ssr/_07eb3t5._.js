module.exports=[33354,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}},37986,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(38679),e=a.i(783),f=a.i(42100);let g={доклад:"#559CD6","доклад онлайн":"#6FCF97","доклад снят":"#E08A8A",дискуссия:"#8B6FC4",перерыв:"#6B7280",обед:"#6B7280",выставка:"#3FA796",фуршет:"#C48B5A",собрание:"#C48B5A","мастер-класс":"#3FA796","круглый стол":"#8B6FC4",регистрация:"#6B7280",церемония:"#C48B5A"};a.s(["default",0,function(){let a,[h,i]=(0,c.useState)(f.DAYS[0].id),[j,k]=(0,c.useState)("Все"),[l,m]=(0,c.useState)(null),[n,o]=(0,c.useState)(()=>new Date);(0,c.useEffect)(()=>{let a=()=>fetch("/api/program").then(a=>a.json()).then(a=>{a.ok&&Array.isArray(a.items)&&m(a.items)}).catch(()=>{});a();let b=setInterval(a,6e4);return()=>clearInterval(b)},[]),(0,c.useEffect)(()=>{let a=setInterval(()=>o(new Date),6e4);return()=>clearInterval(a)},[]);let p=l?(a=new Set(l.filter(a=>a.day===h).map(a=>a.hall)),f.HALLS.filter(b=>a.has(b))):(0,f.hallsWithEvents)(h),q="Все"===j?p:p.filter(a=>a===j);return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(d.default,{}),(0,b.jsxs)("main",{className:"sc-main",children:[(0,b.jsx)("section",{className:"sc-hero",children:(0,b.jsxs)("div",{className:"sc-container",children:[(0,b.jsx)("div",{className:"sc-label",children:"Онлайн"}),(0,b.jsx)("h1",{className:"sc-title",children:"Расписание конференции"}),(0,b.jsx)("p",{className:"sc-subtitle",children:"Программа VII Международной научно-практической конференции GLP-PLANET. 1–3 июля 2026, отель «Санкт-Петербург», Пироговская наб., д. 5/2."})]})}),(0,b.jsx)("section",{className:"sc-body",children:(0,b.jsxs)("div",{className:"sc-container",children:[(0,b.jsx)("div",{className:"sc-days",children:f.DAYS.map(a=>(0,b.jsx)("button",{type:"button",className:`sc-day${a.id===h?" active":""}`,onClick:()=>i(a.id),children:a.label},a.id))}),(0,b.jsxs)("div",{className:"sc-halls",children:[(0,b.jsx)("button",{className:`sc-hall-chip${"Все"===j?" active":""}`,onClick:()=>k("Все"),children:"Все залы"}),p.map(a=>(0,b.jsxs)("button",{className:`sc-hall-chip${j===a?" active":""}`,onClick:()=>k(a),children:[a,!f.BROADCAST_HALLS.includes(a)&&(0,b.jsx)("span",{className:"sc-chip-note",children:"без трансляции"})]},a))]}),(0,b.jsx)("div",{className:"sc-list",children:q.map(a=>{let c=l?l.filter(b=>b.day===h&&b.hall===a).map(a=>({kind:"row",start:a.start,end:a.end,title:a.title,speaker:a.speaker||void 0,online:"доклад онлайн"===a.type,removed:"доклад снят"===a.type,type:a.type,attachments:!0===a.verified?a.attachments:[]})):function(a,b){let c=[];for(let d of(0,f.sessionsFor)(a,b))if(d.talks&&d.talks.length)for(let a of(c.push({kind:"label",title:d.title,moderators:d.moderators}),d.talks))c.push({kind:"row",start:a.start,end:a.end,title:a.title,speaker:a.speaker,online:a.online,type:a.kind});else{let a="сессия"===d.kind?"доклад":d.kind;c.push({kind:"row",start:d.start,end:d.end,title:d.title,speaker:d.moderators,type:a})}return c}(h,a),d=f.BROADCAST_HALLS.includes(a);return(0,b.jsxs)("div",{className:"sc-hall-group",children:[(0,b.jsxs)("div",{className:"sc-hall-head",children:[(0,b.jsxs)("span",{className:"sc-hall-name",children:["Зал «",a,"»"]}),(0,b.jsx)("span",{className:`sc-bc ${d?"on":"off"}`,children:d?"Трансляция":"Без трансляции"})]}),(0,b.jsx)("div",{className:"sc-rows",children:c.map((a,c)=>{let d,e,f,i;return"label"===a.kind?(0,b.jsxs)("div",{className:"sc-sess-label",children:[(0,b.jsx)("div",{className:"sc-sess-title",children:a.title}),a.moderators&&(0,b.jsxs)("div",{className:"sc-sess-mod",children:["Модераторы: ",a.moderators]})]},c):(e=!(d=a.removed||"доклад снят"===a.type)&&function(a,b){let[c,d]=b.split(":").map(Number),e=new Date(a);return e.setHours(c,d,0,0),n>e}(h,a.end),f=a.type??"доклад",i=g[a.type??"доклад"]??"#559CD6",(0,b.jsxs)("div",{className:`sc-talk${e?" past":""}${d?" removed":""}`,children:[(0,b.jsxs)("div",{className:"sc-talk-time",children:[a.start,(0,b.jsxs)("span",{children:["–",a.end]})]}),(0,b.jsxs)("div",{className:"sc-talk-main",children:[(0,b.jsxs)("div",{className:"sc-talk-tags",children:[(0,b.jsx)("span",{className:"sc-talk-type",style:{color:i,borderColor:i},children:f}),a.online&&!d&&(0,b.jsx)("span",{className:"sc-online",children:"онлайн"}),d&&(0,b.jsx)("span",{className:"sc-removed-badge",children:"снят"})]}),(0,b.jsx)("div",{className:`sc-talk-title${d?" sc-strikethrough":""}`,children:a.title}),a.speaker&&(0,b.jsx)("div",{className:"sc-talk-speaker",children:a.speaker}),!!a.attachments?.length&&(0,b.jsx)("div",{className:"sc-talk-files",children:a.attachments.map(a=>(0,b.jsxs)("a",{href:a.url,target:"_blank",rel:"noopener noreferrer",className:"sc-talk-file",children:[(0,b.jsxs)("svg",{width:"13",height:"13",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[(0,b.jsx)("path",{d:"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"}),(0,b.jsx)("polyline",{points:"14,2 14,8 20,8"})]}),(0,b.jsx)("span",{children:a.name})]},a.id))})]})]},c))})})]},a)})})]})})]}),(0,b.jsx)(e.default,{}),(0,b.jsx)("style",{children:`
        .sc-main { min-height: 100vh; background: #141B4D; }
        .sc-container { max-width: 1100px; margin: 0 auto; }

        .sc-hero { padding: 140px 48px 50px; background: linear-gradient(155deg, #080C24 0%, #141B4D 100%); }
        .sc-label { font-size: 11px; color: #6B82C4; font-weight: 600; text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px; }
        .sc-title { font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px; }
        .sc-subtitle { font-size: 15px; color: rgba(255,255,255,0.6); line-height: 1.7; max-width: 680px; }

        .sc-body { padding: 36px 48px 100px; }

        .sc-days { display: flex; gap: 10px; margin-bottom: 18px; flex-wrap: wrap; }
        .sc-day {
          padding: 10px 26px; border-radius: 4px; cursor: pointer;
          font-family: inherit; font-size: 15px; font-weight: 600; color: rgba(255,255,255,0.7);
          background: rgba(107,130,196,0.1); border: 1px solid rgba(107,130,196,0.2); transition: all 0.2s ease;
        }
        .sc-day:hover { color: #fff; background: rgba(107,130,196,0.2); }
        .sc-day.active { color: #fff; background: #559CD6; border-color: #559CD6; }

        .sc-halls { display: flex; gap: 8px; margin-bottom: 28px; flex-wrap: wrap; }
        .sc-hall-chip {
          display: inline-flex; align-items: center; gap: 8px; padding: 7px 16px; border-radius: 20px; cursor: pointer;
          font-family: inherit; font-size: 13px; font-weight: 500; color: rgba(255,255,255,0.65);
          background: transparent; border: 1px solid rgba(107,130,196,0.25); transition: all 0.2s ease;
        }
        .sc-hall-chip:hover { color: #fff; border-color: rgba(107,130,196,0.5); }
        .sc-hall-chip.active { color: #fff; background: rgba(85,156,214,0.18); border-color: #559CD6; }
        .sc-chip-note { font-size: 10px; color: rgba(255,255,255,0.4); }

        .sc-list { display: flex; flex-direction: column; gap: 36px; }
        .sc-hall-group { display: flex; flex-direction: column; }
        .sc-hall-head {
          display: flex; align-items: center; gap: 12px; padding-bottom: 10px; margin-bottom: 4px;
          border-bottom: 1px solid rgba(107,130,196,0.2);
        }
        .sc-hall-name { font-size: 19px; font-weight: 700; color: #fff; }
        .sc-bc { font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; padding: 3px 10px; border-radius: 3px; }
        .sc-bc.on { color: #6FCF97; background: rgba(63,167,150,0.15); border: 1px solid rgba(63,167,150,0.4); }
        .sc-bc.off { color: rgba(255,255,255,0.45); background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.12); }

        .sc-rows { display: flex; flex-direction: column; }

        .sc-sess-label { padding: 18px 14px 8px; }
        .sc-sess-title {
          font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;
          color: #6FA0D8; line-height: 1.5;
        }
        .sc-sess-mod { margin-top: 4px; font-size: 12px; color: rgba(255,255,255,0.45); line-height: 1.5; }

        .sc-talk {
          position: relative; display: flex; gap: 14px; padding: 12px 14px;
          border-top: 1px solid rgba(107,130,196,0.08);
        }
        .sc-talk:hover { background: rgba(8,12,36,0.35); }
        .sc-talk.past { opacity: 0.4; }
        .sc-talk.removed { opacity: 0.5; }

        .sc-talk-time {
          flex-shrink: 0; width: 92px; font-size: 13px; font-weight: 700; color: #fff;
          font-variant-numeric: tabular-nums; line-height: 1.4;
        }
        .sc-talk-time span { font-weight: 500; color: rgba(255,255,255,0.4); }
        .sc-talk-main { flex: 1; min-width: 0; }
        .sc-talk-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 6px; }
        .sc-talk-type {
          display: inline-block; font-size: 10px; font-weight: 700; text-transform: uppercase;
          letter-spacing: 1px; padding: 2px 9px; border: 1px solid; border-radius: 3px; line-height: 1.5;
        }
        .sc-talk-title { font-size: 14px; color: rgba(255,255,255,0.92); line-height: 1.5; }
        .sc-strikethrough { text-decoration: line-through; color: rgba(255,255,255,0.45); }
        .sc-talk-speaker { margin-top: 4px; font-size: 12.5px; color: rgba(133,178,224,0.85); line-height: 1.5; }
        .sc-talk-files { display: flex; flex-wrap: wrap; gap: 7px; margin-top: 10px; }
        .sc-talk-file {
          display: inline-flex; align-items: center; gap: 6px; max-width: 100%; padding: 6px 9px;
          border-radius: 4px; border: 1px solid rgba(85,156,214,0.3);
          background: rgba(85,156,214,0.08); color: #8DBCE3; text-decoration: none;
          font-size: 11px; font-weight: 600; transition: all 0.2s;
        }
        .sc-talk-file span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .sc-talk-file:hover { color: #fff; border-color: rgba(85,156,214,0.6); background: rgba(85,156,214,0.16); }
        .sc-online {
          display: inline-block; font-size: 10px; font-weight: 600; text-transform: uppercase;
          letter-spacing: 0.5px; color: #6FCF97; border: 1px solid rgba(63,167,150,0.4);
          border-radius: 3px; padding: 2px 8px; line-height: 1.5;
        }
        .sc-removed-badge {
          display: inline-block; font-size: 10px; font-weight: 700; text-transform: uppercase;
          letter-spacing: 0.5px; color: #E08A8A; border: 1px solid rgba(224,138,138,0.4);
          border-radius: 3px; padding: 2px 8px; line-height: 1.5;
        }

        @media (max-width: 1024px) {
          .sc-hero { padding: 120px 32px 44px; }
          .sc-title { font-size: 34px; }
          .sc-body { padding: 28px 32px 70px; }
        }
        @media (max-width: 600px) {
          .sc-hero { padding: 100px 20px 36px; }
          .sc-title { font-size: 26px; }
          .sc-subtitle { font-size: 14px; }
          .sc-body { padding: 24px 16px 56px; }
          .sc-day { padding: 8px 18px; font-size: 14px; }
          .sc-talk { flex-wrap: wrap; gap: 4px; }
          .sc-talk-time { width: 100%; }
        }
      `})]})}])}];

//# sourceMappingURL=_07eb3t5._.js.map