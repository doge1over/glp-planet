module.exports=[36021,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_broadcast_page_actions_0p-2hk0.js.map