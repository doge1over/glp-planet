module.exports=[33354,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}},16133,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(38679),e=a.i(783);function f({children:a,delay:d=0,direction:e="up"}){let g=(0,c.useRef)(null),[h,i]=(0,c.useState)(!1);return(0,c.useEffect)(()=>{let a=g.current;if(!a)return;let b=new IntersectionObserver(([a])=>{a.isIntersecting&&i(!0)},{threshold:.08});return b.observe(a),()=>b.disconnect()},[]),(0,b.jsx)("div",{ref:g,style:{opacity:+!!h,transform:h?"none":({up:"translateY(32px)",left:"translateX(-32px)",right:"translateX(32px)",scale:"scale(0.97)"})[e],transition:`opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${d}ms, transform 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${d}ms`},children:a})}let g=[{label:"E-mail",value:"sci.secretary@glp-planet.com",href:null,copy:!0},{label:"Телефон",value:"+7 (981) 041-01-45",subtext:"Ковалева Мария",href:"tel:+79810410145"},{label:"Место проведения",value:"Отель «Санкт-Петербург»",subtext:"Пироговская набережная, д. 5/2, г. Санкт-Петербург",href:null}];a.s(["default",0,function(){let[a,h]=(0,c.useState)(!1),i=()=>{navigator.clipboard.writeText("sci.secretary@glp-planet.com"),h(!0),setTimeout(()=>h(!1),2e3)};return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(d.default,{}),(0,b.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,b.jsx)("section",{className:"contacts-hero",children:(0,b.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,b.jsx)(f,{children:(0,b.jsx)("div",{style:{fontSize:11,color:"#6B82C4",fontWeight:600,textTransform:"uppercase",letterSpacing:3,marginBottom:12},children:"Связь"})}),(0,b.jsx)(f,{delay:80,children:(0,b.jsx)("h1",{className:"contacts-title",children:"Контакты"})}),(0,b.jsx)(f,{delay:160,children:(0,b.jsx)("p",{style:{fontSize:16,color:"rgba(255,255,255,0.6)",lineHeight:1.8,maxWidth:500},children:"Свяжитесь с нами по любым вопросам, связанным с конференцией"})})]})}),(0,b.jsx)("section",{className:"contacts-content",children:(0,b.jsxs)("div",{className:"contacts-grid",style:{maxWidth:1200,margin:"0 auto"},children:[(0,b.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:16},children:g.map((c,d)=>(0,b.jsx)(f,{delay:80+120*d,direction:"left",children:(0,b.jsxs)("div",{className:"contact-card",style:{padding:"28px 32px",background:"var(--light)",borderRadius:4,border:"1px solid rgba(73,100,162,0.06)"},children:[(0,b.jsx)("div",{style:{fontSize:11,color:"var(--muted)",fontWeight:600,textTransform:"uppercase",letterSpacing:2,marginBottom:8},children:c.label}),c.copy?(0,b.jsxs)("button",{onClick:i,className:"contact-link contact-copy-btn",style:{fontSize:17,fontWeight:600,color:"var(--primary)",background:"none",border:"none",padding:0,cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",alignItems:"center",gap:8},children:[c.value,(0,b.jsx)("span",{className:"contact-copy-hint",style:a?{opacity:1}:void 0,children:a?"✓ Скопировано":"Копировать"})]}):c.href?(0,b.jsx)("a",{href:c.href,className:"contact-link",style:{fontSize:17,fontWeight:600,color:"var(--primary)",textDecoration:"none"},children:c.value}):(0,b.jsx)("div",{style:{fontSize:17,fontWeight:600,color:"var(--primary)",lineHeight:1.5},children:c.value}),c.subtext&&(0,b.jsx)("div",{style:{fontSize:13,color:"var(--muted)",marginTop:4,lineHeight:1.5},children:c.subtext})]})},d))}),(0,b.jsx)(f,{delay:200,direction:"right",children:(0,b.jsxs)("div",{style:{padding:32,background:"var(--primary)",borderRadius:4,height:"100%"},children:[(0,b.jsx)("h3",{style:{fontSize:20,fontWeight:700,color:"#fff",marginBottom:24},children:"VII Конференция GLP-PLANET"}),(0,b.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:18},children:[{label:"Даты",value:"1–3 июля 2026 г."},{label:"Город",value:"Санкт-Петербург"},{label:"Площадка",value:"Отель «Санкт-Петербург»"},{label:"Совместно с",value:"Rus-LASA"}].map((a,c)=>(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{style:{fontSize:11,color:"rgba(255,255,255,0.5)",letterSpacing:1.5,textTransform:"uppercase",marginBottom:4},children:a.label}),(0,b.jsx)("div",{style:{color:"rgba(255,255,255,0.9)",fontSize:15},children:a.value})]},c))}),(0,b.jsx)("div",{style:{marginTop:28},children:(0,b.jsx)("a",{href:"/registration",className:"contacts-btn",children:"Регистрация"})})]})})]})})]}),(0,b.jsx)(e.default,{}),(0,b.jsx)("style",{children:`
        .contacts-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .contacts-title {
          font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px;
        }
        .contacts-content { padding: 80px 48px; }

        .contacts-grid {
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 24px;
          align-items: start;
        }
        .contact-card {
          transition: all 0.5s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .contact-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 32px rgba(20,27,77,0.06);
          border-color: rgba(73,100,162,0.12);
        }
        .contact-link {
          transition: color 0.3s;
        }
        .contact-link:hover {
          color: var(--secondary) !important;
        }
        .contact-copy-btn:hover {
          color: var(--secondary) !important;
        }
        .contact-copy-hint {
          font-size: 11px;
          font-weight: 500;
          color: var(--secondary);
          opacity: 0;
          transition: opacity 0.3s;
        }
        .contact-copy-btn:hover .contact-copy-hint {
          opacity: 1;
        }
        .contacts-btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 13px 28px;
          background: rgba(255,255,255,0.08);
          border: 1.5px solid rgba(255,255,255,0.15);
          border-radius: 3px;
          color: #fff;
          font-family: 'Exo 2', sans-serif;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 1px;
          text-transform: uppercase;
          text-decoration: none;
          cursor: pointer;
          transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .contacts-btn:hover {
          background: rgba(255,255,255,0.15);
          border-color: rgba(255,255,255,0.3);
          transform: translateY(-2px);
        }
        @media (max-width: 1024px) {
          .contacts-hero { padding: 120px 32px 48px; }
          .contacts-title { font-size: 34px; }
          .contacts-content { padding: 60px 32px; }

        }
        @media (max-width: 900px) {
          .contacts-grid {
            grid-template-columns: 1fr;
          }
        }
        @media (max-width: 600px) {
          .contacts-hero { padding: 100px 20px 40px; }
          .contacts-title { font-size: 28px; }
          .contacts-content { padding: 40px 20px; }

        }
      `})]})}])}];

//# sourceMappingURL=_0zq8_x8._.js.map