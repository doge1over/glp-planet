module.exports=[25254,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2022_page_actions_0~7esgj.js.map