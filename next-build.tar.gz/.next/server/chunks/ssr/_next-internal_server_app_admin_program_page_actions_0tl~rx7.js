module.exports=[20389,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_program_page_actions_0tl~rx7.js.map