module.exports=[79555,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2023_page_actions_0774t1-.js.map