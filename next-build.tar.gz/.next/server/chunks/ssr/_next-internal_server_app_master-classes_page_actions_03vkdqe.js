module.exports=[10592,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_master-classes_page_actions_03vkdqe.js.map