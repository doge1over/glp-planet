module.exports=[49576,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_registrations_page_actions_08s_1df.js.map