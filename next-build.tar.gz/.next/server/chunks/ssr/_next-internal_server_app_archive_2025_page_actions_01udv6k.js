module.exports=[37957,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archive_2025_page_actions_01udv6k.js.map