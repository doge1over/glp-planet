module.exports=[92926,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_registrations_export_route_actions_07hd4a8.js.map