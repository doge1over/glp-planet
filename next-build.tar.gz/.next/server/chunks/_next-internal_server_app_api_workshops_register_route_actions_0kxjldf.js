module.exports=[55114,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workshops_register_route_actions_0kxjldf.js.map