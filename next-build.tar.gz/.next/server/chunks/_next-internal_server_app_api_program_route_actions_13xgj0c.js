module.exports=[71609,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_program_route_actions_13xgj0c.js.map