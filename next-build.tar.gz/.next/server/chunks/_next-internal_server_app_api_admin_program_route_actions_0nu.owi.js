module.exports=[65509,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_program_route_actions_0nu.owi.js.map