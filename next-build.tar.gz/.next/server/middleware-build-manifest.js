globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/j-s8gww9if42eMuTXpB6h/_buildManifest.js",
    "static/j-s8gww9if42eMuTXpB6h/_ssgManifest.js",
    "static/j-s8gww9if42eMuTXpB6h/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0zaia6i55l01..js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0a3pg.k92a8rq.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/turbopack-01dxszpo6myqm.js"
  ]
};
