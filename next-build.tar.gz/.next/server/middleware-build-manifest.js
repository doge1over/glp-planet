globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Due96VcOfCdFGsHzAgsbE/_buildManifest.js",
    "static/Due96VcOfCdFGsHzAgsbE/_ssgManifest.js",
    "static/Due96VcOfCdFGsHzAgsbE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/045g~0~zva_mv.js",
    "static/chunks/0dgq26a5_oy.a.js",
    "static/chunks/0vkgb7xyv-nko.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/turbopack-0zpnfhr1gt6zd.js"
  ]
};
