(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,72353,e=>{"use strict";var r=e.i(43476),t=e.i(71645),i=e.i(70119),n=e.i(56691),a=e.i(21101);function s({children:e,delay:i=0,direction:n="up"}){let a=(0,t.useRef)(null),[c,d]=(0,t.useState)(!1);return(0,t.useEffect)(()=>{let e=a.current;if(!e)return;let r=new IntersectionObserver(([e])=>{e.isIntersecting&&d(!0)},{threshold:.08});return r.observe(e),()=>r.disconnect()},[]),(0,r.jsx)("div",{ref:a,style:{opacity:+!!c,transform:c?"none":({up:"translateY(32px)",left:"translateX(-32px)",right:"translateX(32px)",scale:"scale(0.97)"})[n],transition:`opacity 0.8s cubic-bezier(0.16,1,0.3,1) ${i}ms, transform 0.8s cubic-bezier(0.16,1,0.3,1) ${i}ms`},children:e})}e.s(["default",0,function(){return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(i.default,{}),(0,r.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,r.jsx)("section",{className:"reg-hero",children:(0,r.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,r.jsx)(s,{children:(0,r.jsx)("div",{style:{fontSize:11,color:"#6B82C4",fontWeight:600,textTransform:"uppercase",letterSpacing:3,marginBottom:12},children:"Участие"})}),(0,r.jsx)(s,{delay:80,children:(0,r.jsx)("h1",{className:"reg-title",children:"Регистрация"})}),(0,r.jsx)(s,{delay:160,children:(0,r.jsxs)("p",{style:{fontSize:16,color:"rgba(255,255,255,0.6)",lineHeight:1.8,maxWidth:560},children:["Выберите удобный формат участия в VII конференции GLP-PLANET,",(0,r.jsx)("br",{}),"1–3 июля 2026 г., Санкт-Петербург"]})})]})}),(0,r.jsx)("section",{className:"reg-content",children:(0,r.jsx)("div",{style:{maxWidth:1200,margin:"0 auto"},children:(0,r.jsxs)("div",{className:"reg-cards",children:[(0,r.jsx)(s,{delay:100,children:(0,r.jsxs)("div",{className:"reg-card",children:[(0,r.jsx)("div",{className:"reg-card-badge",children:"Рекомендуем"}),(0,r.jsx)("div",{className:"reg-card-icon",children:(0,r.jsxs)("svg",{width:"28",height:"28",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,r.jsx)("path",{d:"M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"}),(0,r.jsx)("circle",{cx:"9",cy:"7",r:"4"}),(0,r.jsx)("path",{d:"M23 21v-2a4 4 0 00-3-3.87"}),(0,r.jsx)("path",{d:"M16 3.13a4 4 0 010 7.75"})]})}),(0,r.jsx)("h3",{className:"reg-card-title",children:"Очное участие"}),(0,r.jsx)("p",{className:"reg-card-desc",children:"Личное присутствие на конференции в отеле «Санкт-Петербург». Участие во всех сессиях, мастер-классах, круглых столах и нетворкинге."}),(0,r.jsx)("div",{style:{marginTop:"auto",paddingTop:24},children:(0,r.jsxs)("a",{href:"https://doclinika.timepad.ru/event/3689916",target:"_blank",rel:"noopener noreferrer",className:"btn-primary",style:{textDecoration:"none",width:"100%",justifyContent:"center"},children:[(0,r.jsx)("span",{children:"Зарегистрироваться"}),(0,r.jsx)(a.IconArrow,{})]})})]})}),(0,r.jsx)(s,{delay:200,children:(0,r.jsxs)("div",{className:"reg-card",children:[(0,r.jsx)("div",{className:"reg-card-icon",children:(0,r.jsxs)("svg",{width:"28",height:"28",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,r.jsx)("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"}),(0,r.jsx)("line",{x1:"8",y1:"21",x2:"16",y2:"21"}),(0,r.jsx)("line",{x1:"12",y1:"17",x2:"12",y2:"21"})]})}),(0,r.jsx)("h3",{className:"reg-card-title",children:"Онлайн участие"}),(0,r.jsx)("p",{className:"reg-card-desc",children:"Подключение к трансляции конференции в режиме реального времени. Доступ ко всем пленарным сессиям и возможность задавать вопросы."}),(0,r.jsx)("div",{style:{marginTop:"auto",paddingTop:24},children:(0,r.jsxs)("a",{href:"https://doclinika.timepad.ru/event/3690058",target:"_blank",rel:"noopener noreferrer",className:"btn-primary",style:{textDecoration:"none",width:"100%",justifyContent:"center"},children:[(0,r.jsx)("span",{children:"Зарегистрироваться"}),(0,r.jsx)(a.IconArrow,{})]})})]})}),(0,r.jsx)(s,{delay:300,children:(0,r.jsxs)("div",{className:"reg-card reg-card-accent",children:[(0,r.jsx)("div",{className:"reg-card-icon",children:(0,r.jsxs)("svg",{width:"28",height:"28",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,r.jsx)("path",{d:"M2 3h20v14H2z"}),(0,r.jsx)("path",{d:"M8 21h8"}),(0,r.jsx)("path",{d:"M12 17v4"}),(0,r.jsx)("path",{d:"M7 12l3-3 2 2 4-4"})]})}),(0,r.jsx)("h3",{className:"reg-card-title",children:"Мастер-классы"}),(0,r.jsx)("p",{className:"reg-card-desc",children:"Практические мастер-классы конференции с ограниченным числом мест. Запись открыта для зарегистрированных участников по коду доступа."}),(0,r.jsxs)("div",{className:"reg-card-notice",children:[(0,r.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,r.jsx)("circle",{cx:"12",cy:"12",r:"10"}),(0,r.jsx)("polyline",{points:"12 6 12 12 16 14"})]}),(0,r.jsx)("span",{children:"Подача заявок — до 23.06.2026 включительно"})]}),(0,r.jsx)("div",{style:{marginTop:"auto",paddingTop:24},children:(0,r.jsxs)("a",{href:"/master-classes",className:"btn-primary",style:{textDecoration:"none",width:"100%",justifyContent:"center",background:"#559CD6"},children:[(0,r.jsx)("span",{children:"Записаться"}),(0,r.jsx)(a.IconArrow,{})]})})]})})]})})})]}),(0,r.jsx)(n.default,{}),(0,r.jsx)("style",{children:`
        .reg-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .reg-title { font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px; }
        .reg-content { padding: 80px 48px 80px; }
        .reg-cards {
          display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 48px;
          align-items: stretch;
        }
        .reg-cards > div { height: 100%; }
        .reg-card {
          padding: 36px 32px 32px; background: var(--light); border-radius: 6px;
          border: 1px solid rgba(73,100,162,0.06);
          display: flex; flex-direction: column; position: relative;
          transition: all 0.5s cubic-bezier(0.33,1,0.68,1);
          height: 100%;
        }
        .reg-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 16px 40px rgba(20,27,77,0.08);
          border-color: rgba(73,100,162,0.12);
        }
        .reg-card-accent {
          background: var(--primary); border-color: rgba(107,130,196,0.2);
        }
        .reg-card-accent .reg-card-title { color: #fff; }
        .reg-card-accent .reg-card-desc { color: rgba(255,255,255,0.65); }
        .reg-card-accent .reg-card-icon { color: #6B82C4; }
        .reg-card-accent:hover {
          box-shadow: 0 16px 40px rgba(20,27,77,0.25);
        }
        .reg-card-badge {
          position: absolute; top: -1px; right: 24px;
          padding: 5px 14px; background: var(--secondary);
          color: #fff; font-size: 10px; font-weight: 600;
          letter-spacing: 1px; text-transform: uppercase;
          border-radius: 0 0 4px 4px;
        }
        .reg-card-icon {
          width: 52px; height: 52px; border-radius: 6px;
          background: rgba(73,100,162,0.08);
          display: flex; align-items: center; justify-content: center;
          color: var(--secondary); margin-bottom: 24px;
        }
        .reg-card-accent .reg-card-icon {
          background: rgba(107,130,196,0.15);
        }
        .reg-card-title {
          font-size: 20px; font-weight: 700; color: var(--primary);
          margin-bottom: 12px;
        }
        .reg-card-desc {
          font-size: 14px; color: #444; line-height: 1.7;
        }

        .reg-card-notice {
          margin-top: 18px;
          display: flex;
          align-items: flex-start;
          gap: 10px;
          padding: 12px 14px;
          background: rgba(107,130,196,0.18);
          border-left: 3px solid #6B82C4;
          border-radius: 4px;
          color: #fff;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.5;
        }
        .reg-card-notice svg {
          flex-shrink: 0;
          margin-top: 2px;
          color: #6B82C4;
        }


        @media (max-width: 1024px) {
          .reg-hero { padding: 120px 32px 48px; }
          .reg-title { font-size: 34px; }
          .reg-content { padding: 60px 32px 60px; }
        }
        @media (max-width: 900px) {
          .reg-cards { grid-template-columns: 1fr; max-width: 480px; margin-left: auto; margin-right: auto; }
        }
        @media (max-width: 600px) {
          .reg-hero { padding: 100px 20px 40px; }
          .reg-title { font-size: 28px; }
          .reg-content { padding: 40px 20px 48px; }
          .reg-card { padding: 28px 24px 24px; }
          .reg-card-notice { font-size: 12px; padding: 10px 12px; }
        }
      `})]})}])}]);