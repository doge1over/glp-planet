(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,91035,e=>{"use strict";let i=[{id:"cardiodetective",title:"Кардиодетектив: интервалы принятия решений",sessions:[{date:"01.07.2026",time:"15:00–17:30"}],seats:25},{id:"glp-risk-monitoring",title:"GLP. Риск-ориентированный подход к мониторингу здоровья лабораторных животных",sessions:[{date:"02.07.2026",time:"09:00–11:00"}],seats:25},{id:"laqis",title:"Комплексная оценка качества лабораторных животных: LAQIS",sessions:[{date:"02.07.2026",time:"12:00–14:00"}],seats:25},{id:"digitalization",title:"Цифровизация против фальсификации и профанации",sessions:[{date:"01.07.2026",time:"11:30–12:00"},{date:"02.07.2026",time:"11:30–12:00"}],seats:50},{id:"severity-assessment",title:"Оценка степени тяжести экспериментальных процедур в исследованиях на грызунах",sessions:[{date:"03.07.2026",time:"09:00–14:00"}],seats:10,description:"Мастер-класс предназначен в первую очередь для ветеринарных врачей, сотрудников Комиссии по биоэтике, руководителей исследования и исследователей. Обратите внимание, что повторное участие в данном мастер-классе не желательно.",extended:!0},{id:"video-tracking",title:"Демонстрация возможностей интеллектуальной системы видеотрекинга лабораторных животных",sessions:[{date:"01.07.2026",time:"11:30–13:30"}],seats:0,noRegistration:!0},{id:"mouse-nomenclature",title:"Правила использования номенклатуры в наименовании линий лабораторных мышей",sessions:[{date:"02.07.2026",time:"16:00–18:00"}],seats:0,noRegistration:!0},{id:"ethics-round-table",title:"Этико-правовые аспекты обращения с экспериментальными животными",sessions:[{date:"03.07.2026",time:"15:00–17:30"}],seats:0,unlimited:!0,kind:"Круглый стол"},{id:"vinno6-jul2",title:"Применение ультразвукового сканера VINNO 6 LAB в доклинических исследованиях",sessions:[{date:"02.07.2026",time:"15:00–17:00"}],seats:8,description:"Место проведения: НМИЦ им. В.А. Алмазова, пр. Пархоменко, 15. Предусмотрен трансфер участников от «Отель Санкт-Петербург» и обратно.",bioline:!0},{id:"vinno6-jul3",title:"Применение ультразвукового сканера VINNO 6 LAB в доклинических исследованиях",sessions:[{date:"03.07.2026",time:"15:00–17:00"}],seats:8,description:"Место проведения: НМИЦ им. В.А. Алмазова, пр. Пархоменко, 15. Предусмотрен трансфер участников от «Отель Санкт-Петербург» и обратно.",bioline:!0}];e.s(["ACCESS_CODE",0,"GLPPLANET2026","ACCESS_STORAGE_KEY",0,"mc_access_v1","FIELD_LABELS",0,{fullName:"Фамилия Имя Отчество",position:"Должность",organization:"Место работы",email:"Электронная почта",phone:"Телефон для связи",city:"Город",academicDegree:"Учёная степень",prevParticipation:"Принимали ли ранее участие в данном мастер-классе?",ruslasaMember:"Член Rus-LASA?",motivation:"Как информация о классификации тяжести процедур может помочь в работе и как её применить?"},"REGISTRATION_DEADLINE_LABEL",0,"23.06.2026","WORKSHOPS",0,i,"getWorkshop",0,function(e){return i.find(i=>i.id===e)},"sessionsLabel",0,function(e){return e.sessions.map(e=>`${e.date} ${e.time}`).join(", ")},"workshopKind",0,function(e){return e.kind??"Мастер-класс"}])},18566,(e,i,s)=>{i.exports=e.r(76562)},41901,e=>{"use strict";var i=e.i(43476),s=e.i(71645),a=e.i(22016),t=e.i(18566),n=e.i(70119),r=e.i(56691),o=e.i(91035);let l={fullName:"",position:"",organization:"",email:"",phone:"",city:"",academicDegree:"",biolineConsent:!1,prevParticipation:"",ruslasaMember:"",motivation:""};e.s(["default",0,function(){let e=(0,t.useParams)(),d=(0,t.useRouter)(),c=String(e?.id??""),p=(0,o.getWorkshop)(c),[f,x]=(0,s.useState)(!1),[m,h]=(0,s.useState)(!1),[u,g]=(0,s.useState)(l),[b,w]=(0,s.useState)(!1),[j,v]=(0,s.useState)(null),[N,k]=(0,s.useState)(!1);(0,s.useEffect)(()=>{x(!0);try{h("ok"===sessionStorage.getItem(o.ACCESS_STORAGE_KEY))}catch{}},[]);let y=(e,i)=>g(s=>({...s,[e]:i})),C=async e=>{if(e.preventDefault(),p){if(v(null),!u.fullName.trim()||!u.position.trim()||!u.organization.trim()||!u.email.trim()||!u.phone.trim())return void v("Заполните, пожалуйста, все обязательные поля.");if(p.bioline&&!u.biolineConsent)return void v("Для записи необходимо дать согласие на обработку персональных данных.");if(p.extended&&(!u.prevParticipation||!u.ruslasaMember||!u.motivation.trim()))return void v("Ответьте, пожалуйста, на все вопросы анкеты.");w(!0);try{let e=await fetch("/api/workshops/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({workshopId:p.id,...u,biolineConsent:void 0})}),i=await e.json();e.ok&&i.ok?k(!0):v(i.message||"Не удалось отправить заявку. Попробуйте позже.")}catch{v("Ошибка соединения. Проверьте интернет и попробуйте ещё раз.")}finally{w(!1)}}};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(n.default,{}),(0,i.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,i.jsx)("section",{className:"wf-hero",children:(0,i.jsxs)("div",{style:{maxWidth:860,margin:"0 auto"},children:[(0,i.jsx)(a.default,{href:"/master-classes",className:"wf-back",children:"← Все мастер-классы"}),(0,i.jsx)("div",{className:"wf-eyebrow",children:p?`Запись \xb7 ${(0,o.workshopKind)(p)}`:"Запись"}),(0,i.jsx)("h1",{className:"wf-title",children:p?p.title:"Мероприятие не найдено"}),p&&(0,i.jsxs)("div",{className:"wf-schedule",children:[(0,o.sessionsLabel)(p),p.unlimited||p.noRegistration?"":` \xb7 число мест: ${p.seats}`]})]})}),(0,i.jsx)("section",{className:"wf-content",children:(0,i.jsx)("div",{style:{maxWidth:860,margin:"0 auto"},children:f?p?p.noRegistration?(0,i.jsxs)("div",{className:"wf-note",children:["На этот мастер-класс запись не требуется — приходите в указанное в расписании время."," ",(0,i.jsx)(a.default,{href:"/master-classes",children:"Вернуться к списку"}),"."]}):m?N?(0,i.jsxs)("div",{className:"wf-success",children:[(0,i.jsx)("div",{className:"wf-success-icon",children:(0,i.jsx)("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:(0,i.jsx)("path",{d:"M20 6L9 17l-5-5"})})}),(0,i.jsx)("h2",{className:"wf-success-title",children:"Заявка принята!"}),(0,i.jsxs)("p",{className:"wf-success-text",children:["Вы записаны: «",p.title,"». Мы свяжемся с вами по указанным контактам."]}),(0,i.jsx)(a.default,{href:"/master-classes",className:"wf-success-btn",children:"К списку мастер-классов"})]}):(0,i.jsxs)("form",{className:"wf-form",onSubmit:C,children:[p.description&&(0,i.jsx)("div",{className:"wf-desc",children:p.description}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Фамилия Имя Отчество ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("input",{className:"wf-input",value:u.fullName,onChange:e=>y("fullName",e.target.value),placeholder:"Иванов Иван Иванович",autoComplete:"name"})]}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Должность ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("input",{className:"wf-input",value:u.position,onChange:e=>y("position",e.target.value),placeholder:"Должность"})]}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Организация ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("input",{className:"wf-input",value:u.organization,onChange:e=>y("organization",e.target.value),placeholder:"Название организации",autoComplete:"organization"})]}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Укажите, пожалуйста, вашу электронную почту ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("input",{className:"wf-input",type:"email",value:u.email,onChange:e=>y("email",e.target.value),placeholder:"name@example.com",autoComplete:"email"})]}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Ваш номер телефона для связи ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("input",{className:"wf-input",type:"tel",value:u.phone,onChange:e=>y("phone",e.target.value),placeholder:"+7 (___) ___-__-__",autoComplete:"tel"})]}),p.bioline&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsx)("span",{className:"wf-label",children:o.FIELD_LABELS.city}),(0,i.jsx)("input",{className:"wf-input",value:u.city,onChange:e=>y("city",e.target.value),placeholder:"Город"})]}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsx)("span",{className:"wf-label",children:o.FIELD_LABELS.academicDegree}),(0,i.jsx)("input",{className:"wf-input",value:u.academicDegree,onChange:e=>y("academicDegree",e.target.value),placeholder:"Например: к.б.н., д.м.н."})]}),(0,i.jsxs)("label",{className:"wf-consent",children:[(0,i.jsx)("input",{type:"checkbox",checked:u.biolineConsent,onChange:e=>y("biolineConsent",e.target.checked),className:"wf-consent-check"}),(0,i.jsxs)("span",{className:"wf-consent-text",children:["Я даю своё согласие на осуществление ООО «БиоЛайн» обработки персональных данных (ФИО, адрес электронной почты, номер телефона, место работы и должность, город проживания, учёная степень), включая сбор, запись, систематизацию, накопление, хранение, извлечение, использование, уничтожение персональных данных. Настоящее согласие дано мной добровольно в целях регистрации на мероприятие."," ",(0,i.jsx)("a",{href:"https://bioline.ru/information-received",target:"_blank",rel:"noopener noreferrer",className:"wf-consent-link",children:"Политика конфиденциальности ООО «БиоЛайн»"}),". ",(0,i.jsx)("i",{children:"*"})]})]})]}),p.extended&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("div",{className:"wf-divider"}),(0,i.jsxs)("div",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Принимали ли Вы ранее участие в данном мастер-классе? ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("div",{className:"wf-radios",children:["Да","Нет"].map(e=>(0,i.jsxs)("label",{className:`wf-radio${u.prevParticipation===e?" active":""}`,children:[(0,i.jsx)("input",{type:"radio",name:"prev",value:e,checked:u.prevParticipation===e,onChange:()=>y("prevParticipation",e)}),e]},e))})]}),(0,i.jsxs)("div",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Являетесь ли Вы членом Rus-LASA? ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("div",{className:"wf-radios",children:["Да","Нет"].map(e=>(0,i.jsxs)("label",{className:`wf-radio${u.ruslasaMember===e?" active":""}`,children:[(0,i.jsx)("input",{type:"radio",name:"ruslasa",value:e,checked:u.ruslasaMember===e,onChange:()=>y("ruslasaMember",e)}),e]},e))})]}),(0,i.jsxs)("label",{className:"wf-field",children:[(0,i.jsxs)("span",{className:"wf-label",children:["Кратко укажите, как информация о классификации тяжести процедур экспериментов на животных может помочь вам в вашей повседневной работе. Как вы могли бы её применить? ",(0,i.jsx)("i",{children:"*"})]}),(0,i.jsx)("textarea",{className:"wf-input wf-textarea",rows:5,value:u.motivation,onChange:e=>y("motivation",e.target.value),placeholder:"Ваш ответ"})]})]}),j&&(0,i.jsx)("div",{className:"wf-error",children:j}),(0,i.jsxs)("div",{className:"wf-foot",children:[(0,i.jsxs)("span",{className:"wf-foot-note",children:["Срок подачи заявки — до ",o.REGISTRATION_DEADLINE_LABEL," включительно"]}),(0,i.jsx)("button",{type:"submit",className:"wf-submit",disabled:b,children:b?"Отправка…":"Отправить заявку"})]})]}):(0,i.jsxs)("div",{className:"wf-note",children:["Доступ к записи открывается по коду."," ",(0,i.jsx)("button",{className:"wf-link-btn",onClick:()=>d.push("/master-classes"),children:"Ввести код доступа"})]}):(0,i.jsxs)("div",{className:"wf-note",children:["Такого мероприятия нет. ",(0,i.jsx)(a.default,{href:"/master-classes",children:"Вернуться к списку"}),"."]}):null})})]}),(0,i.jsx)(r.default,{}),(0,i.jsx)("style",{children:`
        .wf-hero {
          padding: 130px 48px 50px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .wf-back { display: inline-block; margin-bottom: 22px; color: rgba(255,255,255,0.6); font-size: 13px; text-decoration: none; transition: color 0.2s; }
        .wf-back:hover { color: #fff; }
        .wf-eyebrow { font-size: 11px; color: #6B82C4; font-weight: 600; text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px; }
        .wf-title { font-size: 30px; font-weight: 700; color: #fff; line-height: 1.3; margin-bottom: 14px; }
        .wf-schedule {
          display: inline-block; padding: 7px 14px; border-radius: 5px;
          background: rgba(107,130,196,0.15); color: #aebbe0;
          font-size: 14px; font-weight: 600;
        }
        .wf-content { padding: 50px 48px 90px; background: var(--white); }

        .wf-note {
          max-width: 560px; margin: 0 auto; text-align: center; padding: 40px 30px;
          background: var(--light); border-radius: 10px; color: #444; font-size: 15px; line-height: 1.7;
        }
        .wf-note a, .wf-link-btn { color: var(--secondary); font-weight: 600; }
        .wf-link-btn { background: none; border: none; cursor: pointer; font-size: 15px; font-family: inherit; text-decoration: underline; padding: 0; }

        .wf-form {
          background: var(--light); border-radius: 12px; padding: 36px 36px 32px;
          border: 1px solid rgba(73,100,162,0.08); display: flex; flex-direction: column; gap: 20px;
        }
        .wf-desc {
          padding: 14px 16px; background: rgba(85,156,214,0.1);
          border-left: 3px solid #559CD6; border-radius: 6px;
          font-size: 13px; color: #3a4258; line-height: 1.6;
        }
        .wf-field { display: flex; flex-direction: column; gap: 8px; }
        .wf-label { font-size: 13px; font-weight: 600; color: var(--primary); line-height: 1.5; }
        .wf-label i { color: #d65555; font-style: normal; }
        .wf-input {
          padding: 12px 14px; border-radius: 6px; font-size: 15px; font-family: 'Exo 2', sans-serif;
          border: 1px solid rgba(73,100,162,0.2); background: #fff; color: var(--primary);
          outline: none; transition: border-color 0.2s;
        }
        .wf-input:focus { border-color: #559CD6; }
        .wf-textarea { resize: vertical; line-height: 1.6; }
        .wf-divider { height: 1px; background: rgba(73,100,162,0.14); margin: 4px 0; }
        .wf-consent { display: flex; gap: 12px; align-items: flex-start; padding: 16px; background: rgba(85,156,214,0.07); border: 1px solid rgba(85,156,214,0.2); border-radius: 6px; cursor: pointer; }
        .wf-consent-check { margin-top: 3px; flex-shrink: 0; width: 17px; height: 17px; accent-color: #559CD6; cursor: pointer; }
        .wf-consent-text { font-size: 13px; color: #3a4258; line-height: 1.6; }
        .wf-consent-text i { color: #d65555; font-style: normal; }
        .wf-consent-link { color: #559CD6; text-decoration: underline; }
        .wf-radios { display: flex; gap: 10px; }
        .wf-radio {
          display: inline-flex; align-items: center; gap: 8px; cursor: pointer;
          padding: 10px 20px; border-radius: 6px; background: #fff;
          border: 1px solid rgba(73,100,162,0.2); font-size: 14px; color: var(--primary); transition: all 0.2s;
        }
        .wf-radio.active { border-color: #559CD6; background: rgba(85,156,214,0.1); font-weight: 600; }
        .wf-radio input { accent-color: #559CD6; }

        .wf-error {
          padding: 12px 16px; background: rgba(214,85,85,0.1); border: 1px solid rgba(214,85,85,0.3);
          border-left: 3px solid #d65555; border-radius: 6px; color: #b23b3b; font-size: 14px; font-weight: 600;
        }
        .wf-foot { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; margin-top: 4px; }
        .wf-foot-note { font-size: 12px; color: #6b7488; }
        .wf-submit {
          padding: 14px 34px; border-radius: 6px; border: none; cursor: pointer;
          background: #559CD6; color: #fff; font-size: 15px; font-weight: 600; font-family: 'Exo 2', sans-serif;
          transition: background 0.2s, transform 0.2s;
        }
        .wf-submit:hover:not(:disabled) { background: #4A8BC2; transform: translateY(-2px); }
        .wf-submit:disabled { opacity: 0.6; cursor: default; }

        .wf-success {
          max-width: 560px; margin: 0 auto; text-align: center; padding: 50px 36px;
          background: var(--light); border-radius: 12px; border: 1px solid rgba(73,100,162,0.08);
        }
        .wf-success-icon {
          width: 64px; height: 64px; border-radius: 50%; margin: 0 auto 22px;
          background: rgba(67,160,107,0.14); color: #43a06b;
          display: flex; align-items: center; justify-content: center;
        }
        .wf-success-title { font-size: 24px; font-weight: 700; color: var(--primary); margin-bottom: 12px; }
        .wf-success-text { font-size: 15px; color: #444; line-height: 1.7; margin-bottom: 26px; }
        .wf-success-btn {
          display: inline-block; padding: 13px 28px; border-radius: 6px;
          background: var(--secondary); color: #fff; font-size: 14px; font-weight: 600;
          text-decoration: none; transition: all 0.3s;
        }
        .wf-success-btn:hover { background: var(--primary); transform: translateY(-2px); }

        @media (max-width: 1024px) {
          .wf-hero { padding: 116px 32px 44px; }
          .wf-title { font-size: 26px; }
          .wf-content { padding: 40px 32px 70px; }
        }
        @media (max-width: 600px) {
          .wf-hero { padding: 100px 18px 38px; }
          .wf-title { font-size: 22px; }
          .wf-content { padding: 30px 16px 56px; }
          .wf-form { padding: 26px 20px 24px; }
          .wf-foot { flex-direction: column; align-items: stretch; }
          .wf-submit { width: 100%; }
        }
      `})]})}])}]);