(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,91035,e=>{"use strict";let s=[{id:"cardiodetective",title:"Кардиодетектив: интервалы принятия решений",sessions:[{date:"01.07.2026",time:"15:00–17:30"}],seats:25},{id:"glp-risk-monitoring",title:"GLP. Риск-ориентированный подход к мониторингу здоровья лабораторных животных",sessions:[{date:"02.07.2026",time:"09:00–11:00"}],seats:25},{id:"laqis",title:"Комплексная оценка качества лабораторных животных: LAQIS",sessions:[{date:"02.07.2026",time:"12:00–14:00"}],seats:25},{id:"digitalization",title:"Цифровизация против фальсификации и профанации",sessions:[{date:"01.07.2026",time:"11:30–12:00"},{date:"02.07.2026",time:"11:30–12:00"}],seats:50},{id:"severity-assessment",title:"Оценка степени тяжести экспериментальных процедур в исследованиях на грызунах",sessions:[{date:"03.07.2026",time:"09:00–14:00"}],seats:10,description:"Мастер-класс предназначен в первую очередь для ветеринарных врачей, сотрудников Комиссии по биоэтике, руководителей исследования и исследователей. Обратите внимание, что повторное участие в данном мастер-классе не желательно.",extended:!0},{id:"video-tracking",title:"Демонстрация возможностей интеллектуальной системы видеотрекинга лабораторных животных",sessions:[{date:"01.07.2026",time:"11:30–13:30"}],seats:0,noRegistration:!0},{id:"mouse-nomenclature",title:"Правила использования номенклатуры в наименовании линий лабораторных мышей",sessions:[{date:"02.07.2026",time:"16:00–18:00"}],seats:0,noRegistration:!0},{id:"ethics-round-table",title:"Этико-правовые аспекты обращения с экспериментальными животными",sessions:[{date:"03.07.2026",time:"15:00–17:30"}],seats:0,unlimited:!0,kind:"Круглый стол"},{id:"vinno6-jul2",title:"Применение ультразвукового сканера VINNO 6 LAB в доклинических исследованиях",sessions:[{date:"02.07.2026",time:"15:00–17:00"}],seats:8,description:"Место проведения: НМИЦ им. В.А. Алмазова, пр. Пархоменко, 15. Предусмотрен трансфер участников от «Отель Санкт-Петербург» и обратно.",bioline:!0},{id:"vinno6-jul3",title:"Применение ультразвукового сканера VINNO 6 LAB в доклинических исследованиях",sessions:[{date:"03.07.2026",time:"15:00–17:00"}],seats:8,description:"Место проведения: НМИЦ им. В.А. Алмазова, пр. Пархоменко, 15. Предусмотрен трансфер участников от «Отель Санкт-Петербург» и обратно.",bioline:!0}];e.s(["ACCESS_CODE",0,"GLPPLANET2026","ACCESS_STORAGE_KEY",0,"mc_access_v1","FIELD_LABELS",0,{fullName:"Фамилия Имя Отчество",position:"Должность",organization:"Место работы",email:"Электронная почта",phone:"Телефон для связи",city:"Город",academicDegree:"Учёная степень",prevParticipation:"Принимали ли ранее участие в данном мастер-классе?",ruslasaMember:"Член Rus-LASA?",motivation:"Как информация о классификации тяжести процедур может помочь в работе и как её применить?"},"REGISTRATION_DEADLINE_LABEL",0,"23.06.2026","WORKSHOPS",0,s,"getWorkshop",0,function(e){return s.find(s=>s.id===e)},"sessionsLabel",0,function(e){return e.sessions.map(e=>`${e.date} ${e.time}`).join(", ")},"workshopKind",0,function(e){return e.kind??"Мастер-класс"}])},48675,e=>{"use strict";var s=e.i(43476),t=e.i(71645),i=e.i(22016),a=e.i(70119),r=e.i(56691),n=e.i(21101),o=e.i(91035);e.s(["default",0,function(){let[e,c]=(0,t.useState)(!1),[d,l]=(0,t.useState)(!1),[p,m]=(0,t.useState)(""),[x,g]=(0,t.useState)(!1),[h,f]=(0,t.useState)(null),[u,b]=(0,t.useState)({});return(0,t.useEffect)(()=>{c(!0);try{"ok"===sessionStorage.getItem(o.ACCESS_STORAGE_KEY)&&l(!0)}catch{}},[]),(0,t.useEffect)(()=>{d&&fetch("/api/workshops/seats").then(e=>e.json()).then(e=>{f(e.remaining??{}),b(e.total??{})}).catch(()=>f({}))},[d]),(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(a.default,{}),(0,s.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,s.jsx)("section",{className:"mc-hero",children:(0,s.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,s.jsx)("div",{className:"mc-eyebrow",children:"Участие"}),(0,s.jsx)("h1",{className:"mc-title",children:"Запись на мастер-классы"}),(0,s.jsxs)("p",{className:"mc-lead",children:["Практические мастер-классы VII конференции GLP-PLANET,",(0,s.jsx)("br",{}),"1–3 июля 2026 г., Санкт-Петербург. Число мест ограничено."]})]})}),(0,s.jsx)("section",{className:"mc-content",children:(0,s.jsx)("div",{style:{maxWidth:1200,margin:"0 auto"},children:e?d?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)("div",{className:"mc-deadline",children:[(0,s.jsxs)("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,s.jsx)("circle",{cx:"12",cy:"12",r:"10"}),(0,s.jsx)("polyline",{points:"12 6 12 12 16 14"})]}),(0,s.jsxs)("span",{children:["Срок подачи заявки на участие — до ",o.REGISTRATION_DEADLINE_LABEL," включительно"]})]}),(0,s.jsx)("div",{className:"mc-grid",children:o.WORKSHOPS.map(e=>{let t=null!==h,a=t?h[e.id]:null,r=u[e.id]??e.seats,c=!e.unlimited&&!e.noRegistration&&t&&(a??r)<=0;return(0,s.jsxs)("div",{className:`mc-card${c?" mc-card-full":""}`,children:[(0,s.jsxs)("div",{className:"mc-card-top",children:[(0,s.jsx)("span",{className:"mc-kind",children:(0,o.workshopKind)(e)}),e.sessions.map((e,t)=>(0,s.jsxs)("div",{className:"mc-session",children:[(0,s.jsx)("span",{className:"mc-session-date",children:e.date}),(0,s.jsx)("span",{className:"mc-session-time",children:e.time})]},t))]}),(0,s.jsx)("h3",{className:"mc-card-title",children:e.title}),e.description&&(0,s.jsx)("p",{className:"mc-card-desc",children:e.description}),(0,s.jsx)("div",{className:"mc-card-foot",children:e.noRegistration?(0,s.jsx)("span",{className:"mc-noreg",children:"Запись не требуется"}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("div",{className:"mc-seats",children:t?e.unlimited?(0,s.jsx)("span",{className:"mc-seats-cap",children:"Без ограничений по местам"}):c?(0,s.jsx)("span",{className:"mc-seats-full",children:"Мест нет"}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("span",{className:"mc-seats-num",children:a}),(0,s.jsxs)("span",{className:"mc-seats-cap",children:["из ",r," мест"]})]}):(0,s.jsx)("span",{className:"mc-seats-load",children:"Загрузка мест…"})}),c?(0,s.jsx)("span",{className:"mc-btn mc-btn-disabled",children:"Запись закрыта"}):(0,s.jsxs)(i.default,{href:`/master-classes/${e.id}`,className:"mc-btn",children:[(0,s.jsx)("span",{children:"Записаться"}),(0,s.jsx)(n.IconArrow,{})]})]})})]},e.id)})})]}):(0,s.jsxs)("div",{className:"mc-gate",children:[(0,s.jsx)("div",{className:"mc-gate-icon",children:(0,s.jsxs)("svg",{width:"26",height:"26",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,s.jsx)("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2"}),(0,s.jsx)("path",{d:"M7 11V7a5 5 0 0110 0v4"})]})}),(0,s.jsx)("h2",{className:"mc-gate-title",children:"Доступ по коду"}),(0,s.jsx)("p",{className:"mc-gate-sub",children:"Запись на мастер-классы доступна по коду, который указан в письме участника конференции."}),(0,s.jsxs)("form",{className:"mc-gate-form",onSubmit:e=>{if(e.preventDefault(),p.trim().toUpperCase()===o.ACCESS_CODE){try{sessionStorage.setItem(o.ACCESS_STORAGE_KEY,"ok")}catch{}l(!0),g(!1)}else g(!0),setTimeout(()=>g(!1),1200)},children:[(0,s.jsx)("input",{className:`mc-gate-input${x?" mc-gate-input-error":""}`,placeholder:"Код доступа",value:p,onChange:e=>m(e.target.value),autoFocus:!0}),(0,s.jsx)("button",{type:"submit",className:"mc-gate-btn",children:"Войти"})]}),x&&(0,s.jsx)("div",{className:"mc-gate-err",children:"Неверный код доступа"})]}):null})})]}),(0,s.jsx)(r.default,{}),(0,s.jsx)("style",{children:`
        .mc-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .mc-eyebrow { font-size: 11px; color: #6B82C4; font-weight: 600; text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px; }
        .mc-title { font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px; }
        .mc-lead { font-size: 16px; color: rgba(255,255,255,0.6); line-height: 1.8; max-width: 600px; }
        .mc-content { padding: 64px 48px 90px; background: var(--white); }

        /* Гейт */
        .mc-gate {
          max-width: 460px; margin: 0 auto; text-align: center;
          padding: 44px 36px; background: var(--light); border-radius: 10px;
          border: 1px solid rgba(73,100,162,0.08);
        }
        .mc-gate-icon {
          width: 56px; height: 56px; border-radius: 50%; margin: 0 auto 20px;
          background: rgba(73,100,162,0.1); color: var(--secondary);
          display: flex; align-items: center; justify-content: center;
        }
        .mc-gate-title { font-size: 22px; font-weight: 700; color: var(--primary); margin-bottom: 10px; }
        .mc-gate-sub { font-size: 14px; color: #555; line-height: 1.6; margin-bottom: 24px; }
        .mc-gate-form { display: flex; gap: 8px; }
        .mc-gate-input {
          flex: 1; padding: 13px 16px; border-radius: 6px; font-size: 15px;
          border: 1px solid rgba(73,100,162,0.25); background: #fff;
          color: var(--primary); outline: none; transition: border-color 0.2s; font-family: 'Exo 2', sans-serif;
        }
        .mc-gate-input:focus { border-color: #559CD6; }
        .mc-gate-input-error { border-color: #d65555 !important; animation: mcShake 0.4s; }
        @keyframes mcShake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-4px)} 40%,80%{transform:translateX(4px)} }
        .mc-gate-btn {
          padding: 13px 26px; border-radius: 6px; border: none; cursor: pointer;
          background: #559CD6; color: #fff; font-size: 15px; font-weight: 600; font-family: 'Exo 2', sans-serif;
          transition: background 0.2s;
        }
        .mc-gate-btn:hover { background: #4A8BC2; }
        .mc-gate-err { margin-top: 14px; color: #d65555; font-size: 13px; font-weight: 600; }

        /* Дедлайн */
        .mc-deadline {
          display: flex; align-items: center; gap: 10px;
          padding: 14px 18px; margin-bottom: 32px;
          background: rgba(85,156,214,0.1); border: 1px solid rgba(85,156,214,0.25);
          border-left: 3px solid #559CD6; border-radius: 6px;
          color: var(--primary); font-size: 14px; font-weight: 600;
        }
        .mc-deadline svg { flex-shrink: 0; color: #559CD6; }

        /* Сетка карточек */
        .mc-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 22px; }
        .mc-card {
          display: flex; flex-direction: column; padding: 28px 28px 24px;
          background: var(--light); border-radius: 8px; border: 1px solid rgba(73,100,162,0.08);
          transition: transform 0.4s cubic-bezier(0.16,1,0.3,1), box-shadow 0.4s, border-color 0.3s;
        }
        .mc-card:hover { transform: translateY(-4px); box-shadow: 0 18px 44px rgba(20,27,77,0.1); border-color: rgba(73,100,162,0.16); }
        .mc-card-full { opacity: 0.72; }
        .mc-card-top { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-bottom: 16px; }
        .mc-kind {
          padding: 5px 11px; border-radius: 5px; font-size: 11px; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.6px;
          background: rgba(85,156,214,0.14); color: #4A6FA5;
        }
        .mc-session {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 6px 12px; border-radius: 5px; background: rgba(73,100,162,0.1);
        }
        .mc-session-date { font-size: 13px; font-weight: 700; color: var(--secondary); }
        .mc-session-time { font-size: 13px; color: #4A5568; }
        .mc-card-title { font-size: 18px; font-weight: 700; color: var(--primary); line-height: 1.35; margin-bottom: 10px; }
        .mc-card-desc { font-size: 13px; color: #555; line-height: 1.6; margin-bottom: 4px; }
        .mc-card-foot {
          margin-top: auto; padding-top: 22px; display: flex; align-items: center;
          justify-content: space-between; gap: 12px; flex-wrap: wrap;
        }
        .mc-seats { display: flex; align-items: baseline; gap: 6px; }
        .mc-seats-num { font-size: 22px; font-weight: 700; color: var(--primary); }
        .mc-seats-cap { font-size: 12px; color: #4A5568; }
        .mc-seats-full { font-size: 14px; font-weight: 700; color: #d65555; }
        .mc-seats-load { font-size: 13px; color: #8893a8; }
        .mc-noreg {
          display: inline-flex; align-items: center;
          padding: 9px 16px; border-radius: 5px; font-size: 13px; font-weight: 700;
          background: rgba(67,160,107,0.12); color: #2f8359;
        }
        .mc-btn {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 11px 22px; border-radius: 4px; background: var(--secondary); color: #fff;
          font-size: 12px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase;
          text-decoration: none; cursor: pointer; transition: all 0.3s;
        }
        .mc-btn:hover { background: var(--primary); transform: translateY(-2px); box-shadow: 0 12px 28px rgba(20,27,77,0.22); }
        .mc-btn-disabled { background: #aeb6cb; cursor: not-allowed; pointer-events: none; }

        @media (max-width: 1024px) {
          .mc-hero { padding: 120px 32px 48px; }
          .mc-title { font-size: 34px; }
          .mc-content { padding: 48px 32px 70px; }
        }
        @media (max-width: 820px) {
          .mc-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 600px) {
          .mc-hero { padding: 100px 20px 40px; }
          .mc-title { font-size: 27px; }
          .mc-content { padding: 36px 18px 56px; }
          .mc-card { padding: 24px 22px 22px; }
          .mc-gate { padding: 32px 22px; }
          .mc-gate-form { flex-direction: column; }
        }
      `})]})}])}]);