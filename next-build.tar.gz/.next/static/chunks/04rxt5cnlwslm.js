(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,95057,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var n={formatUrl:function(){return i},formatWithValidation:function(){return s},urlObjectKeys:function(){return u}};for(var o in n)Object.defineProperty(r,o,{enumerable:!0,get:n[o]});let a=e.r(90809)._(e.r(98183)),l=/https?|ftp|gopher|file/;function i(e){let{auth:t,hostname:r}=e,n=e.protocol||"",o=e.pathname||"",i=e.hash||"",u=e.query||"",s=!1;t=t?encodeURIComponent(t).replace(/%3A/i,":")+"@":"",e.host?s=t+e.host:r&&(s=t+(~r.indexOf(":")?`[${r}]`:r),e.port&&(s+=":"+e.port)),u&&"object"==typeof u&&(u=String(a.urlQueryToSearchParams(u)));let c=e.search||u&&`?${u}`||"";return n&&!n.endsWith(":")&&(n+=":"),e.slashes||(!n||l.test(n))&&!1!==s?(s="//"+(s||""),o&&"/"!==o[0]&&(o="/"+o)):s||(s=""),i&&"#"!==i[0]&&(i="#"+i),c&&"?"!==c[0]&&(c="?"+c),o=o.replace(/[?#]/g,encodeURIComponent),c=c.replace("#","%23"),`${n}${s}${o}${c}${i}`}let u=["auth","hash","host","hostname","href","path","pathname","port","protocol","query","search","slashes"];function s(e){return i(e)}},18581,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"useMergedRef",{enumerable:!0,get:function(){return o}});let n=e.r(71645);function o(e,t){let r=(0,n.useRef)(null),o=(0,n.useRef)(null);return(0,n.useCallback)(n=>{if(null===n){let e=r.current;e&&(r.current=null,e());let t=o.current;t&&(o.current=null,t())}else e&&(r.current=a(e,n)),t&&(o.current=a(t,n))},[e,t])}function a(e,t){if("function"!=typeof e)return e.current=t,()=>{e.current=null};{let r=e(t);return"function"==typeof r?r:()=>e(null)}}("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},73668,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"isLocalURL",{enumerable:!0,get:function(){return a}});let n=e.r(18967),o=e.r(52817);function a(e){if(!(0,n.isAbsoluteUrl)(e))return!0;try{let t=(0,n.getLocationOrigin)(),r=new URL(e,t);return r.origin===t&&(0,o.hasBasePath)(r.pathname)}catch(e){return!1}}},84508,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"errorOnce",{enumerable:!0,get:function(){return n}});let n=e=>{}},22016,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var n={default:function(){return m},useLinkStatus:function(){return y}};for(var o in n)Object.defineProperty(r,o,{enumerable:!0,get:n[o]});let a=e.r(90809),l=e.r(43476),i=a._(e.r(71645)),u=e.r(95057),s=e.r(8372),c=e.r(18581),f=e.r(18967),d=e.r(5550);e.r(33525);let p=e.r(88540),h=e.r(91949),b=e.r(73668),g=e.r(9396);function m(t){var r,n;let o,a,m,[y,v]=(0,i.useOptimistic)(h.IDLE_LINK_STATUS),j=(0,i.useRef)(null),{href:_,as:k,children:C,prefetch:P=null,passHref:S,replace:O,shallow:w,scroll:T,onClick:N,onMouseEnter:R,onTouchStart:E,legacyBehavior:L=!1,onNavigate:A,transitionTypes:M,ref:U,unstable_dynamicOnHover:I,...z}=t;o=C,L&&("string"==typeof o||"number"==typeof o)&&(o=(0,l.jsx)("a",{children:o}));let B=i.default.useContext(s.AppRouterContext),D=!1!==P,$=!1!==P?null===(n=P)||"auto"===n?g.FetchStrategy.PPR:g.FetchStrategy.Full:g.FetchStrategy.PPR,K="string"==typeof(r=k||_)?r:(0,u.formatUrl)(r);if(L){if(o?.$$typeof===Symbol.for("react.lazy"))throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."),"__NEXT_ERROR_CODE",{value:"E863",enumerable:!1,configurable:!0});a=i.default.Children.only(o)}let F=L?a&&"object"==typeof a&&a.ref:U,q=i.default.useCallback(e=>(null!==B&&(j.current=(0,h.mountLinkInstance)(e,K,B,$,D,v)),()=>{j.current&&((0,h.unmountLinkForCurrentNavigation)(j.current),j.current=null),(0,h.unmountPrefetchableInstance)(e)}),[D,K,B,$,v]),W={ref:(0,c.useMergedRef)(q,F),onClick(t){L||"function"!=typeof N||N(t),L&&a.props&&"function"==typeof a.props.onClick&&a.props.onClick(t),!B||t.defaultPrevented||function(t,r,n,o,a,l,u){if("u">typeof window){let s,{nodeName:c}=t.currentTarget;if("A"===c.toUpperCase()&&((s=t.currentTarget.getAttribute("target"))&&"_self"!==s||t.metaKey||t.ctrlKey||t.shiftKey||t.altKey||t.nativeEvent&&2===t.nativeEvent.which)||t.currentTarget.hasAttribute("download"))return;if(!(0,b.isLocalURL)(r)){o&&(t.preventDefault(),location.replace(r));return}if(t.preventDefault(),l){let e=!1;if(l({preventDefault:()=>{e=!0}}),e)return}let{dispatchNavigateAction:f}=e.r(99781);i.default.startTransition(()=>{f(r,o?"replace":"push",!1===a?p.ScrollBehavior.NoScroll:p.ScrollBehavior.Default,n.current,u)})}}(t,K,j,O,T,A,M)},onMouseEnter(e){L||"function"!=typeof R||R(e),L&&a.props&&"function"==typeof a.props.onMouseEnter&&a.props.onMouseEnter(e),B&&D&&(0,h.onNavigationIntent)(e.currentTarget,!0===I)},onTouchStart:function(e){L||"function"!=typeof E||E(e),L&&a.props&&"function"==typeof a.props.onTouchStart&&a.props.onTouchStart(e),B&&D&&(0,h.onNavigationIntent)(e.currentTarget,!0===I)}};return(0,f.isAbsoluteUrl)(K)?W.href=K:L&&!S&&("a"!==a.type||"href"in a.props)||(W.href=(0,d.addBasePath)(K)),m=L?i.default.cloneElement(a,W):(0,l.jsx)("a",{...z,...W,children:o}),(0,l.jsx)(x.Provider,{value:y,children:m})}e.r(84508);let x=(0,i.createContext)(h.IDLE_LINK_STATUS),y=()=>(0,i.useContext)(x);("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},7156,e=>{"use strict";var t=e.i(43476),r=e.i(22016),n=e.i(71645);e.s(["default",0,function(){let[e,o]=(0,n.useState)(""),[a,l]=(0,n.useState)(null),[i,u]=(0,n.useState)(!1);async function s(t){t.preventDefault(),l(null),u(!0);try{let t=await fetch(`/api/admin/program?pw=${encodeURIComponent(e)}`),r=await t.json();if(t.ok&&r.ok){try{sessionStorage.setItem("ap_admin_pw_v1",e)}catch{}window.location.href="/admin/program"}else l(r.message||"Неверный пароль.")}catch{l("Ошибка соединения.")}finally{u(!1)}}return(0,t.jsxs)("main",{className:"al-main",children:[(0,t.jsxs)("div",{className:"al-card",children:[(0,t.jsx)("div",{className:"al-brand",children:"GLP-PLANET · Админ"}),(0,t.jsx)("h1",{className:"al-title",children:"Вход в панель"}),(0,t.jsx)("p",{className:"al-sub",children:"Расписание и управление конференцией"}),(0,t.jsxs)("form",{className:"al-form",onSubmit:s,children:[(0,t.jsxs)("label",{className:"al-field",children:[(0,t.jsx)("span",{children:"Пароль"}),(0,t.jsx)("input",{type:"password",value:e,onChange:e=>o(e.target.value),placeholder:"••••••••",autoFocus:!0,autoComplete:"off"})]}),a&&(0,t.jsx)("div",{className:"al-err",children:a}),(0,t.jsx)("button",{type:"submit",className:"al-btn",disabled:i||!e,children:i?"Проверка…":"Войти"})]}),(0,t.jsx)("div",{className:"al-divider"}),(0,t.jsx)("div",{className:"al-links",children:(0,t.jsx)(r.default,{href:"/admin/registrations",className:"al-alt-link",children:"Заявки на мастер-классы →"})}),(0,t.jsx)(r.default,{href:"/",className:"al-back",children:"← На главную"})]}),(0,t.jsx)("style",{children:`
        .al-main {
          min-height: 100vh; display: flex; align-items: center; justify-content: center;
          padding: 24px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 100%);
          font-family: 'Exo 2', sans-serif;
        }
        .al-card {
          width: 100%; max-width: 400px;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(107,130,196,0.2);
          border-radius: 10px;
          padding: 40px 36px;
        }
        .al-brand {
          font-size: 11px; letter-spacing: 3px; text-transform: uppercase;
          color: #6B82C4; font-weight: 600; margin-bottom: 16px;
        }
        .al-title { font-size: 26px; font-weight: 700; color: #fff; margin-bottom: 6px; }
        .al-sub { font-size: 14px; color: rgba(255,255,255,0.55); margin-bottom: 28px; }
        .al-form { display: flex; flex-direction: column; gap: 16px; }
        .al-field { display: flex; flex-direction: column; gap: 6px; }
        .al-field span {
          font-size: 12px; font-weight: 600; color: rgba(255,255,255,0.7);
          text-transform: uppercase; letter-spacing: 1px;
        }
        .al-field input {
          padding: 12px 14px; border-radius: 6px;
          background: rgba(8,12,36,0.5);
          border: 1px solid rgba(107,130,196,0.25);
          color: #fff; font-size: 14px; font-family: inherit;
          outline: none; transition: border-color 0.2s;
        }
        .al-field input:focus { border-color: #559CD6; }
        .al-err { color: #E08A8A; font-size: 13px; font-weight: 600; }
        .al-btn {
          margin-top: 8px; padding: 13px; border-radius: 6px;
          background: #559CD6; color: #fff; border: none; cursor: pointer;
          font-size: 15px; font-weight: 600; font-family: inherit;
          transition: background 0.2s;
        }
        .al-btn:hover:not(:disabled) { background: #4A8BC2; }
        .al-btn:disabled { opacity: 0.55; cursor: default; }
        .al-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 24px 0; }
        .al-links { display: flex; flex-direction: column; gap: 10px; }
        .al-alt-link {
          color: rgba(255,255,255,0.5); font-size: 13px; text-decoration: none;
          transition: color 0.2s;
        }
        .al-alt-link:hover { color: #fff; }
        .al-back {
          display: block; margin-top: 24px; text-align: center;
          color: rgba(255,255,255,0.35); font-size: 13px; text-decoration: none;
          transition: color 0.2s;
        }
        .al-back:hover { color: #fff; }
      `})]})}])}]);