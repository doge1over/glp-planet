(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,35255,t=>{"use strict";var e=t.i(43476),n=t.i(71645),r=t.i(70119),a=t.i(56691);function i({children:t,delay:r=0,direction:a="up"}){let o=(0,n.useRef)(null),[c,l]=(0,n.useState)(!1);return(0,n.useEffect)(()=>{let t=o.current;if(!t)return;let e=new IntersectionObserver(([t])=>{t.isIntersecting&&l(!0)},{threshold:.08});return e.observe(t),()=>e.disconnect()},[]),(0,e.jsx)("div",{ref:o,style:{opacity:+!!c,transform:c?"none":({up:"translateY(32px)",left:"translateX(-32px)",right:"translateX(32px)",scale:"scale(0.97)"})[a],transition:`opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${r}ms, transform 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${r}ms`},children:t})}let o=[{label:"E-mail",value:"sci.secretary@glp-planet.com",href:null,copy:!0},{label:"Телефон",value:"+7 (981) 041-01-45",subtext:"Ковалева Мария",href:"tel:+79810410145"},{label:"Место проведения",value:"Отель «Санкт-Петербург»",subtext:"Пироговская набережная, д. 5/2, г. Санкт-Петербург",href:null}];t.s(["default",0,function(){let[t,c]=(0,n.useState)(!1),l=()=>{navigator.clipboard.writeText("sci.secretary@glp-planet.com"),c(!0),setTimeout(()=>c(!1),2e3)};return(0,e.jsxs)(e.Fragment,{children:[(0,e.jsx)(r.default,{}),(0,e.jsxs)("main",{style:{minHeight:"100vh"},children:[(0,e.jsx)("section",{className:"contacts-hero",children:(0,e.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,e.jsx)(i,{children:(0,e.jsx)("div",{style:{fontSize:11,color:"#6B82C4",fontWeight:600,textTransform:"uppercase",letterSpacing:3,marginBottom:12},children:"Связь"})}),(0,e.jsx)(i,{delay:80,children:(0,e.jsx)("h1",{className:"contacts-title",children:"Контакты"})}),(0,e.jsx)(i,{delay:160,children:(0,e.jsx)("p",{style:{fontSize:16,color:"rgba(255,255,255,0.6)",lineHeight:1.8,maxWidth:500},children:"Свяжитесь с нами по любым вопросам, связанным с конференцией"})})]})}),(0,e.jsx)("section",{className:"contacts-content",children:(0,e.jsxs)("div",{className:"contacts-grid",style:{maxWidth:1200,margin:"0 auto"},children:[(0,e.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:16},children:o.map((n,r)=>(0,e.jsx)(i,{delay:80+120*r,direction:"left",children:(0,e.jsxs)("div",{className:"contact-card",style:{padding:"28px 32px",background:"var(--light)",borderRadius:4,border:"1px solid rgba(73,100,162,0.06)"},children:[(0,e.jsx)("div",{style:{fontSize:11,color:"var(--muted)",fontWeight:600,textTransform:"uppercase",letterSpacing:2,marginBottom:8},children:n.label}),n.copy?(0,e.jsxs)("button",{onClick:l,className:"contact-link contact-copy-btn",style:{fontSize:17,fontWeight:600,color:"var(--primary)",background:"none",border:"none",padding:0,cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",alignItems:"center",gap:8},children:[n.value,(0,e.jsx)("span",{className:"contact-copy-hint",style:t?{opacity:1}:void 0,children:t?"✓ Скопировано":"Копировать"})]}):n.href?(0,e.jsx)("a",{href:n.href,className:"contact-link",style:{fontSize:17,fontWeight:600,color:"var(--primary)",textDecoration:"none"},children:n.value}):(0,e.jsx)("div",{style:{fontSize:17,fontWeight:600,color:"var(--primary)",lineHeight:1.5},children:n.value}),n.subtext&&(0,e.jsx)("div",{style:{fontSize:13,color:"var(--muted)",marginTop:4,lineHeight:1.5},children:n.subtext})]})},r))}),(0,e.jsx)(i,{delay:200,direction:"right",children:(0,e.jsxs)("div",{style:{padding:32,background:"var(--primary)",borderRadius:4,height:"100%"},children:[(0,e.jsx)("h3",{style:{fontSize:20,fontWeight:700,color:"#fff",marginBottom:24},children:"VII Конференция GLP-PLANET"}),(0,e.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:18},children:[{label:"Даты",value:"1–3 июля 2026 г."},{label:"Город",value:"Санкт-Петербург"},{label:"Площадка",value:"Отель «Санкт-Петербург»"},{label:"Совместно с",value:"Rus-LASA"}].map((t,n)=>(0,e.jsxs)("div",{children:[(0,e.jsx)("div",{style:{fontSize:11,color:"rgba(255,255,255,0.5)",letterSpacing:1.5,textTransform:"uppercase",marginBottom:4},children:t.label}),(0,e.jsx)("div",{style:{color:"rgba(255,255,255,0.9)",fontSize:15},children:t.value})]},n))}),(0,e.jsx)("div",{style:{marginTop:28},children:(0,e.jsx)("a",{href:"/registration",className:"contacts-btn",children:"Регистрация"})})]})})]})})]}),(0,e.jsx)(a.default,{}),(0,e.jsx)("style",{children:`
        .contacts-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
        }
        .contacts-title {
          font-size: 42px; font-weight: 700; color: #fff; line-height: 1.2; margin-bottom: 16px;
        }
        .contacts-content { padding: 80px 48px; }

        .contacts-grid {
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 24px;
          align-items: start;
        }
        .contact-card {
          transition: all 0.5s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .contact-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 32px rgba(20,27,77,0.06);
          border-color: rgba(73,100,162,0.12);
        }
        .contact-link {
          transition: color 0.3s;
        }
        .contact-link:hover {
          color: var(--secondary) !important;
        }
        .contact-copy-btn:hover {
          color: var(--secondary) !important;
        }
        .contact-copy-hint {
          font-size: 11px;
          font-weight: 500;
          color: var(--secondary);
          opacity: 0;
          transition: opacity 0.3s;
        }
        .contact-copy-btn:hover .contact-copy-hint {
          opacity: 1;
        }
        .contacts-btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 13px 28px;
          background: rgba(255,255,255,0.08);
          border: 1.5px solid rgba(255,255,255,0.15);
          border-radius: 3px;
          color: #fff;
          font-family: 'Exo 2', sans-serif;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 1px;
          text-transform: uppercase;
          text-decoration: none;
          cursor: pointer;
          transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
        }
        .contacts-btn:hover {
          background: rgba(255,255,255,0.15);
          border-color: rgba(255,255,255,0.3);
          transform: translateY(-2px);
        }
        @media (max-width: 1024px) {
          .contacts-hero { padding: 120px 32px 48px; }
          .contacts-title { font-size: 34px; }
          .contacts-content { padding: 60px 32px; }

        }
        @media (max-width: 900px) {
          .contacts-grid {
            grid-template-columns: 1fr;
          }
        }
        @media (max-width: 600px) {
          .contacts-hero { padding: 100px 20px 40px; }
          .contacts-title { font-size: 28px; }
          .contacts-content { padding: 40px 20px; }

        }
      `})]})}])}]);