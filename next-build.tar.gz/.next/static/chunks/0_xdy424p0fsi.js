(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,59095,e=>{"use strict";var t=e.i(43476),s=e.i(71645);let i=new Map,a=null,n={up:"translateY(40px)",left:"translateX(-40px)",right:"translateX(40px)",scale:"scale(0.96)"};e.s(["default",0,function({children:e,delay:o=0,direction:r="up"}){let l=(0,s.useRef)(null),[p,d]=(0,s.useState)(!1),c=(0,s.useCallback)(()=>d(!0),[]);return(0,s.useEffect)(()=>{let e=l.current;if(!e)return;let t=(a||(a=new IntersectionObserver(e=>{for(let t of e)if(t.isIntersecting){let e=i.get(t.target);e&&(e(),i.delete(t.target),a?.unobserve(t.target))}},{threshold:.1})),a);return i.set(e,c),t.observe(e),()=>{i.delete(e),t.unobserve(e)}},[c]),(0,t.jsx)("div",{ref:l,style:{opacity:+!!p,transform:p?"none":n[r],transition:`all 0.65s cubic-bezier(0.16, 1, 0.3, 1) ${o}ms`,willChange:p?"auto":"opacity, transform"},children:e})}])},67484,e=>{"use strict";var t=e.i(43476),s=e.i(71645),i=e.i(59095),a=e.i(57688);let n=[{label:"Генеральные спонсоры",sponsors:[{name:"FarmBioLine",img:"/images/sponsors/logo_bronzovyj_sponsor_farmbiolajn-1.png",href:"https://farmbioline.ru/",scale:1.6}],speed:28},{label:"Золотые спонсоры",sponsors:[{name:"БиоГен-Аналитика",img:"/images/sponsors/@logo.png",href:"https://bga.ru/"},{name:"БиоЛайн",img:"/images/sponsors/BL_rus_LOGO.png",href:"https://bioline.ru/"}],speed:32},{label:"Спонсоры",sponsors:[{name:"ТехноИнфо",img:"/images/sponsors/ТехноИнфо_LOGO_2024 (5).png",href:"https://technoinfo.ru/"},{name:"Группа компаний «Р-Фарм»",img:"/images/sponsors/Р-Фарм.png",href:"https://www.r-pharm.com"},{name:"LUMINON",img:"/images/sponsors/Logo-487х183.png",href:"https://luminon.ru"},{name:"LabNeo",img:"/images/sponsors/labneo.png",href:"https://labneo.ru/"},{name:"SciCat — платформа научных каталогов",img:"/images/partners/scicat.png",href:"https://sci-cat.ru/"},{name:"ООО «ФИЗЛАБПРИБОР»",img:"/images/sponsors/fizlab.png",href:"https://fizlab.ru/"},{name:"Биокад",img:"/images/sponsors/logo_BIOCAD_25_color_2.png",href:"https://biocad.ru/"},{name:"АО «НПО «ДОМ ФАРМАЦИИ»",img:"/images/sponsors/logo-vector.png",href:"https://doclinika.ru/"},{name:"ООО «ВЕТКОРМТОРГ»",img:"/images/sponsors/веткт лого.png",href:"https://vetkt.ru/"},{name:"ООО «БМТ-МММ»",img:"/images/sponsors/BMT_logo.jpg",href:"https://bmt-mmm.ru/ ",scale:1.6},{name:"BioInn Labs",img:"/images/sponsors/логотип.jpg",href:"https://bioinnlabs.ru",scale:1.2},{name:"АНО АВТех",img:"/images/sponsors/Логотип AWTECH.png",href:"https://awt.ru/product/vivariy/"},{name:"Группа компаний «ЭДВАНСД»",img:"/images/sponsors/logo_advanced.png",scale:1.4,className:"sponsor-edvansed"}],speed:35},{label:"Информационные партнёры",sponsors:[{name:"Журнал «Разработка и регистрация лекарственных средств»",img:"/images/partners/rrl.png",href:"https://www.pharmjournal.ru/jour/announcement/view/618"},{name:"Лабораторные животные",img:"/images/sponsors/laj-logo-1862x518-transparent-bg.png",href:"https://labanimalsjournal.ru/"},{name:"StereotaX",img:"/images/sponsors/STAX_LOGO_BLACK-01.png",href:"https://stereotax.info/",scale:1.6},{name:"НАИИО",img:"/images/sponsors/NAIIO_RUS_Logo1-01.png",href:"https://наиио.рф/рабочие-группы/"}],speed:38}];function o({s:e}){let s=(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"sponsor-slide-inner",children:(0,t.jsx)(a.default,{src:e.img,alt:e.name,width:200,height:80,style:{width:"auto",height:"auto",maxWidth:180*(e.scale??1),maxHeight:70*(e.scale??1),objectFit:"contain",transform:e.offsetY?`translateY(${e.offsetY}px)`:void 0}})}),(0,t.jsx)("div",{className:"sponsor-slide-name",children:e.name})]});return e.href?(0,t.jsx)("a",{href:e.href,target:"_blank",rel:"noopener noreferrer",className:`sponsor-slide sponsor-slide-link${e.className?` ${e.className}`:""}`,children:s}):(0,t.jsx)("div",{className:`sponsor-slide${e.className?` ${e.className}`:""}`,children:s})}function r({tier:e}){let{label:i,sponsors:a,speed:n=30}=e,l=(0,s.useRef)(null),[p,d]=(0,s.useState)(!1);(0,s.useEffect)(()=>{if(a.length<2)return void d(!1);let e=l.current;if(!e)return;let t=()=>{let t=e.clientWidth,s=window.innerWidth,i=240,n=32;s<=600?(i=170,n=20):s<=1024&&(i=200,n=32),d(a.length*i+(a.length-1)*n>t-16)};t();let s=new ResizeObserver(t);return s.observe(e),()=>s.disconnect()},[a.length]);let c=p?Array.from({length:8},()=>a).flat():a;return(0,t.jsxs)("div",{className:"tier-row",ref:l,children:[(0,t.jsxs)("div",{className:"tier-label-wrap",children:[(0,t.jsx)("div",{className:"tier-label",children:i}),(0,t.jsx)("div",{className:"tier-divider"})]}),0===a.length?(0,t.jsx)("div",{className:"tier-empty-wrap",children:(0,t.jsx)("div",{className:"tier-empty",children:"Скоро…"})}):p?(0,t.jsx)("div",{className:"tier-carousel",children:(0,t.jsx)("div",{className:"tier-track tier-track-scroll",style:{animationDuration:`${n}s`,"--count":a.length},children:c.map((e,s)=>(0,t.jsx)(o,{s:e},s))})}):(0,t.jsx)("div",{className:"tier-static-wrap",children:a.map((e,s)=>(0,t.jsx)(o,{s:e},s))})]})}e.s(["default",0,function(){return(0,t.jsxs)("section",{className:"sponsors-section",children:[(0,t.jsxs)("div",{className:"sponsors-header",children:[(0,t.jsx)(i.default,{children:(0,t.jsx)("div",{className:"section-label",children:"Спонсоры"})}),(0,t.jsx)(i.default,{delay:60,children:(0,t.jsx)("h2",{className:"section-title",style:{marginBottom:16},children:"Нас поддерживают"})}),(0,t.jsx)(i.default,{delay:100,children:(0,t.jsx)("p",{className:"sponsors-desc",children:"Мы благодарим наших партнёров и спонсоров за поддержку конференции"})})]}),(0,t.jsx)("div",{className:"tiers-wrap",children:n.map((e,s)=>(0,t.jsx)(i.default,{delay:140+80*s,children:(0,t.jsx)(r,{tier:e})},s))}),(0,t.jsx)("style",{children:`
                .sponsors-section {
                    padding: 100px 0 110px;
                    background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
                    position: relative;
                }
                .sponsors-header { max-width: 1200px; margin: 0 auto; padding: 0 48px; }
                .sponsors-section .section-label { color: #6B82C4; }
                .sponsors-section .section-title { color: #fff; }
                .sponsors-desc {
                    font-size: 15px;
                    color: rgba(255,255,255,0.4);
                    line-height: 1.7;
                    max-width: 480px;
                    margin-bottom: 56px;
                }

                .tiers-wrap {
                    display: flex;
                    flex-direction: column;
                    gap: 48px;
                }

                .tier-row { width: 100%; }

                .tier-label-wrap {
                    max-width: 1200px;
                    margin: 0 auto 20px;
                    padding: 0 48px;
                    display: flex;
                    align-items: center;
                    gap: 16px;
                }
                .tier-label {
                    font-size: 11px;
                    color: rgba(255,255,255,0.5);
                    font-weight: 600;
                    letter-spacing: 2.5px;
                    text-transform: uppercase;
                    flex-shrink: 0;
                }
                .tier-divider {
                    flex: 1;
                    height: 1px;
                    background: linear-gradient(to right, rgba(107,130,196,0.3), transparent);
                }

                .tier-empty-wrap {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 0 48px;
                    box-sizing: border-box;
                }
                .tier-empty {
                    height: 110px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: rgba(255,255,255,0.2);
                    font-size: 12px;
                    font-style: italic;
                    letter-spacing: 1px;
                    border: 1px dashed rgba(107,130,196,0.12);
                    border-radius: 6px;
                }

                .tier-static-wrap {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 16px 48px;
                    display: flex;
                    gap: 32px;
                    justify-content: center;
                    flex-wrap: wrap;
                    box-sizing: border-box;
                }

                .tier-carousel {
                    width: 100%;
                    overflow-x: hidden;
                    overflow-y: visible;
                    padding: 16px 0;
                    -webkit-mask-image: linear-gradient(to right, transparent 0%, black 6%, black 94%, transparent 100%);
                    mask-image: linear-gradient(to right, transparent 0%, black 6%, black 94%, transparent 100%);
                }

                .tier-track {
                    --slide-w: 240px;
                    --gap: 32px;
                    display: flex;
                    gap: var(--gap);
                    align-items: flex-start;
                }
                .tier-track-scroll {
                    width: max-content;
                    animation-name: sponsorScroll;
                    animation-timing-function: linear;
                    animation-iteration-count: infinite;
                    will-change: transform;
                }
                .tier-track-scroll:hover {
                    animation-play-state: paused;
                }

                @keyframes sponsorScroll {
                    from { transform: translate3d(0, 0, 0); }
                    to   { transform: translate3d(calc(-1 * var(--count) * (var(--slide-w) + var(--gap))), 0, 0); }
                }

                .sponsor-slide {
                    flex-shrink: 0;
                    width: 240px;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 16px;
                    text-decoration: none;
                }
                .sponsor-slide-inner {
                    width: 240px;
                    height: 110px;
                    background: #fff;
                    isolation: isolate;
                    border-radius: 6px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px 24px;
                    transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
                    border: 1px solid rgba(107,130,196,0.1);
                    overflow: hidden;
                    box-sizing: border-box;
                }
                .sponsor-slide-inner img {
                    mix-blend-mode: multiply;
                }
                .sponsor-slide:hover .sponsor-slide-inner {
                    transform: translateY(-6px);
                    box-shadow: 0 16px 40px rgba(0,0,0,0.2);
                    border-color: rgba(107,130,196,0.25);
                }
                .sponsor-slide-name {
                    font-size: 11px;
                    color: rgba(255,255,255,0.35);
                    font-weight: 500;
                    letter-spacing: 0.5px;
                    text-align: center;
                    transition: color 0.3s;
                    max-width: 240px;
                    line-height: 1.4;
                }
                .sponsor-slide:hover .sponsor-slide-name {
                    color: rgba(255,255,255,0.6);
                }

                @media (max-width: 1024px) {
                    .sponsors-section { padding: 80px 0 90px; }
                    .sponsors-header { padding: 0 32px; }
                    .sponsors-desc { margin-bottom: 44px; }
                    .tier-label-wrap { padding: 0 32px; }
                    .tier-empty-wrap { padding: 0 32px; }
                    .tier-static-wrap { padding: 16px 32px; gap: 24px; }
                    .tier-track { --slide-w: 200px; }
                    .sponsor-slide { width: 200px; }
                    .sponsor-slide-inner { width: 200px; height: 100px; padding: 18px 20px; }
                    .sponsor-slide-name { max-width: 200px; }
                    .tiers-wrap { gap: 36px; }
                }
                @media (max-width: 600px) {
                    .sponsors-section { padding: 60px 0 70px; }
                    .sponsors-header { padding: 0 20px; }
                    .sponsors-desc { font-size: 14px; margin-bottom: 36px; }
                    .tier-label-wrap { padding: 0 20px; margin-bottom: 14px; }
                    .tier-empty-wrap { padding: 0 20px; }
                    .tier-empty { height: 90px; font-size: 11px; }
                    .tier-static-wrap { padding: 16px 20px; gap: 16px; }
                    .tier-track { --slide-w: 170px; --gap: 20px; }
                    .sponsor-slide { width: 170px; }
                    .sponsor-slide-inner { width: 170px; height: 85px; padding: 16px; }
                    .sponsor-slide-inner img { max-width: 140px !important; max-height: 55px !important; }
                    .sponsor-edvansed .sponsor-slide-inner img { max-width: 165px !important; max-height: 76px !important; transform: none !important; }
                    .sponsor-slide-name { font-size: 10px; max-width: 170px; }
                    .tiers-wrap { gap: 28px; }
                    .tier-label { font-size: 10px; letter-spacing: 1.5px; }
                }
            `})]})}])},92349,e=>{"use strict";var t=e.i(43476),s=e.i(71645);let i=e=>e*Math.PI/180,a=[{lat:59.94,lon:30.31,label:"Санкт-Петербург",offsetX:14,offsetY:-18},{lat:55.75,lon:37.62,label:"Москва",offsetX:14,offsetY:-10},{lat:53.9,lon:27.57,label:"Беларусь",offsetX:-14,offsetY:-12},{lat:40.18,lon:44.51,label:"Армения",offsetX:14,offsetY:-10},{lat:43,lon:41.02,label:"Абхазия",offsetX:-14,offsetY:-10},{lat:41.72,lon:44.79,label:"Грузия",offsetX:14,offsetY:14},{lat:51.17,lon:71.43,label:"Казахстан",offsetX:14,offsetY:-14},{lat:41.31,lon:69.28,label:"Узбекистан",offsetX:14,offsetY:14},{lat:51.51,lon:-.13,label:"Великобритания",offsetX:-14,offsetY:-18},{lat:48.86,lon:2.35,label:"Франция",offsetX:-14,offsetY:14},{lat:52.52,lon:13.41,label:"Германия",offsetX:14,offsetY:16},{lat:50.85,lon:4.35,label:"Бельгия",offsetX:-14,offsetY:16},{lat:55.68,lon:12.57,label:"Дания",offsetX:-14,offsetY:-16},{lat:40.42,lon:-3.7,label:"Испания",offsetX:-14,offsetY:-14},{lat:41.9,lon:12.5,label:"Италия",offsetX:-14,offsetY:-10},{lat:46.95,lon:7.45,label:"Швейцария",offsetX:-14,offsetY:16},{lat:44.82,lon:20.46,label:"Сербия",offsetX:14,offsetY:12},{lat:39.9,lon:116.4,label:"Китай",offsetX:14,offsetY:-12},{lat:28.61,lon:77.21,label:"Индия",offsetX:14,offsetY:-12},{lat:38.91,lon:-77.04,label:"США",offsetX:-14,offsetY:-14},{lat:23.11,lon:-82.37,label:"Куба",offsetX:-14,offsetY:12},{lat:-33.93,lon:18.42,label:"ЮАР",offsetX:14,offsetY:14}].map(e=>({cosLat:Math.cos(i(e.lat)),sinLat:Math.sin(i(e.lat)),lonR:i(e.lon),label:e.label,offsetX:e.offsetX,offsetY:e.offsetY}));function n({size:e=440}){let o=(0,s.useRef)(null),r=(0,s.useRef)(0),l=(0,s.useRef)(0),p=(0,s.useRef)([]),d=(0,s.useRef)(!1),[c,x]=(0,s.useState)(!1);(0,s.useEffect)(()=>{let t=o.current;if(!t||d.current)return;d.current=!0;let s=window.devicePixelRatio||1;t.width=e*s,t.height=e*s,t.style.width=e+"px",t.style.height=e+"px",t.getContext("2d").setTransform(s,0,0,s,0,0)},[e]),(0,s.useEffect)(()=>{fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json").then(e=>e.json()).then(e=>{let t=function(e){let t=document.createElement("canvas");t.width=720,t.height=360;let s=t.getContext("2d");for(let t of(s.fillStyle="#000",s.fillRect(0,0,720,360),s.fillStyle="#fff",e)){s.beginPath();for(let e=0;e<t.length;e++){let i=(t[e][0]+180)/360*720,a=(90-t[e][1])/180*360;0===e?s.moveTo(i,a):s.lineTo(i,a)}s.closePath(),s.fill()}let i=s.getImageData(0,0,720,360),a=new Uint8Array(259200);for(let e=0;e<a.length;e++)a[e]=+(i.data[4*e]>128);return a}(function(e){let{scale:t,translate:s}=e.transform,i=e.arcs.map(e=>{let i=0,a=0;return e.map(([e,n])=>(i+=e,a+=n,[i*t[0]+s[0],a*t[1]+s[1]]))}),a=[],n=e.objects.land;for(let e of"GeometryCollection"===n.type?n.geometries:[n])for(let t of"MultiPolygon"===e.type?e.arcs.flat():e.arcs||[]){let e=[];for(let s of t){let t=s>=0?i[s]:[...i[~s]].reverse(),a=+(e.length>0);for(let s=a;s<t.length;s++)e.push(t[s])}e.length>2&&a.push(e)}return a}(e)),s=[];for(let e=88;e>=-88;e-=2.5){let a=i(e),n=Math.cos(a),o=Math.sin(a),r=2.5/Math.max(n,.2);for(let a=-180;a<180;a+=r){let r=Math.floor((a+180)/360*720);r>=720&&(r-=720);let l=Math.floor((90-e)/180*360),p=l>=0&&l<360&&1===t[720*l+r];s.push({cosLat:n,sinLat:o,lonR:i(a),land:p})}}p.current=s,x(!0)}).catch(()=>x(!0))},[]);let h=(0,s.useCallback)(()=>{let t=o.current;if(!t)return;let s=t.getContext("2d");if(!s)return;let i=e/2,n=e/2,d=.42*e,c=l.current,x=Math.cos(c),f=Math.sin(c);s.clearRect(0,0,e,e),s.fillStyle="rgba(50,100,200,0.04)",s.beginPath(),s.arc(i,n,1.12*d,0,2*Math.PI),s.fill(),s.strokeStyle="rgba(60,130,240,0.06)",s.lineWidth=8,s.beginPath(),s.arc(i,n,1.04*d,0,2*Math.PI),s.stroke(),s.strokeStyle="rgba(80,140,230,0.18)",s.lineWidth=1,s.beginPath(),s.arc(i,n,d,0,2*Math.PI),s.stroke(),s.strokeStyle="rgba(60,110,200,0.03)",s.lineWidth=.3;for(let e=1;e<6;e++){let t=-Math.PI/2+Math.PI*e/6,a=n-d*Math.sin(t),o=d*Math.cos(t);s.beginPath(),s.ellipse(i,a,o,.06*o,0,0,2*Math.PI),s.stroke()}for(let e=0;e<10;e++){let t=Math.abs(Math.cos(e/10*Math.PI+c));s.strokeStyle=`rgba(60,110,200,${.01+.03*t})`,s.beginPath(),s.ellipse(i,n,t*d,d,0,0,2*Math.PI),s.stroke()}let g=p.current;s.fillStyle="rgba(50,90,170,0.035)",s.beginPath();for(let e=0;e<g.length;e++){let t=g[e],a=Math.sin(t.lonR)*x+Math.cos(t.lonR)*f,o=Math.cos(t.lonR)*x-Math.sin(t.lonR)*f;if(t.cosLat*o<.02||t.land)continue;let r=i+d*t.cosLat*a,l=n-d*t.sinLat;s.rect(r-.35,l-.35,.7,.7)}for(let[e,t,a,o]of(s.fill(),[[.02,.3,"rgba(90,165,250,0.22)",1.2],[.3,.6,"rgba(100,175,255,0.42)",1.5],[.6,1.1,"rgba(120,190,255,0.62)",1.8]])){s.fillStyle=a.replace(/[\d.]+\)$/,`${o>1.5?.1:.06})`),s.beginPath();for(let a=0;a<g.length;a++){let r=g[a];if(!r.land)continue;let l=Math.sin(r.lonR)*x+Math.cos(r.lonR)*f,p=Math.cos(r.lonR)*x-Math.sin(r.lonR)*f,c=r.cosLat*p;if(c<e||c>=t)continue;let h=i+d*r.cosLat*l,m=n-d*r.sinLat,u=o+1.5;s.rect(h-u/2,m-u/2,u,u)}s.fill(),s.fillStyle=a,s.beginPath();for(let a=0;a<g.length;a++){let r=g[a];if(!r.land)continue;let l=Math.sin(r.lonR)*x+Math.cos(r.lonR)*f,p=Math.cos(r.lonR)*x-Math.sin(r.lonR)*f,c=r.cosLat*p;if(c<e||c>=t)continue;let h=i+d*r.cosLat*l,m=n-d*r.sinLat;s.rect(h-o/2,m-o/2,o,o)}s.fill()}let m=(Math.sin(3*c)+1)*.5,u=[];for(let e=0;e<a.length;e++){let t=a[e],s=Math.sin(t.lonR)*x+Math.cos(t.lonR)*f,o=Math.cos(t.lonR)*x-Math.sin(t.lonR)*f,r=t.cosLat*o;if(r<.15)continue;let l=i+d*t.cosLat*s,p=n-d*t.sinLat,c=.3+.7*r;u.push({m:t,px:l,py:p,z:r,alpha:c})}u.sort((e,t)=>t.z-e.z);let b=[];for(let{m:t,px:i,py:a,alpha:n}of(s.font="500 8px 'Exo 2', sans-serif",u)){s.fillStyle=`rgba(190,225,255,${.08*n})`,s.beginPath(),s.arc(i,a,8+3*m,0,2*Math.PI),s.fill(),s.fillStyle=`rgba(210,235,255,${.85*n})`,s.beginPath(),s.arc(i,a,2.2+.3*m,0,2*Math.PI),s.fill(),s.fillStyle=`rgba(240,250,255,${.7*n})`,s.beginPath(),s.arc(i,a,.9,0,2*Math.PI),s.fill();let o=t.offsetX>0?1:-1,r=t.offsetY>0?1:-1,l=i+22*o,p=a+r*Math.abs(t.offsetY/t.offsetX)*22,d=l+15*o,c=s.measureText(t.label).width,x=o>0?d-3:d-c-3,h=o>0?d+c+3:d+3,f=p-14,g=p+3,u=r;for(let t=0;t<12;t++){let t=!1;for(let e of b)if(x<e.x2&&h>e.x1&&f<e.y2&&g>e.y1){t=!0;break}if(!t)break;f<8&&u<0&&(u=1),g>e-8&&u>0&&(u=-1);let s=16*u;p+=s,f+=s,g+=s}if(f<4){let e=4-f;p+=e,f+=e,g+=e}if(g>e-4){let t=g-(e-4);p-=t,f-=t,g-=t}b.push({x1:x,y1:f,x2:h,y2:g}),s.strokeStyle=`rgba(160,210,255,${.25*n})`,s.lineWidth=.6,s.beginPath(),s.moveTo(i,a),s.lineTo(l,p),s.stroke(),s.beginPath(),s.moveTo(l,p),s.lineTo(l+12*o,p),s.stroke(),s.fillStyle=`rgba(255,255,255,${.75*n})`,s.textBaseline="bottom",s.textAlign=o>0?"left":"right",s.fillText(t.label,d,p-1)}l.current+=.0015,r.current=requestAnimationFrame(h)},[e]);return(0,s.useEffect)(()=>{if(c)return r.current=requestAnimationFrame(h),()=>cancelAnimationFrame(r.current)},[h,c]),(0,t.jsx)("canvas",{ref:o,style:{width:e,height:e,opacity:+!!c,transition:"opacity 0.5s"}})}var o=e.i(21101);let r=new Date("2026-07-01T09:00:00+03:00").getTime();e.s(["default",0,function(){let e=function(){let[e,t]=(0,s.useState)(!1),[i,a]=(0,s.useState)(r);(0,s.useEffect)(()=>{t(!0),a(Date.now());let e=setInterval(()=>a(Date.now()),1e3);return()=>clearInterval(e)},[]);let n=e?Math.max(0,r-i):0;return{days:Math.floor(n/864e5),hours:Math.floor(n%864e5/36e5),minutes:Math.floor(n%36e5/6e4),seconds:Math.floor(n%6e4/1e3)}}();return(0,t.jsxs)("section",{style:{position:"relative",minHeight:"100vh",display:"flex",alignItems:"center",background:"linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%)",overflow:"hidden"},children:[(0,t.jsx)("div",{className:"grid-pattern",style:{position:"absolute",inset:0,pointerEvents:"none"}}),(0,t.jsxs)("div",{className:"hero-grid",children:[(0,t.jsxs)("div",{style:{flex:"1 1 52%",minWidth:0},children:[(0,t.jsxs)("div",{className:"hero-date-badge",style:{animation:"fadeUp 0.6s ease-out"},children:[(0,t.jsx)("div",{style:{width:5,height:5,borderRadius:1,background:"#6B82C4"}}),(0,t.jsx)("span",{children:"01 — 03 июля 2026 · Санкт-Петербург"})]}),(0,t.jsx)("h1",{className:"hero-title-light",style:{animation:"fadeUp 0.65s ease-out 0.08s both"},children:"Конференция"}),(0,t.jsxs)("h1",{className:"hero-title-bold",style:{animation:"fadeUp 0.65s ease-out 0.16s both"},children:["GLP-PLANET ",(0,t.jsx)("span",{style:{fontWeight:300,color:"#fff"},children:"VII"})]}),(0,t.jsx)("p",{className:"hero-subtitle",style:{animation:"fadeUp 0.65s ease-out 0.24s both"},children:"Совместно с Русской ассоциацией специалистов по лабораторным животным Rus-LASA"}),(0,t.jsx)("p",{className:"hero-desc",style:{animation:"fadeUp 0.65s ease-out 0.28s both"},children:"12 тематических сессий, мастер-классы и круглые столы. Очное и онлайн участие."}),(0,t.jsxs)("div",{className:"hero-buttons-wrap",style:{animation:"fadeUp 0.65s ease-out 0.30s both"},children:[(0,t.jsxs)("div",{className:"hero-notice",children:[(0,t.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("circle",{cx:"12",cy:"12",r:"10"}),(0,t.jsx)("line",{x1:"12",y1:"8",x2:"12",y2:"12"}),(0,t.jsx)("circle",{cx:"12",cy:"16",r:"0.6",fill:"currentColor"})]}),(0,t.jsx)("span",{children:"Приём докладов на конференцию GLP-PLANET закрыт!"})]}),(0,t.jsxs)("div",{className:"hero-buttons",children:[(0,t.jsxs)("a",{href:"/registration",className:"btn-primary",style:{textDecoration:"none"},children:[(0,t.jsx)("span",{children:"Регистрация"}),(0,t.jsx)(o.IconArrow,{})]}),(0,t.jsxs)("a",{href:"/docs/Programma_GLP_PLANET_VII-1.pdf",target:"_blank",rel:"noopener noreferrer",className:"btn-outline",style:{textDecoration:"none"},children:[(0,t.jsx)(o.IconFile,{}),(0,t.jsx)("span",{children:"Программа конференции"})]})]})]})]}),(0,t.jsx)("div",{className:"hero-globe",style:{flex:"0 0 auto",position:"relative",animation:"fadeIn 1.2s ease-out 0.5s both"},children:(0,t.jsx)(n,{size:440})})]}),(0,t.jsx)("div",{className:"hero-countdown",style:{animation:"fadeUp 0.8s ease-out 0.5s both"},children:[{value:e.days,label:"дней"},{value:e.hours,label:"часов"},{value:e.minutes,label:"минут"},{value:e.seconds,label:"секунд"}].map((e,s)=>(0,t.jsxs)("div",{className:"hero-countdown-item",children:[(0,t.jsx)("div",{className:"hero-countdown-value",children:String(e.value).padStart(2,"0")}),(0,t.jsx)("div",{className:"hero-countdown-label",children:e.label})]},s))}),(0,t.jsx)("style",{children:`
        .hero-grid {
          max-width: 1240px; margin: 0 auto; padding: 120px 48px 140px;
          position: relative; z-index: 2; width: 100%;
          display: flex; align-items: center; justify-content: space-between; gap: 24px;
        }
        .hero-date-badge {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 7px 18px; border: 1px solid rgba(107,130,196,0.2);
          border-radius: 2px; margin-bottom: 32px;
        }
        .hero-date-badge span {
          color: rgba(255,255,255,0.75); font-size: 11px; font-weight: 500;
          letter-spacing: 2.5px; text-transform: uppercase;
        }
        .hero-title-light {
          font-size: 52px; font-weight: 300; color: #fff;
          line-height: 1.12; margin-bottom: 4px; letter-spacing: -0.5px;
        }
        .hero-title-bold {
          font-size: 52px; font-weight: 800; color: #fff;
          line-height: 1.12; margin-bottom: 28px; letter-spacing: 1.5px;
        }
        .hero-subtitle {
          font-size: 15px; color: rgba(255,255,255,0.85); line-height: 1.85;
          max-width: 520px; margin-bottom: 14px;
        }
        .hero-desc {
          font-size: 14px; color: rgba(255,255,255,0.7); line-height: 1.7;
          max-width: 520px; margin-bottom: 28px;
        }
        .hero-buttons-wrap {
          display: inline-flex; flex-direction: column; gap: 0;
          width: fit-content; max-width: 100%;
        }
        .hero-notice {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 18px; margin-bottom: 16px;
          background: rgba(107,130,196,0.15);
          border: 1px solid rgba(107,130,196,0.3);
          border-left: 3px solid #6B82C4;
          border-radius: 4px;
          color: #fff;
          font-size: 13px; font-weight: 600; line-height: 1.5;
          width: 100%; box-sizing: border-box;
        }
        .hero-notice svg {
          flex-shrink: 0; color: #6B82C4;
        }
        .hero-buttons { display: flex; gap: 12px; flex-wrap: wrap; }

        /* Countdown — always centered */
        .hero-countdown {
          position: absolute; bottom: 44px; left: 0; right: 0;
          display: flex; justify-content: center; align-items: center;
          gap: 36px; z-index: 3; padding: 0 20px;
          box-sizing: border-box;
        }
        .hero-countdown-item { text-align: center; min-width: 0; }
        .hero-countdown-value {
          font-size: 44px; font-weight: 800; color: rgba(255,255,255,0.9);
          line-height: 1; font-variant-numeric: tabular-nums;
          letter-spacing: 2px;
        }
        .hero-countdown-label {
          font-size: 10px; color: rgba(255,255,255,0.45);
          text-transform: uppercase; letter-spacing: 2.5px;
          margin-top: 8px;
        }

        /* Tablet */
        @media (max-width: 1024px) {
          .hero-grid { padding: 110px 32px 130px; }
          .hero-title-light, .hero-title-bold { font-size: 42px; }
          .hero-globe { display: none; }
          .hero-countdown { bottom: 36px; gap: 28px; }
          .hero-countdown-value { font-size: 36px; letter-spacing: 1.5px; }
          .hero-countdown-label { font-size: 9px; letter-spacing: 2px; }
        }

        /* Small tablet / large phone */
        @media (max-width: 768px) {
          .hero-grid { padding: 100px 24px 120px; }
          .hero-title-light, .hero-title-bold { font-size: 36px; }
          .hero-subtitle { font-size: 14px; }
          .hero-desc { font-size: 13px; margin-bottom: 22px; }
          .hero-notice { font-size: 12px; padding: 10px 14px; }
          .hero-countdown { bottom: 28px; gap: 24px; }
          .hero-countdown-value { font-size: 30px; }
        }

        /* Mobile */
        @media (max-width: 600px) {
          .hero-grid { padding: 96px 20px 110px; flex-direction: column; }
          .hero-title-light, .hero-title-bold { font-size: 30px; }
          .hero-date-badge { margin-bottom: 24px; }
          .hero-date-badge span { font-size: 9px; letter-spacing: 1.5px; }
          .hero-subtitle { font-size: 13px; max-width: 100%; }
          .hero-desc { font-size: 12px; margin-bottom: 18px; max-width: 100%; }
          .hero-notice {
            font-size: 12px; padding: 10px 14px; margin-bottom: 20px;
            max-width: 100%; align-items: flex-start;
          }
          .hero-buttons { flex-direction: column; }
          .hero-countdown { bottom: 20px; gap: 16px; padding: 0 16px; }
          .hero-countdown-value { font-size: 26px; letter-spacing: 1px; }
          .hero-countdown-label { font-size: 8px; letter-spacing: 1.5px; margin-top: 6px; }
        }

        /* Very small screens */
        @media (max-width: 380px) {
          .hero-grid { padding: 90px 16px 100px; }
          .hero-title-light, .hero-title-bold { font-size: 26px; }
          .hero-notice { font-size: 11px; }
          .hero-countdown { gap: 12px; bottom: 16px; padding: 0 12px; }
          .hero-countdown-value { font-size: 22px; }
          .hero-countdown-label { font-size: 7px; letter-spacing: 1px; }
        }
      `})]})}],92349)},79356,e=>{"use strict";var t=e.i(43476),s=e.i(59095),i=e.i(21101);e.s(["default",0,function(){return(0,t.jsxs)("section",{id:"about",className:"about-section",children:[(0,t.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,t.jsx)(s.default,{children:(0,t.jsx)("div",{className:"section-label",children:"Участникам"})}),(0,t.jsx)(s.default,{delay:60,children:(0,t.jsx)("h2",{className:"section-title",children:"О конференции"})}),(0,t.jsx)(s.default,{delay:100,children:(0,t.jsx)("div",{className:"section-divider"})}),(0,t.jsx)(s.default,{delay:140,children:(0,t.jsx)("p",{className:"about-text",children:"Конференция GLP-PLANET ежегодно объединяет специалистов научно-исследовательских центров, представителей контрактных исследовательских организаций и фармацевтических компаний, разработчиков, экспертов в области биоэтики, представителей регуляторных и надзорных органов, технических специалистов и поставщиков решений, инвесторов, экспертов в области систем менеджмента качества и надлежащей лабораторной практики (GLP)."})}),(0,t.jsx)(s.default,{delay:200,children:(0,t.jsx)("p",{className:"about-text",style:{marginBottom:36},children:"Целями конференции являются распространение знаний и создание единого информационного поля в области надлежащей лабораторной практики, выработка единой стратегии в области разработки и исследований лекарственных препаратов, гуманного обращения с лабораторными животными, подготовка кадров, развитие отрасли, что будет способствовать выводу отечественных препаратов на зарубежный рынок."})}),(0,t.jsx)(s.default,{delay:260,children:(0,t.jsxs)("div",{className:"about-info-row",children:[(0,t.jsxs)("div",{className:"about-info-card",children:[(0,t.jsxs)("div",{className:"about-info-card-title",children:[(0,t.jsx)(i.IconPin,{}),"Место проведения"]}),(0,t.jsx)("div",{className:"about-info-card-text",children:"Отель «Санкт-Петербург», Пироговская набережная, д. 5/2, г. Санкт-Петербург"})]}),(0,t.jsxs)("div",{className:"about-info-card",children:[(0,t.jsxs)("div",{className:"about-info-card-title",children:[(0,t.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("path",{d:"M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"}),(0,t.jsx)("circle",{cx:"9",cy:"7",r:"4"}),(0,t.jsx)("path",{d:"M22 21v-2a4 4 0 00-3-3.87"}),(0,t.jsx)("path",{d:"M16 3.13a4 4 0 010 7.75"})]}),"Регистрация участников"]}),(0,t.jsx)("div",{className:"about-info-card-text",children:"Очное и онлайн участие — регистрация через систему Timepad. Для оплаты от юридического лица свяжитесь с Организационным комитетом. Лектор участвует без организационного взноса."})]})]})}),(0,t.jsx)(s.default,{delay:320,children:(0,t.jsxs)("div",{className:"about-btn-row",style:{marginTop:40},children:[(0,t.jsxs)("a",{href:"/schedule",target:"_blank",rel:"noopener noreferrer",className:"about-btn-outline about-btn-large about-btn-half",style:{textDecoration:"none"},children:[(0,t.jsx)(i.IconCalendar,{}),(0,t.jsx)("span",{children:"Онлайн расписание"})]}),(0,t.jsxs)("a",{href:"/docs/Programma_GLP_PLANET_VII-1.pdf",target:"_blank",rel:"noopener noreferrer",className:"about-btn-outline about-btn-large about-btn-half",style:{textDecoration:"none"},children:[(0,t.jsx)(i.IconFile,{}),(0,t.jsx)("span",{children:"Программа конференции"})]})]})})]}),(0,t.jsx)("style",{children:`
        .about-section { padding: 110px 48px; }
        .about-text { font-size: 15px; line-height: 1.9; color: #333; margin-bottom: 20px; }
        .about-info-row {
          display: grid;
          grid-template-columns: 1fr 2fr;
          gap: 16px;
        }
        .about-info-card {
          padding: 22px 24px;
          background: var(--light);
          border-radius: 4px;
          border-left: 3px solid var(--secondary);
          display: flex;
          flex-direction: column;
        }
        .about-info-card-title {
          font-weight: 600;
          margin-bottom: 8px;
          color: var(--primary);
          font-size: 13px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .about-info-card-text {
          color: #444;
          line-height: 1.6;
          font-size: 13px;
          flex: 1;
        }

        /* Базовая кнопка */
        .about-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          border: 1px solid var(--secondary, #6B82C4);
          border-radius: 4px;
          background: transparent;
          color: var(--primary, #1F2A5E);
          font-weight: 600;
          transition: all 0.2s ease;
          text-decoration: none;
          white-space: nowrap;
        }
        .about-btn-outline:hover {
          background: var(--secondary, #6B82C4);
          color: #ffffff;
        }
        .about-btn-outline:hover svg {
          color: #ffffff;
        }
        .about-btn-outline svg {
          flex-shrink: 0;
        }

        /* Увеличенная версия */
        .about-btn-large {
          padding: 16px 32px;
          font-size: 18px;
          gap: 12px;
        }
        .about-btn-large svg {
          width: 22px;
          height: 22px;
        }

        /* Растягивание на всю ширину */
        .about-btn-full {
          width: 100%;
          justify-content: center;
        }

        /* Ряд из двух кнопок */
        .about-btn-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }
        .about-btn-half {
          width: 100%;
          justify-content: center;
        }

        @media (max-width: 1024px) {
          .about-section { padding: 80px 32px; }
        }
        @media (max-width: 700px) {
          .about-info-row { grid-template-columns: 1fr; }
          .about-btn-row { grid-template-columns: 1fr; }
        }
        @media (max-width: 600px) {
          .about-section { padding: 60px 20px; }
          .about-text { font-size: 14px; line-height: 1.75; }
          .about-btn-large {
            padding: 14px 28px;
            font-size: 16px;
          }
          .about-btn-large svg {
            width: 20px;
            height: 20px;
          }
        }
      `})]})}])},79288,e=>{"use strict";var t=e.i(43476),s=e.i(59095),i=e.i(71645);let a=[{num:1,title:"GLP-инжиниринг. Строительные технологии и инженерные решения для испытательных центров, проводящих доклинические исследования",topics:["Нормативные требования и проектирование вивариев","Инженерные системы и микроклимат в вивариях","Автоматизация и диспетчеризация процессов","Деконтаминация отходов","Выбор оборудования и поставщиков","Эксплуатация и сервисное обслуживание оборудования"]},{num:2,title:"GLP практики",topics:["Опыт сертификации и инспектирования различных видов лабораторий на соответствие правилам надлежащей лабораторной практики (GLP)","Роль Спонсора в доклинических исследованиях","Цифровые технологии в доклинических исследованиях"]},{num:3,title:"Культура доклинических исследований: качество лабораторных животных. Взгляд учёного и регулятора",topics:["От SPF к LAQIS: эволюция представлений о «золотом стандарте»","Мониторинг ключевых параметров окружающей среды в вивариях и питомниках. Программа мониторинга здоровья животных","Выбор релевантного вида для исследования. Влияние патогенов на ход исследования","Управление колониями лабораторных животных","Жизненный путь лабораторных животных: из питомника в виварий","Критерии назначения фармацевтических инспекций GLP в период регистрации лекарственных препаратов"]},{num:4,title:"Репродуктивные технологии, криобанкирование половых продуктов и эмбрионов",topics:["Методы и способы оценки качества получения и сохранения половых продуктов","Программы искусственного оплодотворения и биобанкинга","Репродуктивные технологии в доклинических исследованиях","«…от эмбриона до колонии…»"]},{num:5,title:"Доклинические исследования биологических лекарственных средств",topics:["Программа доклинических исследований биологических лекарственных средств","Выбор релевантных тест-систем","Выбор и обоснование конечных точек в эксперименте","Методические аспекты оценки изучения эффективности, безопасности, фармакокинетики и биораспределения лекарственных средств"]},{num:6,title:"Экспериментальные модели и методы. Положительные контроли и релевантность тест-систем для моделирования",topics:["Практические подходы к выбору релевантной тест-системы","Выбор положительного контроля для исследования. Золотые стандарты","Выбор экспериментальной модели в соответствии с целями исследования","P-значимо? А есть ли эффект?"]},{num:7,title:"Гистология как неотъемлемая часть доклинических исследований",topics:["Методология гистологии и гистотехники","Токсикология, тератология и эмбриотоксичность","Патологическая морфология и экспериментальное моделирование заболеваний","Специализированные методы: иммуногистохимия, цитология","Анализ данных и математическое моделирование в морфологических исследованиях"]},{num:8,title:"Доклинические исследования медицинских изделий: мост между инженерным замыслом и клинической практикой",topics:["Современные требования регуляторных органов","Доклинические исследования эффективности","Доклиническая оценка безопасности"]},{num:9,title:"Нейробиология in vivo",topics:["Новые подходы к изучению работы мозга","Моделирование нейродегенеративных заболеваний и патологий ЦНС","Новые принципы в оценке поведения лабораторных животных. Поведенческие модели и методы оценки состояний","Нейропротекция и регенеративная терапия","Трансгенные животные как тест-системы для оценки эффективности в нейробиологии"]},{num:10,title:"Микробиология и клеточная технология",topics:["Доклинические исследования в лаборатории микробиологии: микроорганизмы как основополагающий фактор качественных и правдоподобных результатов. Способы хранения, восстановления и поддержания жизнеспособности культур микроорганизмов. Учёт и систематизация штаммов","Биобанкирование микроорганизмов","Особенности работы в лаборатории микробиологии: внутренний контроль качества","Микробиологические исследования in vivo и in vitro: методы и их практическое применение"]},{num:11,title:"Аналитические исследования в жизненном цикле биопрепаратов",topics:["Изучение физико-химических характеристик различных видов оригинальных и воспроизведённых биопрепаратов: ключевые показатели, аналитические методы, сложности и пути решения при разработке, валидации, серийном применении методик","Оценка активности in vitro в отношении рецепторов, мембран, клеток/культуры клеток и тканей: методы (иммуноферментный анализ, биослойная интерферометрия и др.), приёмы, поисковые исследования и применение в стандартизации и доказательстве биоаналогичности","Оценка фармакокинетики и биоаналогичности, определение активности in vivo в отношении рецепторов, маркеров в исследованиях на животных и людях, особенности изучения различных групп биопрепаратов (моноклональных антител, генотерапевтических, соматотерапевтических и др.)","Прогноз иммуногенности в исследованиях in vitro и in vivo: методы, особенности валидации методик, практическое применение"]},{num:12,title:"Ветеринарный опыт в доклинических исследованиях",topics:["Животные вне эксперимента: диагностические рутинные и уникальные процедуры","Анатомические особенности сосудов — зачем нам это нужно знать?","Поведенческие особенности различных видов животных","Молоко — будничная тема для ветеринара и диковинка в доклинических исследованиях?"]}];e.s(["default",0,function(){let[e,n]=(0,i.useState)(null);return(0,t.jsxs)("section",{id:"program",className:"program-section",children:[(0,t.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,t.jsx)(s.default,{children:(0,t.jsx)("div",{className:"section-label",children:"Программа"})}),(0,t.jsx)(s.default,{delay:60,children:(0,t.jsx)("h2",{className:"section-title",style:{marginBottom:12},children:"Тематические сессии"})}),(0,t.jsx)(s.default,{delay:90,children:(0,t.jsx)("p",{className:"program-desc",children:"Программа предстоящей конференции включает тематические сессии, мастер-классы и круглые столы. По итогам конференции выпускается коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»."})}),(0,t.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:10},children:a.map((i,a)=>{let o=e===i.num,r=i.topics.length>0;return(0,t.jsx)(s.default,{delay:100+30*a,children:(0,t.jsxs)("div",{style:{background:"var(--light)",borderRadius:4,border:o?"1px solid rgba(73,100,162,0.15)":"1px solid rgba(73,100,162,0.05)",overflow:"hidden",transition:"border-color 0.3s"},children:[(0,t.jsxs)("button",{onClick:()=>{let t;return r&&n(e===(t=i.num)?null:t)},className:"program-session-btn",children:[(0,t.jsx)("div",{className:"program-session-num",style:{background:o?"var(--primary)":"var(--secondary)"},children:i.num}),(0,t.jsxs)("div",{style:{flex:1,paddingTop:6},children:[(0,t.jsx)("h3",{className:"program-session-title",children:i.title}),i.note&&(0,t.jsx)("p",{className:"program-session-note",children:i.note})]}),r&&(0,t.jsx)("div",{style:{flexShrink:0,marginTop:8,width:20,height:20,display:"flex",alignItems:"center",justifyContent:"center",color:"var(--secondary)",transition:"transform 0.3s",transform:o?"rotate(180deg)":"rotate(0deg)"},children:(0,t.jsx)("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:(0,t.jsx)("polyline",{points:"6,9 12,15 18,9"})})})]}),o&&r&&(0,t.jsxs)("div",{className:"program-topics",style:{animation:"fadeIn 0.25s ease-out"},children:[(0,t.jsx)("div",{style:{fontSize:12,fontWeight:600,color:"var(--secondary)",textTransform:"uppercase",letterSpacing:1.5,marginBottom:14},children:"Темы для обсуждений"}),(0,t.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:10},children:i.topics.map((e,s)=>(0,t.jsxs)("div",{style:{display:"flex",gap:12,alignItems:"flex-start"},children:[(0,t.jsx)("div",{style:{width:5,height:5,borderRadius:1,background:"var(--secondary)",marginTop:7,flexShrink:0}}),(0,t.jsx)("span",{style:{color:"#3a3f4a",fontSize:14,lineHeight:1.65},children:e})]},s))})]})]})},i.num)})})]}),(0,t.jsx)("style",{children:`
        .program-section { padding: 110px 48px; background: var(--white); }
        .program-desc { font-size: 15px; color: #4a5060; line-height: 1.7; margin-bottom: 48px; max-width: 720px; }
        .program-session-btn {
          width: 100%; display: flex; gap: 18px; align-items: flex-start;
          padding: 24px 28px; background: none; border: none;
          cursor: pointer; text-align: left; font-family: 'Exo 2', sans-serif;
        }
        .program-session-num {
          display: flex; align-items: center; justify-content: center;
          min-width: 40px; height: 40px; border-radius: 3px;
          color: #fff; font-size: 15px; font-weight: 700; flex-shrink: 0; transition: background 0.3s;
        }
        .program-session-title { color: var(--primary); font-size: 15px; font-weight: 600; line-height: 1.5; margin: 0; }
        .program-session-note { font-size: 13px; color: var(--muted); margin-top: 6px; line-height: 1.5; font-style: italic; }
        .program-topics { padding: 0 28px 24px 86px; }

        @media (max-width: 1024px) {
          .program-section { padding: 80px 32px; }
        }
        @media (max-width: 600px) {
          .program-section { padding: 60px 20px; }
          .program-desc { font-size: 14px; margin-bottom: 32px; }
          .program-session-btn { padding: 18px 16px; gap: 12px; }
          .program-session-num { min-width: 32px; height: 32px; font-size: 13px; }
          .program-session-title { font-size: 14px; }
          .program-topics { padding: 0 16px 20px 56px; }
          .program-topics span { font-size: 13px; }
        }
      `})]})}])},77807,e=>{"use strict";var t=e.i(43476),s=e.i(59095),i=e.i(71645);function a({end:e,suffix:s=""}){let[n,o]=(0,i.useState)(0),r=(0,i.useRef)(null),[l,p]=(0,i.useState)(!1);return(0,i.useEffect)(()=>{let e=new IntersectionObserver(([e])=>{e.isIntersecting&&p(!0)},{threshold:.5});return r.current&&e.observe(r.current),()=>e.disconnect()},[]),(0,i.useEffect)(()=>{if(!l)return;let t=0,s=e/100,i=setInterval(()=>{(t+=s)>=e?(o(e),clearInterval(i)):o(Math.floor(t))},16);return()=>clearInterval(i)},[l,e]),(0,t.jsxs)("span",{ref:r,children:[n,s]})}let n=[{roman:"VII",l:"Конференция"},{n:12,s:"",l:"Сессий"},{n:3,s:"",l:"Дня программы"},{n:500,s:"+",l:"Участников"}];e.s(["default",0,function(){return(0,t.jsxs)("section",{className:"stats-section",children:[(0,t.jsx)("div",{style:{maxWidth:1200,margin:"0 auto"},children:(0,t.jsx)("div",{className:"stats-grid",children:n.map((e,i)=>(0,t.jsx)(s.default,{delay:60*i,children:(0,t.jsxs)("div",{style:{textAlign:"center",padding:20},children:[(0,t.jsx)("div",{className:"stats-number",children:e.roman?e.roman:(0,t.jsx)(a,{end:e.n,suffix:e.s})}),(0,t.jsx)("div",{className:"stats-label",children:e.l})]})},i))})}),(0,t.jsx)("style",{children:`
        .stats-section {
          padding: 70px 48px;
          border-top: 1px solid var(--light);
          border-bottom: 1px solid var(--light);
        }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .stats-number { font-size: 44px; font-weight: 800; color: var(--primary); line-height: 1; margin-bottom: 6px; }
        .stats-label { font-size: 11px; color: var(--muted); font-weight: 500; letter-spacing: 1.5px; text-transform: uppercase; }

        @media (max-width: 1024px) {
          .stats-section { padding: 56px 32px; }
        }
        @media (max-width: 600px) {
          .stats-section { padding: 40px 20px; }
          .stats-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
          .stats-number { font-size: 32px; }
          .stats-label { font-size: 10px; }
        }
      `})]})}],77807)}]);