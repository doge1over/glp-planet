(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,59095,e=>{"use strict";var s=e.i(43476),r=e.i(71645);let i=new Map,t=null,a={up:"translateY(40px)",left:"translateX(-40px)",right:"translateX(40px)",scale:"scale(0.96)"};e.s(["default",0,function({children:e,delay:n=0,direction:o="up"}){let p=(0,r.useRef)(null),[l,d]=(0,r.useState)(!1),m=(0,r.useCallback)(()=>d(!0),[]);return(0,r.useEffect)(()=>{let e=p.current;if(!e)return;let s=(t||(t=new IntersectionObserver(e=>{for(let s of e)if(s.isIntersecting){let e=i.get(s.target);e&&(e(),i.delete(s.target),t?.unobserve(s.target))}},{threshold:.1})),t);return i.set(e,m),s.observe(e),()=>{i.delete(e),s.unobserve(e)}},[m]),(0,s.jsx)("div",{ref:p,style:{opacity:+!!l,transform:l?"none":a[o],transition:`all 0.65s cubic-bezier(0.16, 1, 0.3, 1) ${n}ms`,willChange:l?"auto":"opacity, transform"},children:e})}])},67484,e=>{"use strict";var s=e.i(43476),r=e.i(71645),i=e.i(59095),t=e.i(57688);let a=[{label:"Генеральные спонсоры",sponsors:[{name:"FarmBioLine",img:"/images/sponsors/logo_bronzovyj_sponsor_farmbiolajn-1.png",href:"https://farmbioline.ru/",scale:1.6}],speed:28},{label:"Золотые спонсоры",sponsors:[{name:"БиоГен-Аналитика",img:"/images/sponsors/@logo.png",href:"https://bga.ru/"},{name:"БиоЛайн",img:"/images/sponsors/BL_rus_LOGO.png",href:"https://bioline.ru/"}],speed:32},{label:"Спонсоры",sponsors:[{name:"ТехноИнфо",img:"/images/sponsors/ТехноИнфо_LOGO_2024 (5).png",href:"https://technoinfo.ru/"},{name:"Группа компаний «Р-Фарм»",img:"/images/sponsors/Р-Фарм.png",href:"https://www.r-pharm.com"},{name:"LUMINON",img:"/images/sponsors/Logo-487х183.png",href:"https://luminon.ru"},{name:"LabNeo",img:"/images/sponsors/labneo.png",href:"https://labneo.ru/"},{name:"SciCat — платформа научных каталогов",img:"/images/partners/scicat.png",href:"https://sci-cat.ru/"},{name:"ООО «ФИЗЛАБПРИБОР»",img:"/images/sponsors/fizlab.png",href:"https://fizlab.ru/"},{name:"Биокад",img:"/images/sponsors/logo_BIOCAD_25_color_2.png",href:"https://biocad.ru/"},{name:"АО «НПО «ДОМ ФАРМАЦИИ»",img:"/images/sponsors/logo-vector.png",href:"https://doclinika.ru/"},{name:"ООО «ВЕТКОРМТОРГ»",img:"/images/sponsors/веткт лого.png",href:"https://vetkt.ru/"},{name:"ООО «БМТ-МММ»",img:"/images/sponsors/BMT_logo.jpg",href:"https://bmt-mmm.ru/ ",scale:1.6},{name:"BioInn Labs",img:"/images/sponsors/логотип.jpg",href:"https://bioinnlabs.ru",scale:1.2},{name:"АНО АВТех",img:"/images/sponsors/Логотип AWTECH.png",href:"https://awt.ru/product/vivariy/"},{name:"Группа компаний «ЭДВАНСД»",img:"/images/sponsors/logo_advanced.png",scale:1.4,className:"sponsor-edvansed"}],speed:35},{label:"Информационные партнёры",sponsors:[{name:"Журнал «Разработка и регистрация лекарственных средств»",img:"/images/partners/rrl.png",href:"https://www.pharmjournal.ru/jour/announcement/view/618"},{name:"Лабораторные животные",img:"/images/sponsors/laj-logo-1862x518-transparent-bg.png",href:"https://labanimalsjournal.ru/"},{name:"StereotaX",img:"/images/sponsors/STAX_LOGO_BLACK-01.png",href:"https://stereotax.info/",scale:1.6},{name:"НАИИО",img:"/images/sponsors/NAIIO_RUS_Logo1-01.png",href:"https://наиио.рф/рабочие-группы/"}],speed:38}];function n({s:e}){let r=(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("div",{className:"sponsor-slide-inner",children:(0,s.jsx)(t.default,{src:e.img,alt:e.name,width:200,height:80,style:{width:"auto",height:"auto",maxWidth:180*(e.scale??1),maxHeight:70*(e.scale??1),objectFit:"contain",transform:e.offsetY?`translateY(${e.offsetY}px)`:void 0}})}),(0,s.jsx)("div",{className:"sponsor-slide-name",children:e.name})]});return e.href?(0,s.jsx)("a",{href:e.href,target:"_blank",rel:"noopener noreferrer",className:`sponsor-slide sponsor-slide-link${e.className?` ${e.className}`:""}`,children:r}):(0,s.jsx)("div",{className:`sponsor-slide${e.className?` ${e.className}`:""}`,children:r})}function o({tier:e}){let{label:i,sponsors:t,speed:a=30}=e,p=(0,r.useRef)(null),[l,d]=(0,r.useState)(!1);(0,r.useEffect)(()=>{if(t.length<2)return void d(!1);let e=p.current;if(!e)return;let s=()=>{let s=e.clientWidth,r=window.innerWidth,i=240,a=32;r<=600?(i=170,a=20):r<=1024&&(i=200,a=32),d(t.length*i+(t.length-1)*a>s-16)};s();let r=new ResizeObserver(s);return r.observe(e),()=>r.disconnect()},[t.length]);let m=l?Array.from({length:8},()=>t).flat():t;return(0,s.jsxs)("div",{className:"tier-row",ref:p,children:[(0,s.jsxs)("div",{className:"tier-label-wrap",children:[(0,s.jsx)("div",{className:"tier-label",children:i}),(0,s.jsx)("div",{className:"tier-divider"})]}),0===t.length?(0,s.jsx)("div",{className:"tier-empty-wrap",children:(0,s.jsx)("div",{className:"tier-empty",children:"Скоро…"})}):l?(0,s.jsx)("div",{className:"tier-carousel",children:(0,s.jsx)("div",{className:"tier-track tier-track-scroll",style:{animationDuration:`${a}s`,"--count":t.length},children:m.map((e,r)=>(0,s.jsx)(n,{s:e},r))})}):(0,s.jsx)("div",{className:"tier-static-wrap",children:t.map((e,r)=>(0,s.jsx)(n,{s:e},r))})]})}e.s(["default",0,function(){return(0,s.jsxs)("section",{className:"sponsors-section",children:[(0,s.jsxs)("div",{className:"sponsors-header",children:[(0,s.jsx)(i.default,{children:(0,s.jsx)("div",{className:"section-label",children:"Спонсоры"})}),(0,s.jsx)(i.default,{delay:60,children:(0,s.jsx)("h2",{className:"section-title",style:{marginBottom:16},children:"Нас поддерживают"})}),(0,s.jsx)(i.default,{delay:100,children:(0,s.jsx)("p",{className:"sponsors-desc",children:"Мы благодарим наших партнёров и спонсоров за поддержку конференции"})})]}),(0,s.jsx)("div",{className:"tiers-wrap",children:a.map((e,r)=>(0,s.jsx)(i.default,{delay:140+80*r,children:(0,s.jsx)(o,{tier:e})},r))}),(0,s.jsx)("style",{children:`
                .sponsors-section {
                    padding: 100px 0 110px;
                    background: linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%);
                    position: relative;
                }
                .sponsors-header { max-width: 1200px; margin: 0 auto; padding: 0 48px; }
                .sponsors-section .section-label { color: #6B82C4; }
                .sponsors-section .section-title { color: #fff; }
                .sponsors-desc {
                    font-size: 15px;
                    color: rgba(255,255,255,0.4);
                    line-height: 1.7;
                    max-width: 480px;
                    margin-bottom: 56px;
                }

                .tiers-wrap {
                    display: flex;
                    flex-direction: column;
                    gap: 48px;
                }

                .tier-row { width: 100%; }

                .tier-label-wrap {
                    max-width: 1200px;
                    margin: 0 auto 20px;
                    padding: 0 48px;
                    display: flex;
                    align-items: center;
                    gap: 16px;
                }
                .tier-label {
                    font-size: 11px;
                    color: rgba(255,255,255,0.5);
                    font-weight: 600;
                    letter-spacing: 2.5px;
                    text-transform: uppercase;
                    flex-shrink: 0;
                }
                .tier-divider {
                    flex: 1;
                    height: 1px;
                    background: linear-gradient(to right, rgba(107,130,196,0.3), transparent);
                }

                .tier-empty-wrap {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 0 48px;
                    box-sizing: border-box;
                }
                .tier-empty {
                    height: 110px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: rgba(255,255,255,0.2);
                    font-size: 12px;
                    font-style: italic;
                    letter-spacing: 1px;
                    border: 1px dashed rgba(107,130,196,0.12);
                    border-radius: 6px;
                }

                .tier-static-wrap {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 16px 48px;
                    display: flex;
                    gap: 32px;
                    justify-content: center;
                    flex-wrap: wrap;
                    box-sizing: border-box;
                }

                .tier-carousel {
                    width: 100%;
                    overflow-x: hidden;
                    overflow-y: visible;
                    padding: 16px 0;
                    -webkit-mask-image: linear-gradient(to right, transparent 0%, black 6%, black 94%, transparent 100%);
                    mask-image: linear-gradient(to right, transparent 0%, black 6%, black 94%, transparent 100%);
                }

                .tier-track {
                    --slide-w: 240px;
                    --gap: 32px;
                    display: flex;
                    gap: var(--gap);
                    align-items: flex-start;
                }
                .tier-track-scroll {
                    width: max-content;
                    animation-name: sponsorScroll;
                    animation-timing-function: linear;
                    animation-iteration-count: infinite;
                    will-change: transform;
                }
                .tier-track-scroll:hover {
                    animation-play-state: paused;
                }

                @keyframes sponsorScroll {
                    from { transform: translate3d(0, 0, 0); }
                    to   { transform: translate3d(calc(-1 * var(--count) * (var(--slide-w) + var(--gap))), 0, 0); }
                }

                .sponsor-slide {
                    flex-shrink: 0;
                    width: 240px;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 16px;
                    text-decoration: none;
                }
                .sponsor-slide-inner {
                    width: 240px;
                    height: 110px;
                    background: #fff;
                    isolation: isolate;
                    border-radius: 6px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px 24px;
                    transition: all 0.4s cubic-bezier(0.33, 1, 0.68, 1);
                    border: 1px solid rgba(107,130,196,0.1);
                    overflow: hidden;
                    box-sizing: border-box;
                }
                .sponsor-slide-inner img {
                    mix-blend-mode: multiply;
                }
                .sponsor-slide:hover .sponsor-slide-inner {
                    transform: translateY(-6px);
                    box-shadow: 0 16px 40px rgba(0,0,0,0.2);
                    border-color: rgba(107,130,196,0.25);
                }
                .sponsor-slide-name {
                    font-size: 11px;
                    color: rgba(255,255,255,0.35);
                    font-weight: 500;
                    letter-spacing: 0.5px;
                    text-align: center;
                    transition: color 0.3s;
                    max-width: 240px;
                    line-height: 1.4;
                }
                .sponsor-slide:hover .sponsor-slide-name {
                    color: rgba(255,255,255,0.6);
                }

                @media (max-width: 1024px) {
                    .sponsors-section { padding: 80px 0 90px; }
                    .sponsors-header { padding: 0 32px; }
                    .sponsors-desc { margin-bottom: 44px; }
                    .tier-label-wrap { padding: 0 32px; }
                    .tier-empty-wrap { padding: 0 32px; }
                    .tier-static-wrap { padding: 16px 32px; gap: 24px; }
                    .tier-track { --slide-w: 200px; }
                    .sponsor-slide { width: 200px; }
                    .sponsor-slide-inner { width: 200px; height: 100px; padding: 18px 20px; }
                    .sponsor-slide-name { max-width: 200px; }
                    .tiers-wrap { gap: 36px; }
                }
                @media (max-width: 600px) {
                    .sponsors-section { padding: 60px 0 70px; }
                    .sponsors-header { padding: 0 20px; }
                    .sponsors-desc { font-size: 14px; margin-bottom: 36px; }
                    .tier-label-wrap { padding: 0 20px; margin-bottom: 14px; }
                    .tier-empty-wrap { padding: 0 20px; }
                    .tier-empty { height: 90px; font-size: 11px; }
                    .tier-static-wrap { padding: 16px 20px; gap: 16px; }
                    .tier-track { --slide-w: 170px; --gap: 20px; }
                    .sponsor-slide { width: 170px; }
                    .sponsor-slide-inner { width: 170px; height: 85px; padding: 16px; }
                    .sponsor-slide-inner img { max-width: 140px !important; max-height: 55px !important; }
                    .sponsor-edvansed .sponsor-slide-inner img { max-width: 165px !important; max-height: 76px !important; transform: none !important; }
                    .sponsor-slide-name { font-size: 10px; max-width: 170px; }
                    .tiers-wrap { gap: 28px; }
                    .tier-label { font-size: 10px; letter-spacing: 1.5px; }
                }
            `})]})}])}]);