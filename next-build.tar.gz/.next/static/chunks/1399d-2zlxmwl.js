(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,8341,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var i={cancelIdleCallback:function(){return o},requestIdleCallback:function(){return a}};for(var n in i)Object.defineProperty(r,n,{enumerable:!0,get:i[n]});let a="u">typeof self&&self.requestIdleCallback&&self.requestIdleCallback.bind(window)||function(e){let t=Date.now();return self.setTimeout(function(){e({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-t))}})},1)},o="u">typeof self&&self.cancelIdleCallback&&self.cancelIdleCallback.bind(window)||function(e){return clearTimeout(e)};("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},79520,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var i={default:function(){return v},handleClientScriptLoad:function(){return g},initScriptLoader:function(){return h}};for(var n in i)Object.defineProperty(r,n,{enumerable:!0,get:i[n]});let a=e.r(55682),o=e.r(90809),s=e.r(43476),l=a._(e.r(74080)),c=o._(e.r(71645)),d=e.r(42732),p=e.r(22737),x=e.r(8341),f=new Map,u=new Set,b=e=>{let{src:t,id:r,onLoad:i=()=>{},onReady:n=null,dangerouslySetInnerHTML:a,children:o="",strategy:s="afterInteractive",onError:c,stylesheets:d}=e,x=r||t;if(x&&u.has(x))return;if(f.has(t)){u.add(x),f.get(t).then(i,c);return}let b=()=>{n&&n(),u.add(x)},g=document.createElement("script"),h=new Promise((e,t)=>{g.addEventListener("load",function(t){e(),i&&i.call(this,t),b()}),g.addEventListener("error",function(e){t(e)})}).catch(function(e){c&&c(e)});a?(g.innerHTML=a.__html||"",b()):o?(g.textContent="string"==typeof o?o:Array.isArray(o)?o.join(""):"",b()):t&&(g.src=t,f.set(t,h)),(0,p.setAttributesFromProps)(g,e),"worker"===s&&g.setAttribute("type","text/partytown"),g.setAttribute("data-nscript",s),d&&(e=>{if(l.default.preinit)return e.forEach(e=>{l.default.preinit(e,{as:"style"})});if("u">typeof window){let t=document.head;e.forEach(e=>{let r=document.createElement("link");r.type="text/css",r.rel="stylesheet",r.href=e,t.appendChild(r)})}})(d),document.body.appendChild(g)};function g(e){let{strategy:t="afterInteractive"}=e;"lazyOnload"===t?window.addEventListener("load",()=>{(0,x.requestIdleCallback)(()=>b(e))}):b(e)}function h(e){e.forEach(g),[...document.querySelectorAll('[data-nscript="beforeInteractive"]'),...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(e=>{let t=e.id||e.getAttribute("src");u.add(t)})}function m(e){let{id:t,src:r="",onLoad:i=()=>{},onReady:n=null,strategy:a="afterInteractive",onError:o,stylesheets:p,...f}=e,{updateScripts:g,scripts:h,getIsSsr:m,appDir:v,nonce:y}=(0,c.useContext)(d.HeadManagerContext);y=f.nonce||y;let k=(0,c.useRef)(!1);(0,c.useEffect)(()=>{let e=t||r;k.current||(n&&e&&u.has(e)&&n(),k.current=!0)},[n,t,r]);let j=(0,c.useRef)(!1);if((0,c.useEffect)(()=>{if(!j.current){if("afterInteractive"===a)b(e);else"lazyOnload"===a&&("complete"===document.readyState?(0,x.requestIdleCallback)(()=>b(e)):window.addEventListener("load",()=>{(0,x.requestIdleCallback)(()=>b(e))}));j.current=!0}},[e,a]),("beforeInteractive"===a||"worker"===a)&&(g?(h[a]=(h[a]||[]).concat([{id:t,src:r,onLoad:i,onReady:n,onError:o,...f,nonce:y}]),g(h)):m&&m()?u.add(t||r):m&&!m()&&b({...e,nonce:y})),v){if(p&&p.forEach(e=>{l.default.preinit(e,{as:"style"})}),"beforeInteractive"===a)if(!r)return f.dangerouslySetInnerHTML&&(f.children=f.dangerouslySetInnerHTML.__html,delete f.dangerouslySetInnerHTML),(0,s.jsx)("script",{nonce:y,dangerouslySetInnerHTML:{__html:`(self.__next_s=self.__next_s||[]).push(${JSON.stringify([0,{...f,id:t}])})`}});else return l.default.preload(r,f.integrity?{as:"script",integrity:f.integrity,nonce:y,crossOrigin:f.crossOrigin}:{as:"script",nonce:y,crossOrigin:f.crossOrigin}),(0,s.jsx)("script",{nonce:y,dangerouslySetInnerHTML:{__html:`(self.__next_s=self.__next_s||[]).push(${JSON.stringify([r,{...f,id:t}])})`}});"afterInteractive"===a&&r&&l.default.preload(r,f.integrity?{as:"script",integrity:f.integrity,nonce:y,crossOrigin:f.crossOrigin}:{as:"script",nonce:y,crossOrigin:f.crossOrigin})}return null}Object.defineProperty(m,"__nextScript",{value:!0});let v=m;("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},3303,(e,t,r)=>{t.exports=e.r(79520)},90741,e=>{"use strict";var t=e.i(43476),r=e.i(71645),i=e.i(3303),n=e.i(70119),a=e.i(56691);let o=[{id:"video-1",title:"Давлианидзе Татьяна Алексеевна",description:"Массовое разведение насекомых в лаборатории: от яйца до тест-объекта в исследовании эффективности инсектицидов · младший научный сотрудник Института дезинфектологии ФБУН «ФНЦГ им. Ф.Ф. Эрисмана» Роспотребнадзора",password:"glpplanet2026",videoSrc:"/videos/SVID_20260605_054509_1.mp4"},{id:"video-2",title:"Dasha Fuentes, CENPALAB — Vaxira",description:"Conferencia Evento Rusia 2026 preclínica Vaxira · видеодоклад",password:"glpplanet2026",videoSrc:"/videos/Conferencia Evento Rusia 2026 preclínica Vaxira p.mp4"}],s="glp_unlocked_videos_v1";function l(){let[e,i]=(0,r.useState)({}),[n,a]=(0,r.useState)({}),[l,c]=(0,r.useState)({}),[d,p]=(0,r.useState)(null),[x,f]=(0,r.useState)(!1);(0,r.useEffect)(()=>{f(!0);try{let e=localStorage.getItem(s);e&&i(JSON.parse(e))}catch{}},[]);let u=t=>{if((n[t.id]||"").trim()===t.password){let r={...e,[t.id]:!0};i(r);try{localStorage.setItem(s,JSON.stringify(r))}catch{}p(null),a({...n,[t.id]:""})}else c({...l,[t.id]:!0}),setTimeout(()=>c(e=>({...e,[t.id]:!1})),1200)};return(0,t.jsxs)("section",{className:"pv-section",children:[(0,t.jsxs)("div",{className:"pv-container",children:[(0,t.jsxs)("div",{className:"pv-header",children:[(0,t.jsx)("div",{className:"pv-label",children:"Записи"}),(0,t.jsx)("h2",{className:"pv-title",children:"Видео доклады"}),(0,t.jsx)("p",{className:"pv-subtitle",children:"Для доступа к каждой записи введите пароль участника"})]}),(0,t.jsx)("div",{className:"pv-grid",children:o.map(r=>{let i=x&&!!e[r.id],o=d===r.id,s=!!l[r.id];return(0,t.jsxs)("div",{className:"pv-card",children:[(0,t.jsx)("div",{className:"pv-frame",children:i&&"presentation"===r.fileType?(0,t.jsxs)("div",{className:"pv-file",children:[(0,t.jsx)("div",{className:"pv-file-icon",children:"PPTX"}),(0,t.jsxs)("div",{className:"pv-file-actions",children:[(0,t.jsx)("a",{className:"pv-file-btn",href:r.videoSrc,target:"_blank",rel:"noreferrer",children:"Открыть презентацию"}),(0,t.jsx)("a",{className:"pv-file-link",href:r.videoSrc,download:!0,children:"Скачать файл"})]})]}):i?(0,t.jsx)("video",{src:r.videoSrc,controls:!0,controlsList:"nodownload",playsInline:!0,className:"pv-video",poster:r.thumbnail}):(0,t.jsxs)("div",{className:"pv-locked",children:[(0,t.jsx)("div",{className:"pv-locked-bg",style:r.thumbnail?{backgroundImage:`url(${r.thumbnail})`}:{}}),(0,t.jsx)("div",{className:"pv-locked-overlay"}),o?(0,t.jsxs)("div",{className:"pv-form",onClick:e=>e.stopPropagation(),children:[(0,t.jsx)("input",{type:"password",placeholder:"Пароль",value:n[r.id]||"",onChange:e=>a({...n,[r.id]:e.target.value}),onKeyDown:e=>{"Enter"===e.key&&u(r),"Escape"===e.key&&p(null)},autoFocus:!0,className:`pv-input ${s?"pv-input-error":""}`}),(0,t.jsx)("button",{type:"button",className:"pv-submit-btn",onClick:()=>u(r),children:(0,t.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),(0,t.jsx)("polyline",{points:"12,5 19,12 12,19"})]})})]}):(0,t.jsxs)("button",{type:"button",className:"pv-unlock-btn",onClick:()=>p(r.id),children:[(0,t.jsx)("div",{className:"pv-lock-icon",children:(0,t.jsxs)("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2"}),(0,t.jsx)("path",{d:"M7 11V7a5 5 0 0110 0v4"})]})}),(0,t.jsx)("span",{className:"pv-unlock-text",children:"Введите пароль"})]})]})}),(0,t.jsxs)("div",{className:"pv-info",children:[(0,t.jsx)("h3",{className:"pv-card-title",children:r.title}),r.description&&(0,t.jsx)("p",{className:"pv-card-desc",children:r.description})]})]},r.id)})})]}),(0,t.jsx)("style",{children:`
                .pv-section {
                    padding: 60px 48px 100px;
                    background: #141B4D;
                }
                .pv-container { max-width: 1240px; margin: 0 auto; }

                .pv-header { margin-bottom: 40px; }
                .pv-label {
                    font-size: 11px; color: #6B82C4; font-weight: 600;
                    text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px;
                }
                .pv-title {
                    font-size: 32px; font-weight: 700; color: #fff;
                    line-height: 1.2; margin: 0 0 12px;
                }
                .pv-subtitle {
                    font-size: 14px; color: rgba(255,255,255,0.5);
                    line-height: 1.6; max-width: 500px; margin: 0;
                }

                .pv-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 24px;
                }

                .pv-card {
                    background: rgba(8,12,36,0.4);
                    border: 1px solid rgba(107,130,196,0.15);
                    border-radius: 8px;
                    overflow: hidden;
                    transition: border-color 0.3s, transform 0.3s;
                }
                .pv-card:hover {
                    border-color: rgba(107,130,196,0.3);
                    transform: translateY(-3px);
                }

                .pv-frame {
                    position: relative;
                    width: 100%;
                    aspect-ratio: 16 / 9;
                    overflow: hidden;
                    background: #000;
                }
                .pv-video {
                    position: absolute;
                    inset: 0;
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                    background: #000;
                    display: block;
                }
                .pv-file {
                    position: absolute;
                    inset: 0;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    gap: 18px;
                    padding: 22px;
                    background:
                        radial-gradient(circle at 50% 30%, rgba(107,130,196,0.28), transparent 48%),
                        linear-gradient(135deg, #101740 0%, #1b2460 100%);
                }
                .pv-file-icon {
                    width: 78px;
                    height: 78px;
                    border-radius: 8px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: rgba(255,255,255,0.1);
                    border: 1px solid rgba(255,255,255,0.18);
                    color: #fff;
                    font-size: 15px;
                    font-weight: 700;
                    letter-spacing: 1px;
                }
                .pv-file-actions {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    flex-wrap: wrap;
                    justify-content: center;
                }
                .pv-file-btn,
                .pv-file-link {
                    min-height: 40px;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 5px;
                    font-family: 'Exo 2', sans-serif;
                    font-size: 13px;
                    font-weight: 600;
                    text-decoration: none;
                    transition: background 0.25s, border-color 0.25s;
                }
                .pv-file-btn {
                    padding: 0 18px;
                    background: var(--secondary, #4964A2);
                    color: #fff;
                }
                .pv-file-btn:hover { background: #6B82C4; }
                .pv-file-link {
                    padding: 0 14px;
                    border: 1px solid rgba(255,255,255,0.18);
                    color: rgba(255,255,255,0.76);
                    background: rgba(255,255,255,0.04);
                }
                .pv-file-link:hover {
                    border-color: rgba(255,255,255,0.34);
                    background: rgba(255,255,255,0.08);
                }

                .pv-locked {
                    position: absolute;
                    inset: 0;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .pv-locked-bg {
                    position: absolute;
                    inset: -10px;
                    background: linear-gradient(135deg, #1a2460 0%, #2a3680 50%, #141B4D 100%);
                    background-size: cover;
                    background-position: center;
                    filter: blur(14px);
                    transform: scale(1.1);
                }
                .pv-locked-overlay {
                    position: absolute;
                    inset: 0;
                    background:
                        radial-gradient(circle at center, transparent 0%, rgba(8,12,36,0.6) 100%),
                        repeating-linear-gradient(45deg, transparent 0 8px, rgba(255,255,255,0.02) 8px 9px);
                }

                .pv-unlock-btn {
                    position: relative;
                    z-index: 2;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 12px;
                    padding: 16px 28px;
                    background: rgba(8,12,36,0.65);
                    backdrop-filter: blur(10px);
                    -webkit-backdrop-filter: blur(10px);
                    border: 1px solid rgba(107,130,196,0.35);
                    border-radius: 8px;
                    color: #fff;
                    cursor: pointer;
                    font-family: 'Exo 2', sans-serif;
                    transition: all 0.3s;
                }
                .pv-unlock-btn:hover {
                    border-color: #6B82C4;
                    background: rgba(20,27,77,0.85);
                    transform: translateY(-2px);
                }
                .pv-lock-icon {
                    width: 44px; height: 44px;
                    border-radius: 50%;
                    background: rgba(107,130,196,0.18);
                    color: #6B82C4;
                    display: flex; align-items: center; justify-content: center;
                }
                .pv-unlock-text {
                    font-size: 12px;
                    font-weight: 600;
                    letter-spacing: 1.5px;
                    text-transform: uppercase;
                    color: rgba(255,255,255,0.85);
                }

                .pv-form {
                    position: relative;
                    z-index: 2;
                    display: flex;
                    gap: 6px;
                    align-items: center;
                    padding: 8px;
                    background: rgba(8,12,36,0.85);
                    backdrop-filter: blur(14px);
                    -webkit-backdrop-filter: blur(14px);
                    border: 1px solid rgba(107,130,196,0.4);
                    border-radius: 8px;
                    width: min(86%, 320px);
                }
                .pv-input {
                    flex: 1;
                    min-width: 0;
                    padding: 10px 14px;
                    background: rgba(255,255,255,0.05);
                    border: 1px solid rgba(107,130,196,0.25);
                    border-radius: 5px;
                    color: #fff;
                    font-family: 'Exo 2', sans-serif;
                    font-size: 14px;
                    outline: none;
                    transition: all 0.25s;
                }
                .pv-input:focus {
                    border-color: #6B82C4;
                    background: rgba(255,255,255,0.08);
                }
                .pv-input::placeholder {
                    color: rgba(255,255,255,0.35);
                }
                .pv-input-error {
                    border-color: #e15a5a !important;
                    animation: pvShake 0.4s;
                }
                @keyframes pvShake {
                    0%, 100% { transform: translateX(0); }
                    20%, 60% { transform: translateX(-4px); }
                    40%, 80% { transform: translateX(4px); }
                }
                .pv-submit-btn {
                    flex-shrink: 0;
                    width: 38px; height: 38px;
                    display: flex; align-items: center; justify-content: center;
                    background: var(--secondary, #4964A2);
                    border: none;
                    border-radius: 5px;
                    color: #fff;
                    cursor: pointer;
                    transition: background 0.25s;
                }
                .pv-submit-btn:hover { background: #6B82C4; }

                .pv-info {
                    padding: 18px 20px 22px;
                }
                .pv-card-title {
                    font-size: 16px;
                    font-weight: 700;
                    color: #fff;
                    margin: 0 0 6px;
                    line-height: 1.35;
                }
                .pv-card-desc {
                    font-size: 13px;
                    color: rgba(255,255,255,0.5);
                    line-height: 1.55;
                    margin: 0;
                }

                @media (max-width: 1024px) {
                    .pv-section { padding: 50px 32px 80px; }
                    .pv-title { font-size: 28px; }
                    .pv-grid { gap: 20px; }
                }
                @media (max-width: 768px) {
                    .pv-grid { grid-template-columns: 1fr 1fr; }
                }
                @media (max-width: 600px) {
                    .pv-section { padding: 36px 16px 56px; }
                    .pv-header { margin-bottom: 28px; }
                    .pv-title { font-size: 22px; }
                    .pv-subtitle { font-size: 13px; }
                    .pv-grid { grid-template-columns: 1fr; gap: 16px; }
                    .pv-info { padding: 14px 16px 18px; }
                    .pv-card-title { font-size: 15px; }
                    .pv-card-desc { font-size: 12px; }
                    .pv-unlock-btn { padding: 14px 22px; }
                    .pv-lock-icon { width: 38px; height: 38px; }
                    .pv-unlock-text { font-size: 11px; }
                }
            `})]})}let c=[{hash:"YpiOqOhG",activityId:"10741",label:"1. Зал «Санкт-Петербург»"},{hash:"QXbaznQV",activityId:"10742",label:"2. Зал «Стрельна»"},{hash:"liBQmque",activityId:"10743",label:"3. Зал «Выборг»"}],d="platform";e.s(["default",0,function(){let[e,o]=(0,r.useState)(c[0].hash),s=(0,r.useRef)(null);return(0,r.useEffect)(()=>{let t=s.current;if(!t)return;let r=c.find(t=>t.hash===e);if(!r)return;let i=`pml-iframe-container-${r.hash}-${d}`,n=`pml-iframe-${r.hash}-${d}`,a=`https://embed-cdn.mashroom.online/?hash=${r.hash}`,o=document.createElement("div");o.setAttribute("id",i),o.setAttribute("iframe-name",n),o.setAttribute("src",a),o.setAttribute("mode",d),o.setAttribute("activity-id",r.activityId),o.classList.add(`pml-container-iframe-${d}`),t.innerHTML="",t.appendChild(o);let l=null,p=()=>!!window.initIframe&&(window.initIframe(i),!0);return p()||(l=setInterval(()=>{p()&&l&&clearInterval(l)},50)),()=>{if(l&&clearInterval(l),window.destroyIframe)try{window.destroyIframe(n)}catch{}}},[e]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n.default,{}),(0,t.jsxs)("main",{className:"bc-main",children:[(0,t.jsx)("section",{className:"bc-hero",children:(0,t.jsxs)("div",{className:"bc-container",children:[(0,t.jsx)("div",{className:"bc-label",children:"Онлайн"}),(0,t.jsx)("h1",{className:"bc-title",children:"Трансляция конференции"}),(0,t.jsx)("p",{className:"bc-subtitle",children:"Прямая трансляция и записи сессий VII Международной научно-практической конференции GLP-PLANET"}),(0,t.jsxs)("a",{href:"/schedule",target:"_blank",rel:"noopener noreferrer",className:"bc-schedule-btn",children:[(0,t.jsxs)("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("rect",{x:"3",y:"4",width:"18",height:"18",rx:"2"}),(0,t.jsx)("line",{x1:"16",y1:"2",x2:"16",y2:"6"}),(0,t.jsx)("line",{x1:"8",y1:"2",x2:"8",y2:"6"}),(0,t.jsx)("line",{x1:"3",y1:"10",x2:"21",y2:"10"})]}),(0,t.jsx)("span",{children:"Онлайн расписание"})]})]})}),(0,t.jsx)("section",{className:"bc-player-section",children:(0,t.jsxs)("div",{className:"bc-container",children:[(0,t.jsx)("div",{className:"bc-player-wrap",children:(0,t.jsxs)("div",{className:"tabs",children:[(0,t.jsx)("div",{className:"tabs__controls",children:c.map(r=>(0,t.jsx)("button",{type:"button",className:`tabs__control${r.hash===e?" active":""}`,onClick:()=>o(r.hash),children:r.label},r.hash))}),(0,t.jsx)("div",{className:"tabs__content",children:(0,t.jsx)("div",{className:"bc-player-frame",children:(0,t.jsx)("div",{ref:s})})})]})}),(0,t.jsx)("div",{className:"bc-info",children:(0,t.jsxs)("div",{className:"bc-info-card",children:[(0,t.jsx)("div",{className:"bc-info-icon",children:(0,t.jsxs)("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("circle",{cx:"12",cy:"12",r:"10"}),(0,t.jsx)("line",{x1:"12",y1:"6",x2:"12",y2:"12"}),(0,t.jsx)("line",{x1:"12",y1:"12",x2:"16",y2:"14"})]})}),(0,t.jsx)("div",{className:"bc-info-text",children:"Если плеер не загружается — обновите страницу или попробуйте отключить блокировщик рекламы"})]})})]})}),(0,t.jsx)(l,{})]}),(0,t.jsx)(a.default,{}),(0,t.jsx)("link",{rel:"stylesheet",href:"https://embed-cdn.mashroom.online/iframe/css/index.css"}),(0,t.jsx)(i.default,{src:"https://embed-cdn.mashroom.online/iframe/js/index.js",strategy:"afterInteractive"}),(0,t.jsx)("style",{children:`
        .bc-main {
          min-height: 100vh;
          background: #141B4D;
        }
        .bc-container { max-width: 1240px; margin: 0 auto; }

        .bc-hero {
          padding: 140px 48px 60px;
          background: linear-gradient(155deg, #080C24 0%, #141B4D 100%);
        }
        .bc-label {
          font-size: 11px; color: #6B82C4; font-weight: 600;
          text-transform: uppercase; letter-spacing: 3px; margin-bottom: 12px;
        }
        .bc-title {
          font-size: 42px; font-weight: 700; color: #fff;
          line-height: 1.2; margin-bottom: 16px;
        }
        .bc-subtitle {
          font-size: 15px; color: rgba(255,255,255,0.6); line-height: 1.7;
          max-width: 600px;
        }
        .bc-schedule-btn {
          display: inline-flex; align-items: center; gap: 10px;
          margin-top: 24px; padding: 12px 24px;
          border: 1px solid #559CD6; border-radius: 4px;
          background: transparent; color: #fff;
          font-size: 15px; font-weight: 600; text-decoration: none;
          transition: all 0.2s ease;
        }
        .bc-schedule-btn:hover { background: #559CD6; }
        .bc-schedule-btn svg { flex-shrink: 0; color: #559CD6; transition: color 0.2s ease; }
        .bc-schedule-btn:hover svg { color: #fff; }

        .bc-player-section {
          padding: 50px 48px 100px;
          background: #141B4D;
        }

        .bc-player-wrap {
          width: 100%;
          max-width: 1240px;
          margin: 0 auto 32px;
          border-radius: 8px;
          background: #000;
          box-shadow: 0 30px 80px rgba(0,0,0,0.4);
          border: 1px solid rgba(107,130,196,0.15);
        }

        .tabs {
          --border-color: #559CD6;
          --bg-color: #FFFFFF;
          --text-color: #559CD6;
          --bg-active-color: #559CD6;
          --text-active-color: #FFFFFF;
        }
        .tabs__controls {
          display: flex;
          flex-wrap: wrap;
        }
        .tabs__control {
          position: relative;
          padding: 8px 24px;
          flex: 1 50%;
          font-size: 20px;
          line-height: 1.6;
          color: var(--text-color);
          letter-spacing: 0.9px;
          text-transform: uppercase;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          border: none;
          box-shadow: 0 0 0 1px var(--border-color);
          background-color: var(--bg-color);
          border-radius: 0;
          cursor: pointer;
          transition: background-color 0.2s ease, color 0.2s ease;
        }
        .tabs__content {
          margin-top: 1px;
          width: 100%;
        }
        .tabs__control.active {
          cursor: initial;
          color: var(--text-active-color);
          background-color: var(--bg-active-color);
        }
        @media (min-width: 1024px) {
          .tabs__control {
            flex: 1 20%;
          }
        }

        .bc-player-frame {
          width: 100%;
        }
        .bc-player-frame > div {
          width: 100%;
        }
        .bc-player-frame iframe {
          width: 100% !important;
          border: 0;
          display: block;
        }

        .bc-info {
          display: flex;
          flex-direction: column;
          gap: 12px;
          max-width: 1240px;
          margin: 0 auto;
        }
        .bc-info-card {
          display: flex;
          align-items: flex-start;
          gap: 14px;
          padding: 16px 20px;
          background: rgba(73,100,162,0.1);
          border: 1px solid rgba(107,130,196,0.18);
          border-left: 3px solid #6B82C4;
          border-radius: 4px;
        }
        .bc-info-icon {
          flex-shrink: 0;
          width: 36px; height: 36px;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          background: rgba(107,130,196,0.18);
          color: #6B82C4;
        }
        .bc-info-text {
          font-size: 13px;
          color: rgba(255,255,255,0.7);
          line-height: 1.6;
          padding-top: 7px;
        }

        @media (max-width: 1024px) {
          .bc-hero { padding: 120px 32px 48px; }
          .bc-title { font-size: 34px; }
          .bc-player-section { padding: 40px 32px 70px; }
          .tabs__control { font-size: 16px; padding: 8px 16px; }
        }
        @media (max-width: 768px) {
          .tabs__control { font-size: 14px; padding: 8px 12px; letter-spacing: 0.5px; }
        }
        @media (max-width: 600px) {
          .bc-hero { padding: 100px 20px 36px; }
          .bc-label { font-size: 10px; letter-spacing: 2px; }
          .bc-title { font-size: 26px; margin-bottom: 12px; }
          .bc-subtitle { font-size: 14px; line-height: 1.65; }
          .bc-player-section { padding: 28px 16px 56px; }
          .bc-player-wrap { border-radius: 6px; margin-bottom: 20px; }
          .bc-info-card { padding: 14px 16px; gap: 12px; }
          .bc-info-icon { width: 32px; height: 32px; }
          .bc-info-icon svg { width: 16px; height: 16px; }
          .bc-info-text { font-size: 12px; padding-top: 5px; }
          .tabs__control { font-size: 12px; padding: 6px 8px; letter-spacing: 0.3px; }
        }
      `})]})}],90741)}]);