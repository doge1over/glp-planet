(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,92349,e=>{"use strict";var t=e.i(43476),a=e.i(71645);let i=e=>e*Math.PI/180,n=[{lat:59.94,lon:30.31,label:"Санкт-Петербург",offsetX:14,offsetY:-18},{lat:55.75,lon:37.62,label:"Москва",offsetX:14,offsetY:-10},{lat:53.9,lon:27.57,label:"Беларусь",offsetX:-14,offsetY:-12},{lat:40.18,lon:44.51,label:"Армения",offsetX:14,offsetY:-10},{lat:43,lon:41.02,label:"Абхазия",offsetX:-14,offsetY:-10},{lat:41.72,lon:44.79,label:"Грузия",offsetX:14,offsetY:14},{lat:51.17,lon:71.43,label:"Казахстан",offsetX:14,offsetY:-14},{lat:41.31,lon:69.28,label:"Узбекистан",offsetX:14,offsetY:14},{lat:51.51,lon:-.13,label:"Великобритания",offsetX:-14,offsetY:-18},{lat:48.86,lon:2.35,label:"Франция",offsetX:-14,offsetY:14},{lat:52.52,lon:13.41,label:"Германия",offsetX:14,offsetY:16},{lat:50.85,lon:4.35,label:"Бельгия",offsetX:-14,offsetY:16},{lat:55.68,lon:12.57,label:"Дания",offsetX:-14,offsetY:-16},{lat:40.42,lon:-3.7,label:"Испания",offsetX:-14,offsetY:-14},{lat:41.9,lon:12.5,label:"Италия",offsetX:-14,offsetY:-10},{lat:46.95,lon:7.45,label:"Швейцария",offsetX:-14,offsetY:16},{lat:44.82,lon:20.46,label:"Сербия",offsetX:14,offsetY:12},{lat:39.9,lon:116.4,label:"Китай",offsetX:14,offsetY:-12},{lat:28.61,lon:77.21,label:"Индия",offsetX:14,offsetY:-12},{lat:38.91,lon:-77.04,label:"США",offsetX:-14,offsetY:-14},{lat:23.11,lon:-82.37,label:"Куба",offsetX:-14,offsetY:12},{lat:-33.93,lon:18.42,label:"ЮАР",offsetX:14,offsetY:14}].map(e=>({cosLat:Math.cos(i(e.lat)),sinLat:Math.sin(i(e.lat)),lonR:i(e.lon),label:e.label,offsetX:e.offsetX,offsetY:e.offsetY}));function l({size:e=440}){let o=(0,a.useRef)(null),s=(0,a.useRef)(0),r=(0,a.useRef)(0),d=(0,a.useRef)([]),c=(0,a.useRef)(!1),[p,f]=(0,a.useState)(!1);(0,a.useEffect)(()=>{let t=o.current;if(!t||c.current)return;c.current=!0;let a=window.devicePixelRatio||1;t.width=e*a,t.height=e*a,t.style.width=e+"px",t.style.height=e+"px",t.getContext("2d").setTransform(a,0,0,a,0,0)},[e]),(0,a.useEffect)(()=>{fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json").then(e=>e.json()).then(e=>{let t=function(e){let t=document.createElement("canvas");t.width=720,t.height=360;let a=t.getContext("2d");for(let t of(a.fillStyle="#000",a.fillRect(0,0,720,360),a.fillStyle="#fff",e)){a.beginPath();for(let e=0;e<t.length;e++){let i=(t[e][0]+180)/360*720,n=(90-t[e][1])/180*360;0===e?a.moveTo(i,n):a.lineTo(i,n)}a.closePath(),a.fill()}let i=a.getImageData(0,0,720,360),n=new Uint8Array(259200);for(let e=0;e<n.length;e++)n[e]=+(i.data[4*e]>128);return n}(function(e){let{scale:t,translate:a}=e.transform,i=e.arcs.map(e=>{let i=0,n=0;return e.map(([e,l])=>(i+=e,n+=l,[i*t[0]+a[0],n*t[1]+a[1]]))}),n=[],l=e.objects.land;for(let e of"GeometryCollection"===l.type?l.geometries:[l])for(let t of"MultiPolygon"===e.type?e.arcs.flat():e.arcs||[]){let e=[];for(let a of t){let t=a>=0?i[a]:[...i[~a]].reverse(),n=+(e.length>0);for(let a=n;a<t.length;a++)e.push(t[a])}e.length>2&&n.push(e)}return n}(e)),a=[];for(let e=88;e>=-88;e-=2.5){let n=i(e),l=Math.cos(n),o=Math.sin(n),s=2.5/Math.max(l,.2);for(let n=-180;n<180;n+=s){let s=Math.floor((n+180)/360*720);s>=720&&(s-=720);let r=Math.floor((90-e)/180*360),d=r>=0&&r<360&&1===t[720*r+s];a.push({cosLat:l,sinLat:o,lonR:i(n),land:d})}}d.current=a,f(!0)}).catch(()=>f(!0))},[]);let h=(0,a.useCallback)(()=>{let t=o.current;if(!t)return;let a=t.getContext("2d");if(!a)return;let i=e/2,l=e/2,c=.42*e,p=r.current,f=Math.cos(p),x=Math.sin(p);a.clearRect(0,0,e,e),a.fillStyle="rgba(50,100,200,0.04)",a.beginPath(),a.arc(i,l,1.12*c,0,2*Math.PI),a.fill(),a.strokeStyle="rgba(60,130,240,0.06)",a.lineWidth=8,a.beginPath(),a.arc(i,l,1.04*c,0,2*Math.PI),a.stroke(),a.strokeStyle="rgba(80,140,230,0.18)",a.lineWidth=1,a.beginPath(),a.arc(i,l,c,0,2*Math.PI),a.stroke(),a.strokeStyle="rgba(60,110,200,0.03)",a.lineWidth=.3;for(let e=1;e<6;e++){let t=-Math.PI/2+Math.PI*e/6,n=l-c*Math.sin(t),o=c*Math.cos(t);a.beginPath(),a.ellipse(i,n,o,.06*o,0,0,2*Math.PI),a.stroke()}for(let e=0;e<10;e++){let t=Math.abs(Math.cos(e/10*Math.PI+p));a.strokeStyle=`rgba(60,110,200,${.01+.03*t})`,a.beginPath(),a.ellipse(i,l,t*c,c,0,0,2*Math.PI),a.stroke()}let g=d.current;a.fillStyle="rgba(50,90,170,0.035)",a.beginPath();for(let e=0;e<g.length;e++){let t=g[e],n=Math.sin(t.lonR)*f+Math.cos(t.lonR)*x,o=Math.cos(t.lonR)*f-Math.sin(t.lonR)*x;if(t.cosLat*o<.02||t.land)continue;let s=i+c*t.cosLat*n,r=l-c*t.sinLat;a.rect(s-.35,r-.35,.7,.7)}for(let[e,t,n,o]of(a.fill(),[[.02,.3,"rgba(90,165,250,0.22)",1.2],[.3,.6,"rgba(100,175,255,0.42)",1.5],[.6,1.1,"rgba(120,190,255,0.62)",1.8]])){a.fillStyle=n.replace(/[\d.]+\)$/,`${o>1.5?.1:.06})`),a.beginPath();for(let n=0;n<g.length;n++){let s=g[n];if(!s.land)continue;let r=Math.sin(s.lonR)*f+Math.cos(s.lonR)*x,d=Math.cos(s.lonR)*f-Math.sin(s.lonR)*x,p=s.cosLat*d;if(p<e||p>=t)continue;let h=i+c*s.cosLat*r,m=l-c*s.sinLat,u=o+1.5;a.rect(h-u/2,m-u/2,u,u)}a.fill(),a.fillStyle=n,a.beginPath();for(let n=0;n<g.length;n++){let s=g[n];if(!s.land)continue;let r=Math.sin(s.lonR)*f+Math.cos(s.lonR)*x,d=Math.cos(s.lonR)*f-Math.sin(s.lonR)*x,p=s.cosLat*d;if(p<e||p>=t)continue;let h=i+c*s.cosLat*r,m=l-c*s.sinLat;a.rect(h-o/2,m-o/2,o,o)}a.fill()}let m=(Math.sin(3*p)+1)*.5,u=[];for(let e=0;e<n.length;e++){let t=n[e],a=Math.sin(t.lonR)*f+Math.cos(t.lonR)*x,o=Math.cos(t.lonR)*f-Math.sin(t.lonR)*x,s=t.cosLat*o;if(s<.15)continue;let r=i+c*t.cosLat*a,d=l-c*t.sinLat,p=.3+.7*s;u.push({m:t,px:r,py:d,z:s,alpha:p})}u.sort((e,t)=>t.z-e.z);let b=[];for(let{m:t,px:i,py:n,alpha:l}of(a.font="500 8px 'Exo 2', sans-serif",u)){a.fillStyle=`rgba(190,225,255,${.08*l})`,a.beginPath(),a.arc(i,n,8+3*m,0,2*Math.PI),a.fill(),a.fillStyle=`rgba(210,235,255,${.85*l})`,a.beginPath(),a.arc(i,n,2.2+.3*m,0,2*Math.PI),a.fill(),a.fillStyle=`rgba(240,250,255,${.7*l})`,a.beginPath(),a.arc(i,n,.9,0,2*Math.PI),a.fill();let o=t.offsetX>0?1:-1,s=t.offsetY>0?1:-1,r=i+22*o,d=n+s*Math.abs(t.offsetY/t.offsetX)*22,c=r+15*o,p=a.measureText(t.label).width,f=o>0?c-3:c-p-3,h=o>0?c+p+3:c+3,x=d-14,g=d+3,u=s;for(let t=0;t<12;t++){let t=!1;for(let e of b)if(f<e.x2&&h>e.x1&&x<e.y2&&g>e.y1){t=!0;break}if(!t)break;x<8&&u<0&&(u=1),g>e-8&&u>0&&(u=-1);let a=16*u;d+=a,x+=a,g+=a}if(x<4){let e=4-x;d+=e,x+=e,g+=e}if(g>e-4){let t=g-(e-4);d-=t,x-=t,g-=t}b.push({x1:f,y1:x,x2:h,y2:g}),a.strokeStyle=`rgba(160,210,255,${.25*l})`,a.lineWidth=.6,a.beginPath(),a.moveTo(i,n),a.lineTo(r,d),a.stroke(),a.beginPath(),a.moveTo(r,d),a.lineTo(r+12*o,d),a.stroke(),a.fillStyle=`rgba(255,255,255,${.75*l})`,a.textBaseline="bottom",a.textAlign=o>0?"left":"right",a.fillText(t.label,c,d-1)}r.current+=.0015,s.current=requestAnimationFrame(h)},[e]);return(0,a.useEffect)(()=>{if(p)return s.current=requestAnimationFrame(h),()=>cancelAnimationFrame(s.current)},[h,p]),(0,t.jsx)("canvas",{ref:o,style:{width:e,height:e,opacity:+!!p,transition:"opacity 0.5s"}})}var o=e.i(21101);let s=new Date("2026-07-01T09:00:00+03:00").getTime();e.s(["default",0,function(){let e=function(){let[e,t]=(0,a.useState)(!1),[i,n]=(0,a.useState)(s);(0,a.useEffect)(()=>{t(!0),n(Date.now());let e=setInterval(()=>n(Date.now()),1e3);return()=>clearInterval(e)},[]);let l=e?Math.max(0,s-i):0;return{days:Math.floor(l/864e5),hours:Math.floor(l%864e5/36e5),minutes:Math.floor(l%36e5/6e4),seconds:Math.floor(l%6e4/1e3)}}();return(0,t.jsxs)("section",{style:{position:"relative",minHeight:"100vh",display:"flex",alignItems:"center",background:"linear-gradient(155deg, #080C24 0%, #141B4D 45%, #192258 100%)",overflow:"hidden"},children:[(0,t.jsx)("div",{className:"grid-pattern",style:{position:"absolute",inset:0,pointerEvents:"none"}}),(0,t.jsxs)("div",{className:"hero-grid",children:[(0,t.jsxs)("div",{style:{flex:"1 1 52%",minWidth:0},children:[(0,t.jsxs)("div",{className:"hero-date-badge",style:{animation:"fadeUp 0.6s ease-out"},children:[(0,t.jsx)("div",{style:{width:5,height:5,borderRadius:1,background:"#6B82C4"}}),(0,t.jsx)("span",{children:"01 — 03 июля 2026 · Санкт-Петербург"})]}),(0,t.jsx)("h1",{className:"hero-title-light",style:{animation:"fadeUp 0.65s ease-out 0.08s both"},children:"Конференция"}),(0,t.jsxs)("h1",{className:"hero-title-bold",style:{animation:"fadeUp 0.65s ease-out 0.16s both"},children:["GLP-PLANET ",(0,t.jsx)("span",{style:{fontWeight:300,color:"#fff"},children:"VII"})]}),(0,t.jsx)("p",{className:"hero-subtitle",style:{animation:"fadeUp 0.65s ease-out 0.24s both"},children:"Совместно с Русской ассоциацией специалистов по лабораторным животным Rus-LASA"}),(0,t.jsx)("p",{className:"hero-desc",style:{animation:"fadeUp 0.65s ease-out 0.28s both"},children:"10 тематических сессий, мастер-классы и круглые столы. Очное и онлайн участие."}),(0,t.jsxs)("div",{className:"hero-buttons",style:{animation:"fadeUp 0.65s ease-out 0.32s both"},children:[(0,t.jsxs)("a",{href:"/registration",className:"btn-primary",style:{textDecoration:"none"},children:[(0,t.jsx)("span",{children:"Регистрация"}),(0,t.jsx)(o.IconArrow,{})]}),(0,t.jsxs)("a",{href:"/docs/info-letter-2026.pdf",target:"_blank",rel:"noopener noreferrer",className:"btn-outline",style:{textDecoration:"none"},children:[(0,t.jsx)(o.IconFile,{}),(0,t.jsx)("span",{children:"Информационное письмо"})]})]})]}),(0,t.jsx)("div",{className:"hero-globe",style:{flex:"0 0 auto",position:"relative",animation:"fadeIn 1.2s ease-out 0.5s both"},children:(0,t.jsx)(l,{size:440})})]}),(0,t.jsx)("div",{className:"hero-countdown",style:{animation:"fadeUp 0.8s ease-out 0.5s both"},children:[{value:e.days,label:"дней"},{value:e.hours,label:"часов"},{value:e.minutes,label:"минут"},{value:e.seconds,label:"секунд"}].map((e,a)=>(0,t.jsxs)("div",{className:"hero-countdown-item",children:[(0,t.jsx)("div",{className:"hero-countdown-value",children:String(e.value).padStart(2,"0")}),(0,t.jsx)("div",{className:"hero-countdown-label",children:e.label})]},a))}),(0,t.jsx)("style",{children:`
        .hero-grid {
          max-width: 1240px; margin: 0 auto; padding: 120px 48px 140px;
          position: relative; z-index: 2; width: 100%;
          display: flex; align-items: center; justify-content: space-between; gap: 24px;
        }
        .hero-date-badge {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 7px 18px; border: 1px solid rgba(107,130,196,0.2);
          border-radius: 2px; margin-bottom: 32px;
        }
        .hero-date-badge span {
          color: rgba(255,255,255,0.75); font-size: 11px; font-weight: 500;
          letter-spacing: 2.5px; text-transform: uppercase;
        }
        .hero-title-light {
          font-size: 52px; font-weight: 300; color: #fff;
          line-height: 1.12; margin-bottom: 4px; letter-spacing: -0.5px;
        }
        .hero-title-bold {
          font-size: 52px; font-weight: 800; color: #fff;
          line-height: 1.12; margin-bottom: 28px; letter-spacing: 1.5px;
        }
        .hero-subtitle {
          font-size: 15px; color: rgba(255,255,255,0.85); line-height: 1.85;
          max-width: 520px; margin-bottom: 14px;
        }
        .hero-desc {
          font-size: 14px; color: rgba(255,255,255,0.7); line-height: 1.7;
          max-width: 520px; margin-bottom: 40px;
        }
        .hero-buttons { display: flex; gap: 12px; flex-wrap: wrap; }

        /* Countdown — always centered */
        .hero-countdown {
          position: absolute; bottom: 44px; left: 0; right: 0;
          display: flex; justify-content: center; align-items: center;
          gap: 36px; z-index: 3; padding: 0 20px;
          box-sizing: border-box;
        }
        .hero-countdown-item { text-align: center; min-width: 0; }
        .hero-countdown-value {
          font-size: 44px; font-weight: 800; color: rgba(255,255,255,0.9);
          line-height: 1; font-variant-numeric: tabular-nums;
          letter-spacing: 2px;
        }
        .hero-countdown-label {
          font-size: 10px; color: rgba(255,255,255,0.45);
          text-transform: uppercase; letter-spacing: 2.5px;
          margin-top: 8px;
        }

        /* Tablet */
        @media (max-width: 1024px) {
          .hero-grid { padding: 110px 32px 130px; }
          .hero-title-light, .hero-title-bold { font-size: 42px; }
          .hero-globe { display: none; }
          .hero-countdown { bottom: 36px; gap: 28px; }
          .hero-countdown-value { font-size: 36px; letter-spacing: 1.5px; }
          .hero-countdown-label { font-size: 9px; letter-spacing: 2px; }
        }

        /* Small tablet / large phone */
        @media (max-width: 768px) {
          .hero-grid { padding: 100px 24px 120px; }
          .hero-title-light, .hero-title-bold { font-size: 36px; }
          .hero-subtitle { font-size: 14px; }
          .hero-desc { font-size: 13px; margin-bottom: 32px; }
          .hero-countdown { bottom: 28px; gap: 24px; }
          .hero-countdown-value { font-size: 30px; }
        }

        /* Mobile */
        @media (max-width: 600px) {
          .hero-grid { padding: 96px 20px 110px; flex-direction: column; }
          .hero-title-light, .hero-title-bold { font-size: 30px; }
          .hero-date-badge { margin-bottom: 24px; }
          .hero-date-badge span { font-size: 9px; letter-spacing: 1.5px; }
          .hero-subtitle { font-size: 13px; max-width: 100%; }
          .hero-desc { font-size: 12px; margin-bottom: 28px; max-width: 100%; }
          .hero-buttons { flex-direction: column; }
          .hero-countdown { bottom: 20px; gap: 16px; padding: 0 16px; }
          .hero-countdown-value { font-size: 26px; letter-spacing: 1px; }
          .hero-countdown-label { font-size: 8px; letter-spacing: 1.5px; margin-top: 6px; }
        }

        /* Very small screens */
        @media (max-width: 380px) {
          .hero-grid { padding: 90px 16px 100px; }
          .hero-title-light, .hero-title-bold { font-size: 26px; }
          .hero-countdown { gap: 12px; bottom: 16px; padding: 0 12px; }
          .hero-countdown-value { font-size: 22px; }
          .hero-countdown-label { font-size: 7px; letter-spacing: 1px; }
        }
      `})]})}],92349)},59095,e=>{"use strict";var t=e.i(43476),a=e.i(71645);let i=new Map,n=null,l={up:"translateY(40px)",left:"translateX(-40px)",right:"translateX(40px)",scale:"scale(0.96)"};e.s(["default",0,function({children:e,delay:o=0,direction:s="up"}){let r=(0,a.useRef)(null),[d,c]=(0,a.useState)(!1),p=(0,a.useCallback)(()=>c(!0),[]);return(0,a.useEffect)(()=>{let e=r.current;if(!e)return;let t=(n||(n=new IntersectionObserver(e=>{for(let t of e)if(t.isIntersecting){let e=i.get(t.target);e&&(e(),i.delete(t.target),n?.unobserve(t.target))}},{threshold:.1})),n);return i.set(e,p),t.observe(e),()=>{i.delete(e),t.unobserve(e)}},[p]),(0,t.jsx)("div",{ref:r,style:{opacity:+!!d,transform:d?"none":l[s],transition:`all 0.65s cubic-bezier(0.16, 1, 0.3, 1) ${o}ms`,willChange:d?"auto":"opacity, transform"},children:e})}])},79356,e=>{"use strict";var t=e.i(43476),a=e.i(59095),i=e.i(21101);e.s(["default",0,function(){return(0,t.jsxs)("section",{id:"about",className:"about-section",children:[(0,t.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,t.jsx)(a.default,{children:(0,t.jsx)("div",{className:"section-label",children:"Участникам"})}),(0,t.jsx)(a.default,{delay:60,children:(0,t.jsx)("h2",{className:"section-title",children:"О конференции"})}),(0,t.jsx)(a.default,{delay:100,children:(0,t.jsx)("div",{className:"section-divider"})}),(0,t.jsx)(a.default,{delay:140,children:(0,t.jsx)("p",{className:"about-text",children:"Конференция GLP-PLANET ежегодно объединяет специалистов научно-исследовательских центров, представителей контрактных исследовательских организаций и фармацевтических компаний, разработчиков, экспертов в области биоэтики, представителей регуляторных и надзорных органов, технических специалистов и поставщиков решений, инвесторов, экспертов в области систем менеджмента качества и надлежащей лабораторной практики (GLP)."})}),(0,t.jsx)(a.default,{delay:200,children:(0,t.jsx)("p",{className:"about-text",style:{marginBottom:36},children:"Целями конференции являются распространение знаний и создание единого информационного поля в области надлежащей лабораторной практики, выработка единой стратегии в области разработки и исследований лекарственных препаратов, гуманного обращения с лабораторными животными, подготовка кадров, развитие отрасли, что будет способствовать выводу отечественных препаратов на зарубежный рынок."})}),(0,t.jsx)(a.default,{delay:260,children:(0,t.jsxs)("div",{className:"about-info-row",children:[(0,t.jsxs)("div",{className:"about-info-card",children:[(0,t.jsxs)("div",{className:"about-info-card-title",children:[(0,t.jsx)(i.IconPin,{}),"Место проведения"]}),(0,t.jsx)("div",{className:"about-info-card-text",children:"Отель «Санкт-Петербург», Пироговская набережная, д. 5/2, г. Санкт-Петербург"})]}),(0,t.jsxs)("div",{className:"about-info-card",children:[(0,t.jsxs)("div",{className:"about-info-card-title",children:[(0,t.jsxs)("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,t.jsx)("path",{d:"M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"}),(0,t.jsx)("circle",{cx:"9",cy:"7",r:"4"}),(0,t.jsx)("path",{d:"M22 21v-2a4 4 0 00-3-3.87"}),(0,t.jsx)("path",{d:"M16 3.13a4 4 0 010 7.75"})]}),"Регистрация участников"]}),(0,t.jsx)("div",{className:"about-info-card-text",children:"Очное и онлайн участие — регистрация через систему Timepad. Для оплаты от юридического лица свяжитесь с Организационным комитетом. Лектор участвует без организационного взноса."})]})]})})]}),(0,t.jsx)("style",{children:`
                .about-section { padding: 110px 48px; }
                .about-text { font-size: 15px; line-height: 1.9; color: #333; margin-bottom: 20px; }
                .about-info-row {
                    display: grid;
                    grid-template-columns: 1fr 2fr;
                    gap: 16px;
                }
                .about-info-card {
                    padding: 22px 24px;
                    background: var(--light);
                    border-radius: 4px;
                    border-left: 3px solid var(--secondary);
                    display: flex;
                    flex-direction: column;
                }
                .about-info-card-title {
                    font-weight: 600;
                    margin-bottom: 8px;
                    color: var(--primary);
                    font-size: 13px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .about-info-card-text {
                    color: #444;
                    line-height: 1.6;
                    font-size: 13px;
                    flex: 1;
                }
                @media (max-width: 1024px) {
                    .about-section { padding: 80px 32px; }
                }
                @media (max-width: 700px) {
                    .about-info-row { grid-template-columns: 1fr; }
                }
                @media (max-width: 600px) {
                    .about-section { padding: 60px 20px; }
                    .about-text { font-size: 14px; line-height: 1.75; }
                }
            `})]})}])},79288,e=>{"use strict";var t=e.i(43476),a=e.i(59095),i=e.i(71645);let n=[{num:1,title:"GLP-инжиниринг. Строительные технологии и инженерные решения для испытательных центров, проводящих доклинические исследования",topics:["Вентиляционное оборудование, от подбора до обслуживания","Проектирование и строительство вивария","Эксплуатация технического оборудования","Структурированные кабельные системы. Автоматизация и обслуживание","Управление отходами вивария"]},{num:2,title:"Аналитические исследования в жизненном цикле биопрепаратов",topics:["Изучение физико-химических характеристик различных видов оригинальных и воспроизведенных биопрепаратов: ключевые показатели, аналитические методы, сложности и пути решения при разработке, валидации, серийном применении методик","Оценка активности in vitro в отношении рецепторов, мембран, клеток/культуры клеток и тканей: методы (иммуноферментный анализ, биослойная интерферометрия), приемы, поисковые исследования и применение в стандартизации и доказательстве биоаналогичности","Оценка фармакокинетики и биоаналогичности, определение активности in vivo в отношении рецепторов, маркеров в исследованиях на животных и людях, особенности изучения различных групп биопрепаратов (моноклональных антител, генотерапевтических, соматотерапевтических)","Прогноз иммуногенности в исследованиях in vitro и in vivo: методы, особенности валидации методик, практическое применение"]},{num:3,title:"Репродуктивные технологии, криобанкирование половых продуктов и эмбрионов",topics:["Методы и способы оценки качества получения и сохранения половых продуктов","Программы искусственного оплодотворения и биобанкинга","Репродуктивные технологии в доклинических исследованиях"]},{num:4,title:"Экспериментальные модели и методы. Положительные контроли и релевантность тест-систем для моделирования",topics:["Практические подходы к выбору релевантной тест-системы","Выбор положительного контроля для исследования. Золотые стандарты","Выбор экспериментальной модели в соответствии с целями исследования","P-значимо? А смысл?"]},{num:5,title:"Доклинические исследования медицинских изделий: мост между инженерным замыслом и клинической практикой",topics:["Современные требования регуляторных органов","Доклинические исследования эффективности","Доклиническая оценка безопасности"]},{num:6,title:"Микробиология в доклинических исследованиях",topics:["Доклинические исследования в лаборатории микробиологии: микроорганизмы как основополагающий фактор качественных и правдоподобных результатов. Способы хранения, восстановления и поддержания жизнеспособности культур микроорганизмов. Учет и систематизация штаммов","Биобанкирование микроорганизмов","Особенности работы в лаборатории микробиологии: внутренний контроль качества","Микробиологические исследования in vivo и in vitro: методы и их практическое применение"]},{num:7,title:"Доклинические исследования биологических лекарственных средств",topics:["Применение риск-ориентированного подхода при обосновании программы исследований","Выбор и обоснование конечных точек в эксперименте","Методические аспекты оценки изучения эффективности, безопасности, фармакокинетики и биораспределения лекарственных средств","Доклинические аспекты фармацевтической разработки","Выбор релевантных тест-систем"],note:"Сессия делится на тематические блоки: биотехнологические ЛП, высокотехнологичные ЛП, иммунобиологические ЛП для человека и животных"},{num:8,title:"Гистология как неотъемлемая часть доклинических исследований",topics:["Воспроизводимость гистологических данных в доклинических исследованиях","Корреляция гистологии с другими типами данных","Кросс-реактивность гистологии с другими типами данных","Вызовы преаналитики и новые технологические решения в гистологии","Анализ и интерпретация данных: особенности в доклинических исследованиях и современные решения"]},{num:9,title:"Культура доклинических исследований: качество лабораторных животных",topics:["От SPF к LAQIS: эволюция представлений о «золотом стандарте»","Санитарные мероприятия в питомниках и вивариях","Мониторинг ключевых параметров окружающей среды в вивариях и питомниках испытательных центров. Программа мониторинга здоровья животных","Качество манипуляций — основа надежных данных исследования. Принцип «не навреди» в доклинических исследованиях","Ведение колоний","Генотипирование","Вопросы терапии колоний. Эвтаназировать нельзя лечить: где ставить запятую?","Влияние патогенов на ход исследования"]},{num:10,title:"Ярмарка выпускных квалификационных работ (сессия для студентов старших курсов и магистров)",topics:[]}];e.s(["default",0,function(){let[e,l]=(0,i.useState)(null);return(0,t.jsxs)("section",{id:"program",className:"program-section",children:[(0,t.jsxs)("div",{style:{maxWidth:1e3,margin:"0 auto"},children:[(0,t.jsx)(a.default,{children:(0,t.jsx)("div",{className:"section-label",children:"Программа"})}),(0,t.jsx)(a.default,{delay:60,children:(0,t.jsx)("h2",{className:"section-title",style:{marginBottom:12},children:"Тематические сессии"})}),(0,t.jsx)(a.default,{delay:90,children:(0,t.jsx)("p",{className:"program-desc",children:"Программа предстоящей конференции включает тематические сессии, мастер-классы и круглые столы. По итогам конференции выпускается коллективная монография «Консультант GLP-PLANET. Мнение фармацевтической отрасли»."})}),(0,t.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:10},children:n.map((i,n)=>{let o=e===i.num,s=i.topics.length>0;return(0,t.jsx)(a.default,{delay:100+30*n,children:(0,t.jsxs)("div",{style:{background:"var(--light)",borderRadius:4,border:o?"1px solid rgba(73,100,162,0.15)":"1px solid rgba(73,100,162,0.05)",overflow:"hidden",transition:"border-color 0.3s"},children:[(0,t.jsxs)("button",{onClick:()=>{let t;return s&&l(e===(t=i.num)?null:t)},className:"program-session-btn",children:[(0,t.jsx)("div",{className:"program-session-num",style:{background:o?"var(--primary)":"var(--secondary)"},children:i.num}),(0,t.jsxs)("div",{style:{flex:1,paddingTop:6},children:[(0,t.jsx)("h3",{className:"program-session-title",children:i.title}),i.note&&(0,t.jsx)("p",{className:"program-session-note",children:i.note})]}),s&&(0,t.jsx)("div",{style:{flexShrink:0,marginTop:8,width:20,height:20,display:"flex",alignItems:"center",justifyContent:"center",color:"var(--secondary)",transition:"transform 0.3s",transform:o?"rotate(180deg)":"rotate(0deg)"},children:(0,t.jsx)("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:(0,t.jsx)("polyline",{points:"6,9 12,15 18,9"})})})]}),o&&s&&(0,t.jsxs)("div",{className:"program-topics",style:{animation:"fadeIn 0.25s ease-out"},children:[(0,t.jsx)("div",{style:{fontSize:12,fontWeight:600,color:"var(--secondary)",textTransform:"uppercase",letterSpacing:1.5,marginBottom:14},children:"Темы для обсуждений"}),(0,t.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:10},children:i.topics.map((e,a)=>(0,t.jsxs)("div",{style:{display:"flex",gap:12,alignItems:"flex-start"},children:[(0,t.jsx)("div",{style:{width:5,height:5,borderRadius:1,background:"var(--secondary)",marginTop:7,flexShrink:0}}),(0,t.jsx)("span",{style:{color:"#3a3f4a",fontSize:14,lineHeight:1.65},children:e})]},a))})]})]})},i.num)})})]}),(0,t.jsx)("style",{children:`
        .program-section { padding: 110px 48px; background: var(--white); }
        .program-desc { font-size: 15px; color: #4a5060; line-height: 1.7; margin-bottom: 48px; max-width: 720px; }
        .program-session-btn {
          width: 100%; display: flex; gap: 18px; align-items: flex-start;
          padding: 24px 28px; background: none; border: none;
          cursor: pointer; text-align: left; font-family: 'Exo 2', sans-serif;
        }
        .program-session-num {
          display: flex; align-items: center; justify-content: center;
          min-width: 40px; height: 40px; border-radius: 3px;
          color: #fff; font-size: 15px; font-weight: 700; flex-shrink: 0; transition: background 0.3s;
        }
        .program-session-title { color: var(--primary); font-size: 15px; font-weight: 600; line-height: 1.5; margin: 0; }
        .program-session-note { font-size: 13px; color: var(--muted); margin-top: 6px; line-height: 1.5; font-style: italic; }
        .program-topics { padding: 0 28px 24px 86px; }

        @media (max-width: 1024px) {
          .program-section { padding: 80px 32px; }
        }
        @media (max-width: 600px) {
          .program-section { padding: 60px 20px; }
          .program-desc { font-size: 14px; margin-bottom: 32px; }
          .program-session-btn { padding: 18px 16px; gap: 12px; }
          .program-session-num { min-width: 32px; height: 32px; font-size: 13px; }
          .program-session-title { font-size: 14px; }
          .program-topics { padding: 0 16px 20px 56px; }
          .program-topics span { font-size: 13px; }
        }
      `})]})}])},77807,e=>{"use strict";var t=e.i(43476),a=e.i(59095),i=e.i(71645);function n({end:e,suffix:a=""}){let[l,o]=(0,i.useState)(0),s=(0,i.useRef)(null),[r,d]=(0,i.useState)(!1);return(0,i.useEffect)(()=>{let e=new IntersectionObserver(([e])=>{e.isIntersecting&&d(!0)},{threshold:.5});return s.current&&e.observe(s.current),()=>e.disconnect()},[]),(0,i.useEffect)(()=>{if(!r)return;let t=0,a=e/100,i=setInterval(()=>{(t+=a)>=e?(o(e),clearInterval(i)):o(Math.floor(t))},16);return()=>clearInterval(i)},[r,e]),(0,t.jsxs)("span",{ref:s,children:[l,a]})}let l=[{roman:"VII",l:"Конференция"},{n:10,s:"",l:"Сессий"},{n:3,s:"",l:"Дня программы"},{n:500,s:"+",l:"Участников"}];e.s(["default",0,function(){return(0,t.jsxs)("section",{className:"stats-section",children:[(0,t.jsx)("div",{style:{maxWidth:1200,margin:"0 auto"},children:(0,t.jsx)("div",{className:"stats-grid",children:l.map((e,i)=>(0,t.jsx)(a.default,{delay:60*i,children:(0,t.jsxs)("div",{style:{textAlign:"center",padding:20},children:[(0,t.jsx)("div",{className:"stats-number",children:e.roman?e.roman:(0,t.jsx)(n,{end:e.n,suffix:e.s})}),(0,t.jsx)("div",{className:"stats-label",children:e.l})]})},i))})}),(0,t.jsx)("style",{children:`
        .stats-section {
          padding: 70px 48px;
          border-top: 1px solid var(--light);
          border-bottom: 1px solid var(--light);
        }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .stats-number { font-size: 44px; font-weight: 800; color: var(--primary); line-height: 1; margin-bottom: 6px; }
        .stats-label { font-size: 11px; color: var(--muted); font-weight: 500; letter-spacing: 1.5px; text-transform: uppercase; }

        @media (max-width: 1024px) {
          .stats-section { padding: 56px 32px; }
        }
        @media (max-width: 600px) {
          .stats-section { padding: 40px 20px; }
          .stats-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
          .stats-number { font-size: 32px; }
          .stats-label { font-size: 10px; }
        }
      `})]})}],77807)},84468,e=>{"use strict";var t=e.i(43476),a=e.i(59095),i=e.i(57688);let n=[{name:"Журнал «Разработка и регистрация лекарственных средств»",img:"/images/partners/rrl.png",href:"https://www.pharmjournal.ru/jour/announcement/view/618"},{name:"Laboratory Animals Journal",img:"/images/partners/laj.png",href:null},{name:"SciCat — платформа научных каталогов",img:"/images/partners/scicat.png",href:"https://sci-cat.ru/"}];function l({p:e}){let a=(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(i.default,{src:e.img,alt:e.name,width:200,height:80,className:"partner-logo",style:{width:"auto",height:"auto",maxWidth:200,maxHeight:80,objectFit:"contain"}}),(0,t.jsx)("div",{className:"partner-name",children:e.name})]});return e.href?(0,t.jsx)("a",{href:e.href,target:"_blank",rel:"noopener noreferrer",className:"partner-card",children:a}):(0,t.jsx)("div",{className:"partner-card",children:a})}e.s(["default",0,function(){return(0,t.jsxs)("section",{className:"partners-section",children:[(0,t.jsxs)("div",{style:{maxWidth:1200,margin:"0 auto"},children:[(0,t.jsx)(a.default,{children:(0,t.jsx)("div",{className:"section-label",children:"Партнёры"})}),(0,t.jsx)(a.default,{delay:60,children:(0,t.jsx)("h2",{className:"section-title",style:{marginBottom:44},children:"Сотрудничество"})}),(0,t.jsx)("div",{className:"partners-grid",children:n.map((e,i)=>(0,t.jsx)(a.default,{delay:120+80*i,direction:"scale",children:(0,t.jsx)(l,{p:e})},i))})]}),(0,t.jsx)("style",{children:`
        .partners-section { padding: 110px 48px; background: var(--white); }
        .partners-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .partner-card {
          display: flex; flex-direction: column; align-items: center; justify-content: center;
          padding: 40px 32px 28px; background: var(--light); border-radius: 4px;
          border: 1px solid rgba(73,100,162,0.06); text-decoration: none; text-align: center;
          transition: all 0.5s cubic-bezier(0.33, 1, 0.68, 1); min-height: 200px;
        }
        .partner-card:hover {
          transform: translateY(-5px); box-shadow: 0 20px 44px rgba(20,27,77,0.08);
          border-color: rgba(73,100,162,0.12);
        }
        .partner-logo { margin-bottom: 20px; transition: opacity 0.4s; }
        .partner-card:hover .partner-logo { opacity: 0.85; }
        .partner-name { font-size: 13px; font-weight: 600; color: var(--primary); line-height: 1.5; }

        @media (max-width: 1024px) {
          .partners-section { padding: 80px 32px; }
        }
        @media (max-width: 900px) {
          .partners-grid { grid-template-columns: 1fr 1fr; }
        }
        @media (max-width: 600px) {
          .partners-section { padding: 60px 20px; }
          .partners-grid { grid-template-columns: 1fr; }
          .partner-card { min-height: 160px; padding: 28px 20px 20px; }
        }
      `})]})}])}]);